﻿#pragma once
#include "opencv2\opencv.hpp"
#include <string>
#include<tchar.h>
#include<math.h>
#include <direct.h>
#include<fstream>
#include<iostream>
class imageSpillter
{
public:
	imageSpillter();
	~imageSpillter();
	//将RB通道合并图像抓换成RGB图像
	void solve(std::string path,bool no_windows, std::string target = "");
	bool no_windows;
private:
	cv::Mat image_a;
	cv::Mat image_g;
	cv::Mat image_b;
	cv::Mat image_raw;
	cv::Mat image_b_shifted_1;
	cv::Mat image_b_shifted_2;
	cv::Mat image_merged;
	void split();
	void yashuo();
	void shift();
	void merger(bool jidong = false, std::string target = "");
	cv::Mat get_qian(cv::Mat & img);
};

