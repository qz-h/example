﻿#pragma once
#include "includeOpenCV.h"
#include <string>
#include<tchar.h>
#include<math.h>
#include <direct.h>
#include<fstream>
#include<iostream>
#include<list>
#include "output_test.h"
#define DT 1
//#define MinSamples 4332
#define MinSamples 12646
//#define LABEL_NAME "252"
#define LABEL_NAME "314"

using namespace cv;
using namespace std;

class peizhi {
public:
	int shendu, min_sample, num_val,trees_num;
	float daichubi, hunza;
	float weight;
	peizhi(int shendu, int min_sample, int num_val,int tress_num,float weight) {
		this->shendu = shendu;
		this->min_sample = min_sample;
		this->num_val = num_val;
		this->trees_num = tress_num;
		this->weight = weight;
	}
	void shuchu(ofstream &ofs) {
		ofs << this->shendu << "," << this->min_sample << "," << this->num_val << "," <<  this->trees_num << "," << this->weight << "," << this->daichubi << "," << this->hunza << std::endl;
	}
	void show() {
		std::cout << this->shendu << "," << this->min_sample << "," << this->num_val << "," << this->trees_num << "," << this->weight << std::endl;
	}
};

class goodBadDetecctor{
	bool has_load = false;
	cv::SVM svm;
	cv::SVMParams params;

	bool use_svm = false;
	bool use_pca = false;

	cv::RandomTrees tress;
	int node_id = 0;

	

	cv::PCA pca;
	ofstream outputfile=ofstream("shuchu.c", ofstream::out);

	//std::vector<int> ge{ 0, 0, 0, 1, 9, 9, 2, 1, 3, 4, 2, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 2, 107, 65700, 70115, 54699, 39212, 22205, 15957, 14778, 13852, 12442, 9562, 5959, 2925, 973, 251, 27, 2, 0, 0, 0, 0, 0, 0, 0, 1, 162, 78304, 97733, 93074, 84553, 71168, 55994, 46217, 42044, 40186, 36757, 32115, 26910, 20983, 14863, 8885, 4361, 1607, 364, 6, 0, 0, 0, 0, 0, 13, 30217, 56951, 67636, 71586, 62728, 50439, 43419, 40303, 40938, 39956, 36688, 31890, 25872, 19985, 14339, 9122, 5086, 2382, 239, 1, 0, 0, 0, 0, 0, 5227, 19217, 26648, 34747, 32715, 23809, 15971, 15219, 19450, 23573, 25626, 25202, 22577, 18538, 13612, 8695, 4714, 2260, 287, 3, 0, 0, 0, 0, 0, 366, 2330, 3630, 7010, 12348, 10960, 5477, 1732, 1997, 2966, 4425, 6403, 8694, 10033, 9514, 7342, 4740, 2405, 196, 6, 0, 0, 0, 0, 0, 18, 199, 371, 591, 1044, 1347, 1490, 539, 184, 185, 281, 428, 571, 738, 865, 957, 1036, 1191, 241, 19, 6, 1, 0, 0, 0, 0, 14, 50, 72, 103, 207, 353, 219, 62, 32, 35, 41, 46, 63, 102, 164, 191, 285, 164, 32, 7, 3, 0};
	//std::vector<int> ge{0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 5, 1279, 1217, 276, 103, 67, 58, 55, 33, 13, 4, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 2, 103, 65244, 69890, 54568, 39132, 22190, 15950, 14775, 13851, 12441, 9562, 5959, 2925, 973, 251, 27, 2, 0, 0, 0, 0, 0, 0, 0, 1, 162, 77781, 97262, 92018, 83502, 70217, 54985, 45437, 41247, 39382, 36052, 31537, 26429, 20502, 14395, 8476, 4070, 1419, 299, 5, 0, 0, 0, 0, 0, 14, 28160, 55643, 65940, 67362, 56602, 45924, 40053, 37137, 37063, 35433, 31764, 27006, 21895, 16983, 11993, 7530, 3991, 1705, 139, 1, 0, 0, 0, 0, 1, 10799, 29546, 38292, 44934, 40035, 29175, 23785, 24214, 27828, 30071, 29322, 26622, 22098, 17020, 12000, 7645, 4325, 2255, 277, 2, 0, 0, 0, 0, 0, 1510, 8494, 12720, 21615, 23028, 16394, 8440, 6107, 8581, 12119, 15758, 17889, 17779, 15491, 11984, 7920, 4169, 1845, 200, 2, 0, 0, 0, 0, 0, 183, 1208, 1884, 3322, 6729, 8371, 4552, 1159, 959, 1344, 2039, 2898, 4027, 5671, 6828, 6172, 4333, 2330, 244, 10, 5, 0, 0, 0, 0, 5, 80, 185, 277, 535, 754, 724, 291, 88, 91, 126, 185, 269, 378, 494, 541, 517, 566, 148, 15, 2, 1, 0, 0, 0, 0, 14, 50, 71, 103, 207, 353, 219, 62, 32, 35, 41, 46, 63, 102, 164, 191, 285, 164, 32, 7, 3, 0, 0};
	//for hou
	std::vector<int> ge{ 0, 0, 70, 28398, 37954, 21821, 13145, 8445, 7354, 6730, 5444, 3301, 2404, 972, 516, 130, 34, 3, 1, 0, 0, 0, 0, 0, 0, 0, 51, 248, 55491, 81673, 66284, 53350, 36447, 27203, 25907, 25741, 21805, 22412, 15314, 12340, 6128, 3483, 1035, 344, 39, 3, 1, 0, 0, 0, 0, 21, 378, 60820, 92990, 85116, 80223, 70616, 56382, 44758, 40533, 34994, 38127, 31738, 31102, 23414, 20020, 12323, 8340, 3311, 1433, 103, 2, 0, 0, 0, 2, 143, 45303, 82215, 81547, 81496, 75193, 66824, 57636, 51167, 42957, 46031, 37534, 38308, 29802, 28176, 20329, 16834, 10157, 7214, 2006, 126, 0, 0, 0, 0, 5, 11270, 33362, 42288, 46967, 43676, 36772, 32002, 30483, 26862, 32600, 27369, 29327, 21579, 21299, 13902, 12646, 7561, 6598, 2293, 284, 0, 0, 0, 0, 1, 3445, 12841, 19668, 28982, 30876, 25185, 17541, 14483, 13369, 20128, 19746, 24691, 21101, 21638, 15314, 13409, 7537, 6278, 1849, 218, 3, 0, 0, 0, 0, 480, 2500, 4690, 9188, 16141, 16184, 10972, 4738, 2905, 5025, 5665, 9827, 10834, 15297, 13563, 13344, 9476, 7402, 1721, 134, 1, 0, 0, 0, 0, 62, 356, 552, 1034, 2021, 3696, 5399, 2918, 515, 552, 610, 1093, 1067, 1895, 1965, 3543, 4025, 5330, 2322, 191, 8, 0, 0, 0, 0, 0, 22, 59, 95, 179, 367, 553, 486, 186, 73, 54, 90, 103, 146, 168, 295, 301, 527, 437, 199, 13, 0, 0, 0, 0, 0, 4, 8, 14, 38, 76, 168, 273, 175, 91, 27, 25, 24, 34, 31, 66, 74, 176, 268, 198, 54, 4, 0, 0 };
template <typename T>
bool has_key(std::vector<T> v, T word ){
	if (std::find(v.begin(), v.end(), word) != v.end()) {
		/* v contains x */
		return true;
	}
	else {
		/* v does not contain x */
		return false;
	}
}
int read_csv_lines(string path)
{
	std::ifstream read_data(path);
	int lineID = 0;
	//エラー処理
	if (!read_data) {
		std::cout << "Error:Input data file not found" << std::endl;
		return -1;
	}

	string str;
	while (getline(read_data, str)) {
		lineID++;
	}
	return lineID;
}
cv::Mat read_csv(string path,std::vector<string> filter) //ループのカウンター値を受け取る→連続したファイルを読み込む
{
	cv::Mat result;
	int height=read_csv_lines(path)-1;
	int width = filter.size();
	
	std::ifstream read_data(path);
	std::vector<int> id_filter;
	
	//エラー処理
	if (!read_data) {
		std::cout << "Error:Input data file not found" << std::endl;
		return result;
	}

	result = Mat(cv::Size(width, height), CV_32FC1);


	std::string str;
	
	int LineID=0;
	while (getline(read_data, str)) {
		string token;
		istringstream stream(str);
		int fildID = 0;
		int savedLieID = 0;
		if (LineID % 2000 == 0) {
			std::cout << LineID << endl;
		}

		while (getline(stream, token, ',')) { // 区切り文字は ,カンマ
			if (LineID>0){
				if (has_key(id_filter, fildID)){
					result.at<float>(LineID-1, savedLieID) = atof(token.c_str());
					savedLieID++;
				}
			}else{
				if (has_key(filter, token))
					id_filter.push_back(fildID);
			}
			fildID++;
		}
		LineID++;
	}
	return result;
}
void save_pca(const string &file_name, cv::PCA pca_)
{
	FileStorage fs(file_name, FileStorage::WRITE);
	fs << "mean" << pca_.mean;
	fs << "e_vectors" << pca_.eigenvectors;
	fs << "e_values" << pca_.eigenvalues;
	fs.release();
}

int load_pca(const string &file_name, cv::PCA& pca_)
{
	FileStorage fs(file_name, FileStorage::READ);
	fs["mean"] >> pca_.mean;
	fs["e_vectors"] >> pca_.eigenvectors;
	fs["e_values"] >> pca_.eigenvalues;
	std::cout << pca_.mean.size() << std::endl;
	std::cout << pca_.eigenvalues.size() << std::endl;
	std::cout << pca_.eigenvectors.size() << std::endl;
	fs.release();
	return 0;
}
public:
	goodBadDetecctor() {
		
		params.svm_type = SVM::C_SVC;
		params.kernel_type = SVM::RBF;
		params.C = 1.3824;
		params.degree = 1.2;
		params.gamma = 0.00006;
		params.coef0 = 1.0;
		params.term_crit = TermCriteria(CV_TERMCRIT_EPS, 8000, FLT_EPSILON);
	}
	void exportSelected() {
		bool first = true;
		outputfile << "float hranges[] = { 0,12,24,40,65,85,110,140,180,210,256 };" << std::endl;
		outputfile << "float sranges[] = { 0,10,20,30,40,48,56,64,72,80,87,94,101,108,115,122,129,136,143,150,162,176,194,213,233,256 };" << std::endl;
		outputfile << "int selected_col[80]={ ";
		for (int i = 0; i < ge.size(); i++) {
			if (ge[i]>MinSamples) {
				stringstream ss;
				ss << i;
				if (first == false) {
					outputfile << ",";
				}
				outputfile << i;
				first = false;
			}
		}
		outputfile << "};" << std::endl;

		outputfile << "static unsigned char __attribute__((adress(0x5000))) ptr[80];" << std::endl;
	}
	
	void exportTree() {
		for (int i = 0; i < tress.get_tree_count(); i++) {
			auto tres_one = tress.get_tree(i);
			auto root=tres_one->get_root();
			node_id = 0;
			std::cout << "%%%%%%%%%%" << i << std::endl;

			outputfile << "unsigned char predict_" << i << "(unsigned char ptr[]){\n";
			//printNode(root, node_id);
			printNode(root, tres_one->pruned_tree_idx);
			outputfile << "}\n";
		}

		//main
		outputfile << "unsigned char predict(unsigned char ptr[]){\n";
		outputfile << "    unsigned char sum=0;\n";
		
		for (int i = 0; i < tress.get_tree_count(); i++) {
			outputfile << "    sum +=predict_" << i << "(ptr);\n";
		}
		outputfile << "    return sum;\n";
		outputfile << "}\n";
		outputfile.close();
	}
	int getID() {
		node_id++;
		return node_id;
	}
	void printSpace(int l) {
		for (int i = 0; i < l; i++) {
			outputfile << "    ";
		}
	}
	bool is_needJian(const CvDTreeNode * left, const CvDTreeNode * right) {
		if((!(left->left || left->right)) && (!(right->left || right->right))) {
			if (right->value == left->value) {
				return true;
			}
		}
		return false;
	}
	void printNode(const CvDTreeNode * node,int pruned_tree_idx) {
		
		if (node->Tn>pruned_tree_idx && node->left && node->right) {
			printSpace(node->depth + 1);

			//删除一些无用的树
			if (is_needJian(node->left , node->right)) {
				outputfile << "return " << node->left->value << ";//short version\n";
				
			}
			else {
				outputfile << "if (ptr[" << node->split->var_idx << "]<=" << int((node->split->ord.c - 0.5)*2.55) << "){\n";
				if( node->split->inversed==0) {
					printNode(node->left, pruned_tree_idx);
				}
				else {
					printNode(node->right, pruned_tree_idx);
				}
				printSpace(node->depth + 1);
				outputfile << "}else{\n";
				if (node->split->inversed == 0) {
					printNode(node->right, pruned_tree_idx);
				}
				else {
					printNode(node->left, pruned_tree_idx);
				}
				printSpace(node->depth + 1);
				outputfile << "}\n";
			}
		}
		else {
			printSpace(node->depth+1);
			outputfile << "return " << node->class_idx << ";\n";
		}
	}
	
	void load() {
		if(use_svm){
			svm.load("svm.dat", "svm");
		}
		else {
			tress.load("tress.dat", "tress");
			//exportTree();
		}
		if (use_pca) {
			load_pca("pca.model", pca);
		}
		has_load = true;
	}
	void pridict(cv::Mat & dat, cv::Mat & result, cv::Mat answer,bool extend) {
		result = cv::Mat(cv::Size(1, dat.rows), CV_32FC1);
		for (int i = 0; i < dat.rows; i++) {
			std::vector<float> d;
			for (int j = 0; j < dat.cols; j++) {
				d.push_back(dat.at<float>(i,j));
			}
			result.at<float>(i, 0) = pridict(d, extend, answer.at<float>(i,0));
		}
	}

	void tress_pridict(cv::Mat & dat, cv::Mat & result,bool use_pro=false) {
		result = cv::Mat(cv::Size(1, dat.rows), CV_32FC1);

		result.setTo(cv::Scalar(0));
		auto d = cv::Mat(cv::Size(dat.cols,1), CV_32FC1);

		for (int i = 0; i < dat.rows; i++) {
			for (int j = 0; j < dat.cols; j++) {
				d.at<float>(0, j) = dat.at<float>(i, j);
			}
			float yy;
			if (!use_pro) {
				 yy = tress.predict(d);
			}
			else {
				 yy = tress.predict_prob(d);
			}
			result.at<float>(i, 0) = yy;
		}
	}
	void c_tress_pridict(cv::Mat & dat, cv::Mat & result, bool use_pro = false) {
		unsigned char fe[80];
		test_moudule tester;
		result = cv::Mat(cv::Size(1, dat.rows), CV_32FC1);


		result.setTo(cv::Scalar(0));
		

		for (int i = 0; i < dat.rows; i++) {
			for (int j = 0; j < dat.cols; j++) {
				fe[j] = unsigned char(2.55*dat.at<float>(i, j));
			}
			unsigned char yy;
			yy = tester.c_predict(fe);
			if (yy >= 6) {
				result.at<float>(i, 0) = 1;
			}
			else {
				result.at<float>(i, 0) = 0;
			}
		}
	}
	

	std::vector<float> makeDes(std::vector<float> des) {
		std::vector<float>nn;
#if DT==0
		int ge[] = { 0,137,858,1956,4827,10537,19770,31772,46266,60364,72688,81068,85343,87711,87030,83085,77463,71500,65031,58325,51900,45255,38127,30658,23964,17893,12861,8655,5242,2775,1314,1157,0,0,0,0,1,36,292,852,2245,4842,9599,15891,23531,32491,41738,50034,58078,64341,69755,72373,73605,72891,70356,65248,58870,51549,43342,35215,28330,22126,17385,38763,0,0,0,0,0,0,0,0,0,0,0,8,20,90,199,495,955,1729,2973,4847,7310,10094,13220,16369,19154,20948,21984,21968,20962,19015,16583,39934,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,8,20,38,65,145,169,283,435,571,748,949,1409,13508,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,9,9,5,10,17,30,61,1656,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,281,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,9,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0 };
		for (int i = 0; i < 256; i++) {
			if (ge[i] > MinSamples) {
				nn.push_back(des[i]);
			}
		}
#else
		for (int i = 0; i < ge.size(); i++) {
			if (ge[i]>MinSamples) {
				nn.push_back(des[i]);
			}
		}
#endif

		//std::cout << nn.size();
		return nn;
	};
	

	float pridict(std::vector<float> & d, bool extend, float answer = 0, bool use_pro = false) {
		if (!has_load)
			load();
		cv::Mat detect_data = Mat(cv::Size(d.size(), 1), CV_32FC1);
		int i = 0;
		for (auto it = d.begin(); it != d.end(); it++) {
			detect_data.at<float>(0, i) = *it;
			i++;
		}

		cv::Mat projection_data;
		if(use_pca){
			projection_data = pca.project(detect_data);
		}
		else {
			projection_data = detect_data;
		}
		//std::cout << "target_data.size:" << projection_data.rows << "," << projection_data.cols << std::endl;
		cv::Mat detect_label;
		//svm.predict(detect_data, detect_label);

		if(use_svm){
			svm.predict(projection_data, detect_label);
		}
		else {
			tress_pridict(projection_data, detect_label, use_pro);
		}


		auto predict_result = detect_label.at<float>(0, 0);

		return predict_result;
		
	}
	void splitSample(cv::Mat & sample, cv::Mat & train, cv::Mat & test, cv::Mat & train_mask) {
		train = cv::Mat(cv::Size(sample.cols, cv::countNonZero(train_mask)), CV_32FC1);
		test = cv::Mat(cv::Size(sample.cols, sample.rows-cv::countNonZero(train_mask)), CV_32FC1);
		train.setTo(cv::Scalar(0));
		test.setTo(cv::Scalar(0));
		int tran_line_id = 0;
		int test_line_id = 0;
		
		for (int i = 0; i < sample.rows; i++) {
			if (train_mask.at<uchar>(i, 0)) {
				for (int j = 0; j < sample.cols; j++) {
					train.at<float>(tran_line_id, j) = sample.at<float>(i, j);
				}
				tran_line_id++;
			}else{
				for (int j = 0; j < sample.cols; j++) {
					test.at<float>(test_line_id, j) = sample.at<float>(i, j);
				}
				test_line_id++;
			}
		}

	}
	void export_model(string mode_path) {
		std::cout << "Load tress. mode_path=" << mode_path << std::endl;
		tress.load(mode_path.c_str(), "tress");
		exportSelected();
		exportTree();
	}
	void test_c(string path) {
		string test_csv;
		test_csv = path;

		std::cout << "Start test_c. test_csv=" << test_csv << std::endl;

		std::vector<string> data_filter;

		for (int i = 0; i < ge.size(); i++) {
			if (ge[i]>MinSamples) {
				stringstream ss;
				ss << i;
				data_filter.push_back(ss.str());
			}
		}

		std::vector<string> lable_filter;
		lable_filter.push_back(LABEL_NAME);

		std::cout << "Load sample data..." << std::endl;
		auto test_data = read_csv(test_csv, data_filter);
		std::cout << "Load label..." << std::endl;
		auto test_label = read_csv(test_csv, lable_filter);

		//输出第一行作为测试数据
		std::cout << "First row of data\n";

		for (int rowID = 0; rowID < 11; rowID++) {
			for (int i = 0; i < test_data.cols; i++) {
				std::cout << test_data.at<float>(rowID, i) << ",";
			}
			std::cout << std::endl;
		}
		std::cout << "First row of label\n";

		for (int rowID = 0; rowID<11; rowID++) {
			for (int i = 0; i < test_label.cols; i++) {
				std::cout << test_label.at<float>(rowID, i) << ",";
			}
			std::cout << std::endl;
		}

		for (int i = 0; i < data_filter.size(); i++) {
			std::cout << test_data.at<float>(0, i) << ",";
		}
		std::cout << std::endl;

		auto projection_test_data = test_data;


		std::cout << "test_data.size:" << test_data.rows << "," << test_data.cols << std::endl;
		std::cout << "projection_train_data.size:" << projection_test_data.rows << "," << projection_test_data.cols << std::endl;

		std::cout << "Test Random Forest" << std::endl;

		
		//检测
		cv::Mat output_label;

		c_tress_pridict(projection_test_data, output_label);

		int tp = 0, tn = 0, fp = 0, fn = 0;
		for (int i = 0; i < test_label.rows; i++) {
			
			if (test_label.at<float>(i, 0) == 1) {
				if (output_label.at<float>(i, 0) == 1) {
					tp++;
				}
				else {
					fn++;
				}
			}
			else {
				if (output_label.at<float>(i, 0) == 1) {
					fp++;
				}
				else {
					tn++;
				}
			}
		}
		float daichubi = 1.0*fp / (tn + fp);
		float kunzaibi = 1.0*fn / (tp + fn);
		std::cout << "dai_chu_bi\thun_za_bi" << std::endl;
		std::cout << daichubi;
		std::cout << "\t," << kunzaibi << std::endl;
	}
	void test(string path, string mode_path) {
		string test_csv;
		test_csv = path;

		std::cout << "Start test. test_csv=" << test_csv << std::endl;

		std::vector<string> data_filter;

		for (int i = 0; i < ge.size(); i++) {
			if (ge[i]>MinSamples) {
				stringstream ss;
				ss << i;
				data_filter.push_back(ss.str());
			}
		}

		std::vector<string> lable_filter;
		lable_filter.push_back(LABEL_NAME);

		std::cout << "Load sample data..." << std::endl;
		auto test_data = read_csv(test_csv, data_filter);
		std::cout << "Load label..." << std::endl;
		auto test_label = read_csv(test_csv, lable_filter);

		//输出第一行作为测试数据
		std::cout << "First row of data\n";

		for (int rowID = 0; rowID < 12; rowID++) {
			for (int i = 0; i < test_data.cols; i++) {
				std::cout << test_data.at<float>(rowID, i) << ",";
			}
			std::cout << std::endl;
		}
		std::cout << "First row of label\n";

		for (int rowID = 0; rowID<12; rowID++) {
			for (int i = 0; i < test_label.cols; i++) {
				std::cout << test_label.at<float>(rowID, i) << ",";
			}
			std::cout << std::endl;
		}

		for (int i = 0; i < data_filter.size(); i++) {
			std::cout << test_data.at<float>(0, i) << ",";
		}
		std::cout << std::endl;

		auto projection_test_data = test_data;


		std::cout << "test_data.size:" << test_data.rows << "," << test_data.cols << std::endl;
		std::cout << "projection_train_data.size:" << projection_test_data.rows << "," << projection_test_data.cols << std::endl;

		std::cout << "Test Random Forest" << std::endl;

		//加载模型
		tress.load(mode_path.c_str(), "tress");

		//检测
		cv::Mat output_label;
		
		tress_pridict(projection_test_data, output_label);

		int tp = 0, tn = 0, fp = 0, fn = 0;
		for (int i = 0; i < test_label.rows; i++) {
			if (test_label.at<float>(i, 0) == 1) {
				if (output_label.at<float>(i, 0) == 1) {
					tp++;
				}
				else {
					fn++;
				}
			}
			else {
				if (output_label.at<float>(i, 0) == 1) {
					fp++;
				}
				else {
					tn++;
				}
			}
		}
		float daichubi = 1.0*fp / (tn + fp);
		float kunzaibi = 1.0*fn / (tp + fn);
		std::cout << "dai_chu_bi\thun_za_bi" << std::endl;
		std::cout << daichubi;
		std::cout << "\t," << kunzaibi << std::endl;
	}
	/*
	id:	file ID
	a:	max depth
	b:	 min sample count
	c:	num_val
	d:	trees_num
	weight:weight
	*/
	void train(string path,int a,int b,int c,int d,float weight) {
#if DT==0
		string train_csv = "C:/Users/Duan/Desktop/sexuanj/work/result_s_3.csv";
		string test_csv = "C:/Users/Duan/Desktop/sexuanj/work/result_s_2.csv";
#else
		string train_csv;
		string test_csv;
		
		train_csv = path;
		test_csv = "";
		
		std::cout << "Start training. train_csv=" << train_csv << std::endl;
#endif
		std::vector<string> data_filter;
#if DT==0
		int ge[] = { 0,137,858,1956,4827,10537,19770,31772,46266,60364,72688,81068,85343,87711,87030,83085,77463,71500,65031,58325,51900,45255,38127,30658,23964,17893,12861,8655,5242,2775,1314,1157,0,0,0,0,1,36,292,852,2245,4842,9599,15891,23531,32491,41738,50034,58078,64341,69755,72373,73605,72891,70356,65248,58870,51549,43342,35215,28330,22126,17385,38763,0,0,0,0,0,0,0,0,0,0,0,8,20,90,199,495,955,1729,2973,4847,7310,10094,13220,16369,19154,20948,21984,21968,20962,19015,16583,39934,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,8,20,38,65,145,169,283,435,571,748,949,1409,13508,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,9,9,5,10,17,30,61,1656,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,281,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,9,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0 };
		for (int i = 0; i < 256; i++) {
			if (ge[i]>20) {
				stringstream ss;
				ss << i;
				data_filter.push_back(ss.str());
			}
		}

		std::vector<string> lable_filter;
		lable_filter.push_back("256");
#else
		
		for (int i = 0; i < ge.size(); i++) {
			if (ge[i]>MinSamples) {
				stringstream ss;
				ss << i;
				data_filter.push_back(ss.str());
			}
		}

		std::vector<string> lable_filter;
		lable_filter.push_back(LABEL_NAME);
#endif

		


		float train_percent = 0.8;
		if (test_csv.length() > 0) {
			train_percent = 1;
		}

		std::cout << "Load sample data..." << std::endl;
		auto sample_data = read_csv(train_csv, data_filter);
		std::cout << "Load label..." << std::endl;
		auto sample_label = read_csv(train_csv, lable_filter);

//输出第一行作为测试数据
		std::cout << "First row of data\n";

		for (int rowID = 0; rowID < 2; rowID++) {
			for (int i = 0; i < sample_data.cols; i++) {
				std::cout << sample_data.at<float>(rowID, i) << ",";
			}
			std::cout << std::endl;
		}
		std::cout << "First row of label\n";

		for (int rowID=0;rowID<2;rowID++){
		for (int i = 0; i < sample_label.cols; i++) {
			std::cout << sample_label.at<float>(rowID, i) << ",";
		}
		std::cout << std::endl;
		}


		int maxLines = sample_data.rows;
		cv::Mat train_slot(Size(1, maxLines), CV_32FC1);
		cv::RNG rng(2945673);
		cv::theRNG().state = 122225;
		cv::randu(train_slot, (float)0, (float)1);

		Mat  split_mask(Size(1, maxLines), CV_8UC1);;

		split_mask.setTo(Scalar(1));
		for (int i = 0; i < train_slot.rows; i++) {
			if (train_slot.at<float>(i, 0) > train_percent) {
				split_mask.at<uchar>(i, 0) = 0;
			};
		}

		cv::Mat train_data, train_label;
		cv::Mat test_data, test_label;

		

		if (test_csv.length() > 0) {
			test_data = read_csv(test_csv, data_filter);
			test_label = read_csv(test_csv, lable_filter);

			train_data = sample_data.clone();
			train_label = sample_label.clone();
		}
		else {
			std::cout << "Do spliting..." << std::endl;
			splitSample(sample_data, train_data, test_data, split_mask);
			splitSample(sample_label, train_label, test_label, split_mask);
		}



		for (int i = 0; i < data_filter.size(); i++) {
			std::cout << train_data.at<float>(0, i) << ",";
		}
		std::cout << std::endl;
		
		if(use_pca){
			pca = cv::PCA(train_data, cv::Mat(), CV_PCA_DATA_AS_ROW, 90);
			save_pca("pca.model", pca);
		}
		//auto projection_train_data = pca.project(train_data);
		//auto projection_test_data = pca.project(test_data);

		auto projection_train_data = train_data;
		auto projection_test_data = test_data;

		std::cout << "train_data.size:" << train_data.rows << "," << train_data.cols << std::endl;
		std::cout << "test_data.size:" << test_data.rows << "," << test_data.cols << std::endl;
		std::cout << "projection_train_data.size:" << projection_train_data.rows << "," << projection_train_data.cols << std::endl;

		if (use_svm) {
			std::cout << "Train SVM" << std::endl;
			vector<float> vf{ (float)1.2,(float)1 };
			CvMat weightMat = Mat(vf);
			params.class_weights = &weightMat;

			if (1) {
				//svm.train(train_data, train_label, cv::Mat(),cv::Mat(),params);
				svm.train(projection_train_data, train_label, cv::Mat(), cv::Mat(), params);
			}
			else {

				auto config_para1 = svm.get_default_grid(CvSVM::C);
				config_para1.step = 1.2;
				config_para1.min_val = 0.8;
				config_para1.max_val = 1.6;
				auto config_para2 = svm.get_default_grid(CvSVM::GAMMA);
				config_para2.step = 1.5;//params.gamma = 0.0005;
				config_para2.min_val = 0.000075;
				config_para2.max_val = 0.0002;
				auto config_para3 = svm.get_default_grid(CvSVM::P);
				config_para3.step = 0;
				auto config_para4 = svm.get_default_grid(CvSVM::NU);
				config_para4.step = 0;
				auto config_para5 = svm.get_default_grid(CvSVM::COEF);
				config_para5.step = 0;
				auto config_para6 = svm.get_default_grid(CvSVM::DEGREE);
				config_para6.step = 0;
				svm.train_auto(projection_train_data, train_label, cv::Mat(), cv::Mat(), params,
					15,
					config_para1,
					config_para2,
					config_para3,
					config_para4,
					config_para5,
					config_para6,
					true);
				auto bestPara = svm.get_params();
				std::cout << "bestPara.C:" << bestPara.C << std::endl;
				std::cout << "bestPara.coef0:" << bestPara.coef0 << std::endl;
				std::cout << "bestPara.degree:" << bestPara.degree << std::endl;
				std::cout << "bestPara.gamma:" << bestPara.gamma << std::endl;
			}
		}
		else {
			std::cout << "Train Random Forest" << std::endl;

			std::vector<peizhi> peizhi_array;		
			float priors[] = { 1.75,1 };  // weights of each classification for classes
			if (a>=0){
				peizhi_array.push_back(peizhi(a, b, c,d,weight));
				
			}
			else {
				peizhi_array.push_back(peizhi(16, 101, 0,20,1.75));
			}
			std::vector<peizhi>::iterator itr = peizhi_array.begin();

			itr->show();
			
			while (itr != peizhi_array.end()) {
				priors[0] = itr->weight ;
				CvRTParams para = CvRTParams(itr->shendu, // max depth
					itr->min_sample, // min sample count
					0, // regression accuracy: N/A here
					false, // compute surrogate split, no missing data
					2, // max number of categories (use sub-optimal algorithm for larger numbers)
					priors, // the array of priors
					false,  // calculate variable importance
					itr->num_val,       // number of variables randomly selected at node and used to find the best split(s).
					itr->trees_num,     // max number of trees in the forest
					0.00001f,                // forest accuracy
					CV_TERMCRIT_ITER | CV_TERMCRIT_EPS // termination cirteria
				);
				para.use_1se_rule = true;
				para.truncate_pruned_tree = true;
				tress.train(projection_train_data, CV_ROW_SAMPLE, train_label, cv::Mat(), cv::Mat(), cv::Mat(), cv::Mat(), para);
			
				if (a>=0){
					//这一部分单独为了检测
					cv::Mat output_label;
					//std::cout << "Test Random Forest" << std::endl;
					tress_pridict(projection_test_data, output_label);


					int tp = 0, tn = 0, fp = 0, fn = 0;
					for (int i = 0; i < test_label.rows; i++) {
						if (test_label.at<float>(i, 0) == 1) {
							if (output_label.at<float>(i, 0) == 1) {
								tp++;
							}
							else {
								fn++;
							}
						}
						else {
							if (output_label.at<float>(i, 0) == 1) {
								fp++;
							}
							else {
								tn++;
							}
						}
					}
					float daichubi = 1.0*fp / (tn + fp);
					float kunzaibi = 1.0*fn / (tp + fn);
					std::cout << "dai_chu_bi\thun_za_bi" << std::endl;
					std::cout << daichubi;
					std::cout << "\t," << kunzaibi << std::endl;

					itr->daichubi = daichubi;
					itr->hunza = kunzaibi;
					ofstream ofs("grid.csv", ofstream::app);
					itr->shuchu(ofs);
					ofs.close();

					tress.save("tress.dat", "tress");
				}
				itr++;
			}

			if (a >= 0) {
				return;
			}
			//shuchu
			/*ofstream ofs("grid.csv", ofstream::app);
			itr = peizhi_array.begin();
			while (itr != peizhi_array.end()) {
				itr->shuchu(ofs);
			}*/
		}
		//jian yan
		cv::Mat output_label;
		if (use_svm) {
			std::cout << "Test SVM" << std::endl;
			svm.predict(projection_test_data, output_label);
		}
		else {
			std::cout << "Test Random Forest" << std::endl;
			tress_pridict(projection_test_data, output_label);
		}
		int tp = 0, tn = 0, fp = 0, fn = 0;
		for (int i = 0; i < test_label.rows; i++) {
			if (test_label.at<float>(i, 0) == 1) {
				if (output_label.at<float>(i, 0) == 1) {
					tp++;
				}
				else {
					fn++;
				}
			}
			else {
				if (output_label.at<float>(i, 0) == 1) {
					fp++;
				}
				else {
					tn++;
				}
			}
		}
		std::cout << "TP:" << tp << std::endl;
		std::cout << "TN:" << tn << std::endl;
		std::cout << "FP:" << fp << std::endl;
		std::cout << "FN:" << fn << std::endl;
		std::cout << "daichubi fp/(tn+fp):" << 1.0*fp / (tn + fp) << std::endl;
		std::cout << "kunzabi fn/(tp+fn):" << 1.0*fn / (tp + fn) << std::endl;

		if (use_svm) {
			svm.save("svm.dat", "svm");
		}else{
			tress.save("tress.dat", "tress");
		}
	}
	~goodBadDetecctor() {
		outputfile.close();
	}
};

class goodBadDetecctor_svm{
	bool has_load = false;
	cv::SVM svm;
	cv::SVMParams params;

	bool use_svm = true;
	bool use_pca = true;




	cv::PCA pca;
	
	std::vector<int> ge{ 0, 0, 70, 28398, 37954, 21821, 13145, 8445, 7354, 6730, 5444, 3301, 2404, 972, 516, 130, 34, 3, 1, 0, 0, 0, 0, 0, 0, 0, 51, 248, 55491, 81673, 66284, 53350, 36447, 27203, 25907, 25741, 21805, 22412, 15314, 12340, 6128, 3483, 1035, 344, 39, 3, 1, 0, 0, 0, 0, 21, 378, 60820, 92990, 85116, 80223, 70616, 56382, 44758, 40533, 34994, 38127, 31738, 31102, 23414, 20020, 12323, 8340, 3311, 1433, 103, 2, 0, 0, 0, 2, 143, 45303, 82215, 81547, 81496, 75193, 66824, 57636, 51167, 42957, 46031, 37534, 38308, 29802, 28176, 20329, 16834, 10157, 7214, 2006, 126, 0, 0, 0, 0, 5, 11270, 33362, 42288, 46967, 43676, 36772, 32002, 30483, 26862, 32600, 27369, 29327, 21579, 21299, 13902, 12646, 7561, 6598, 2293, 284, 0, 0, 0, 0, 1, 3445, 12841, 19668, 28982, 30876, 25185, 17541, 14483, 13369, 20128, 19746, 24691, 21101, 21638, 15314, 13409, 7537, 6278, 1849, 218, 3, 0, 0, 0, 0, 480, 2500, 4690, 9188, 16141, 16184, 10972, 4738, 2905, 5025, 5665, 9827, 10834, 15297, 13563, 13344, 9476, 7402, 1721, 134, 1, 0, 0, 0, 0, 62, 356, 552, 1034, 2021, 3696, 5399, 2918, 515, 552, 610, 1093, 1067, 1895, 1965, 3543, 4025, 5330, 2322, 191, 8, 0, 0, 0, 0, 0, 22, 59, 95, 179, 367, 553, 486, 186, 73, 54, 90, 103, 146, 168, 295, 301, 527, 437, 199, 13, 0, 0, 0, 0, 0, 4, 8, 14, 38, 76, 168, 273, 175, 91, 27, 25, 24, 34, 31, 66, 74, 176, 268, 198, 54, 4, 0, 0 };
	template <typename T>
	bool has_key(std::vector<T> v, T word) {
		if (std::find(v.begin(), v.end(), word) != v.end()) {
			/* v contains x */
			return true;
		}
		else {
			/* v does not contain x */
			return false;
		}
	}
	int read_csv_lines(string path)
	{
		std::ifstream read_data(path);
		int lineID = 0;
		//エラー処理
		if (!read_data) {
			std::cout << "Error:Input data file not found" << std::endl;
			return -1;
		}

		string str;
		while (getline(read_data, str)) {
			lineID++;
		}
		return lineID;
	}
	cv::Mat read_csv(string path, std::vector<string> filter) //ループのカウンター値を受け取る→連続したファイルを読み込む
	{
		cv::Mat result;
		int height = read_csv_lines(path) - 1;
		int width = filter.size();

		std::ifstream read_data(path);
		std::vector<int> id_filter;

		//エラー処理
		if (!read_data) {
			std::cout << "Error:Input data file not found" << std::endl;
			return result;
		}

		result = Mat(cv::Size(width, height), CV_32FC1);


		std::string str;

		int LineID = 0;
		while (getline(read_data, str)) {
			string token;
			istringstream stream(str);
			int fildID = 0;
			int savedLieID = 0;
			if (LineID % 5000 == 0) {
				std::cout << LineID << endl;
			}

			while (getline(stream, token, ',')) { // 区切り文字は ,カンマ
				if (LineID>0) {
					if (has_key(id_filter, fildID)) {
						result.at<float>(LineID - 1, savedLieID) = atof(token.c_str());
						savedLieID++;
					}
				}
				else {
					if (has_key(filter, token))
						id_filter.push_back(fildID);
				}
				fildID++;
			}
			LineID++;
		}
		return result;
	}
	void save_pca(const string &file_name, cv::PCA pca_)
	{
		FileStorage fs(file_name, FileStorage::WRITE);
		fs << "mean" << pca_.mean;
		fs << "e_vectors" << pca_.eigenvectors;
		fs << "e_values" << pca_.eigenvalues;
		fs.release();
	}

	int load_pca(const string &file_name, cv::PCA& pca_)
	{
		FileStorage fs(file_name, FileStorage::READ);
		fs["mean"] >> pca_.mean;
		fs["e_vectors"] >> pca_.eigenvectors;
		fs["e_values"] >> pca_.eigenvalues;
		std::cout << pca_.mean.size() << std::endl;
		std::cout << pca_.eigenvalues.size() << std::endl;
		std::cout << pca_.eigenvectors.size() << std::endl;
		fs.release();
		return 0;
	}
public:
	goodBadDetecctor_svm() {

		
	}

	void load() {
		
		svm.load("svm.dat", "svm");
		
		if (use_pca) {
			load_pca("pca.model", pca);
		}
		has_load = true;
	}
	void pridict(cv::Mat & dat, cv::Mat & result, cv::Mat answer, bool extend) {
		result = cv::Mat(cv::Size(1, dat.rows), CV_32FC1);
		for (int i = 0; i < dat.rows; i++) {
			std::vector<float> d;
			for (int j = 0; j < dat.cols; j++) {
				d.push_back(dat.at<float>(i, j));
			}
			result.at<float>(i, 0) = pridict(d, extend, answer.at<float>(i, 0));
		}
	}



	std::vector<float> makeDes(std::vector<float> des) {
		std::vector<float>nn;
		for (int i = 0; i < ge.size(); i++) {
			if (ge[i]>MinSamples) {
				nn.push_back(des[i]);
			}
		}
		return nn;
	};


	float pridict(std::vector<float> & d, bool extend, float answer = 0, bool use_pro = false) {
		if (!has_load)
			load();
		cv::Mat detect_data = Mat(cv::Size(d.size(), 1), CV_32FC1);
		int i = 0;
		for (auto it = d.begin(); it != d.end(); it++) {
			detect_data.at<float>(0, i) = *it;
			i++;
		}

		cv::Mat projection_data;
		if (use_pca) {
			projection_data = pca.project(detect_data);
		}
		else {
			projection_data = detect_data;
		}
		//std::cout << "target_data.size:" << projection_data.rows << "," << projection_data.cols << std::endl;
		cv::Mat detect_label;
		//svm.predict(detect_data, detect_label);

		
		svm.predict(projection_data, detect_label);

		auto predict_result = detect_label.at<float>(0, 0);

		return predict_result;

	}
	void splitSample(cv::Mat & sample, cv::Mat & train, cv::Mat & test, cv::Mat & train_mask) {
		train = cv::Mat(cv::Size(sample.cols, cv::countNonZero(train_mask)), CV_32FC1);
		test = cv::Mat(cv::Size(sample.cols, sample.rows - cv::countNonZero(train_mask)), CV_32FC1);
		train.setTo(cv::Scalar(0));
		test.setTo(cv::Scalar(0));
		int tran_line_id = 0;
		int test_line_id = 0;

		for (int i = 0; i < sample.rows; i++) {
			if (train_mask.at<uchar>(i, 0)) {
				for (int j = 0; j < sample.cols; j++) {
					train.at<float>(tran_line_id, j) = sample.at<float>(i, j);
				}
				tran_line_id++;
			}
			else {
				for (int j = 0; j < sample.cols; j++) {
					test.at<float>(test_line_id, j) = sample.at<float>(i, j);
				}
				test_line_id++;
			}
		}

	}
	
	//void test(string path, string mode_path) {
	//	string test_csv;
	//	test_csv = path;

	//	std::cout << "Start test. test_csv=" << test_csv << std::endl;

	//	std::vector<string> data_filter;

	//	for (int i = 0; i < ge.size(); i++) {
	//		if (ge[i]>MinSamples) {
	//			stringstream ss;
	//			ss << i;
	//			data_filter.push_back(ss.str());
	//		}
	//	}

	//	std::vector<string> lable_filter;
	//	lable_filter.push_back(LABEL_NAME);

	//	std::cout << "Load sample data..." << std::endl;
	//	auto test_data = read_csv(test_csv, data_filter);
	//	std::cout << "Load label..." << std::endl;
	//	auto test_label = read_csv(test_csv, lable_filter);

	//	//输出第一行作为测试数据
	//	std::cout << "First row of data\n";

	//	for (int rowID = 0; rowID < 12; rowID++) {
	//		for (int i = 0; i < test_data.cols; i++) {
	//			std::cout << test_data.at<float>(rowID, i) << ",";
	//		}
	//		std::cout << std::endl;
	//	}
	//	std::cout << "First row of label\n";

	//	for (int rowID = 0; rowID<12; rowID++) {
	//		for (int i = 0; i < test_label.cols; i++) {
	//			std::cout << test_label.at<float>(rowID, i) << ",";
	//		}
	//		std::cout << std::endl;
	//	}

	//	for (int i = 0; i < data_filter.size(); i++) {
	//		std::cout << test_data.at<float>(0, i) << ",";
	//	}
	//	std::cout << std::endl;

	//	auto projection_test_data = test_data;


	//	std::cout << "test_data.size:" << test_data.rows << "," << test_data.cols << std::endl;
	//	std::cout << "projection_train_data.size:" << projection_test_data.rows << "," << projection_test_data.cols << std::endl;

	//	std::cout << "Test Random Forest" << std::endl;

	//	//加载模型
	//	tress.load(mode_path.c_str(), "tress");

	//	//检测
	//	cv::Mat output_label;

	//	tress_pridict(projection_test_data, output_label);

	//	int tp = 0, tn = 0, fp = 0, fn = 0;
	//	for (int i = 0; i < test_label.rows; i++) {
	//		if (test_label.at<float>(i, 0) == 1) {
	//			if (output_label.at<float>(i, 0) == 1) {
	//				tp++;
	//			}
	//			else {
	//				fn++;
	//			}
	//		}
	//		else {
	//			if (output_label.at<float>(i, 0) == 1) {
	//				fp++;
	//			}
	//			else {
	//				tn++;
	//			}
	//		}
	//	}
	//	float daichubi = 1.0*fp / (tn + fp);
	//	float kunzaibi = 1.0*fn / (tp + fn);
	//	std::cout << "dai_chu_bi\thun_za_bi" << std::endl;
	//	std::cout << daichubi;
	//	std::cout << "\t," << kunzaibi << std::endl;
	//}
	/*
	id:	file ID
	a:	max depth
	b:	 min sample count
	c:	num_val
	d:	trees_num
	weight:weight
	*/
	void train(string path, int pca_variant_num, int use_auto_train, int use_one_class, int d, float weight) {

		string train_csv;
		string test_csv;

		train_csv = path;
		test_csv = "";

		std::cout << "Start training. train_csv=" << train_csv << std::endl;

		if (pca_variant_num > 0) {
			use_pca = true;
		}
		else {
			use_pca = false;
		}
		std::cout << "use_pca=" << use_pca << std::endl;
		std::cout << "pca_variant_num=" << pca_variant_num << std::endl;

		std::vector<string> data_filter;


		for (int i = 0; i < ge.size(); i++) {
			if (ge[i]>MinSamples) {
				stringstream ss;
				ss << i;
				data_filter.push_back(ss.str());
			}
		}

		std::vector<string> lable_filter;
		lable_filter.push_back(LABEL_NAME);


		float train_percent = 0.8;
		if (test_csv.length() > 0) {
			train_percent = 1;
		}

		std::cout << "Load sample data..." << std::endl;
		auto sample_data = read_csv(train_csv, data_filter);
		std::cout << "Load label..." << std::endl;
		auto sample_label = read_csv(train_csv, lable_filter);

		//输出第一行作为测试数据
		std::cout << "First row of data\n";

		for (int rowID = 0; rowID < 2; rowID++) {
			for (int i = 0; i < sample_data.cols; i++) {
				std::cout << sample_data.at<float>(rowID, i) << ",";
			}
			std::cout << std::endl;
		}
		std::cout << "First row of label\n";

		for (int rowID = 0; rowID<2; rowID++) {
			for (int i = 0; i < sample_label.cols; i++) {
				std::cout << sample_label.at<float>(rowID, i) << ",";
			}
			std::cout << std::endl;
		}


		int maxLines = sample_data.rows;
		cv::Mat train_slot(Size(1, maxLines), CV_32FC1);
		cv::RNG rng(2945673);
		cv::theRNG().state = 122225;
		cv::randu(train_slot, (float)0, (float)1);

		Mat  split_mask(Size(1, maxLines), CV_8UC1);;

		split_mask.setTo(Scalar(1));
		for (int i = 0; i < train_slot.rows; i++) {
			if (train_slot.at<float>(i, 0) > train_percent) {
				split_mask.at<uchar>(i, 0) = 0;
			};
		}

		cv::Mat train_data, train_label;
		cv::Mat test_data, test_label;

		if (test_csv.length() > 0) {
			test_data = read_csv(test_csv, data_filter);
			test_label = read_csv(test_csv, lable_filter);

			train_data = sample_data.clone();
			train_label = sample_label.clone();
		}
		else {
			std::cout << "Do spliting..." << std::endl;
			splitSample(sample_data, train_data, test_data, split_mask);
			splitSample(sample_label, train_label, test_label, split_mask);
		}



		for (int i = 0; i < data_filter.size(); i++) {
			std::cout << train_data.at<float>(0, i) << ",";
		}
		std::cout << std::endl;

		cv::Mat projection_train_data = train_data;
		cv::Mat projection_test_data = test_data;
		if (use_pca) {
			pca = cv::PCA(train_data, cv::Mat(), CV_PCA_DATA_AS_ROW, pca_variant_num);
			save_pca("pca.model", pca);

			projection_train_data = pca.project(train_data);
			projection_test_data = pca.project(test_data);
		}

		std::cout << "train_data.size:" << train_data.rows << "," << train_data.cols << std::endl;
		std::cout << "test_data.size:" << test_data.rows << "," << test_data.cols << std::endl;
		std::cout << "projection_train_data.size:" << projection_train_data.rows << "," << projection_train_data.cols << std::endl;

		std::cout << "Train SVM" << std::endl;

		if (use_one_class) {

		}

		params.svm_type = SVM::C_SVC;
		params.kernel_type = SVM::RBF;
		params.C = 1.3824;
		params.degree = 1.2;
		params.gamma = 0.00006;
		params.coef0 = 1.0;
		params.term_crit = TermCriteria(CV_TERMCRIT_EPS, 8000, FLT_EPSILON);

		vector<float> vf{ weight,(float)1 };
		CvMat weightMat = Mat(vf);
		params.class_weights = &weightMat;

		if (use_auto_train==0) {
			//svm.train(train_data, train_label, cv::Mat(),cv::Mat(),params);
			svm.train(projection_train_data, train_label, cv::Mat(), cv::Mat(), params);
		}
		else {
			std::cout << "SVM Auto config" << std::endl;
			auto config_para1 = svm.get_default_grid(CvSVM::C);
			config_para1.step = 1.2;
			config_para1.min_val = 0.8;
			config_para1.max_val = 1.6;

			auto config_para2 = svm.get_default_grid(CvSVM::GAMMA);
			config_para2.step = 1.5;//params.gamma = 0.0005;
			config_para2.min_val = 0.000075;
			config_para2.max_val = 0.0002;
			
			auto config_para3 = svm.get_default_grid(CvSVM::P);
			config_para3.step = 0;
			auto config_para4 = svm.get_default_grid(CvSVM::NU);
			config_para4.step = 0;
			auto config_para5 = svm.get_default_grid(CvSVM::COEF);
			config_para5.step = 0;
			auto config_para6 = svm.get_default_grid(CvSVM::DEGREE);
			config_para6.step = 0;
			svm.train_auto(projection_train_data, train_label, cv::Mat(), cv::Mat(), params,
				15,
				config_para1,
				config_para2,
				config_para3,
				config_para4,
				config_para5,
				config_para6,
				true);
			auto bestPara = svm.get_params();
			std::cout << "bestPara.C:" << bestPara.C << std::endl;
			std::cout << "bestPara.coef0:" << bestPara.coef0 << std::endl;
			std::cout << "bestPara.degree:" << bestPara.degree << std::endl;
			std::cout << "bestPara.gamma:" << bestPara.gamma << std::endl;
		}
		
		//jian yan
		cv::Mat output_label;
		std::cout << "Test SVM" << std::endl;
		svm.predict(projection_test_data, output_label);

		int tp = 0, tn = 0, fp = 0, fn = 0;
		for (int i = 0; i < test_label.rows; i++) {
			if (test_label.at<float>(i, 0) == 1) {
				if (output_label.at<float>(i, 0) == 1) {
					tp++;
				}
				else {
					fn++;
				}
			}
			else {
				if (output_label.at<float>(i, 0) == 1) {
					fp++;
				}
				else {
					tn++;
				}
			}
		}
		std::cout << "TP:" << tp << std::endl;
		std::cout << "TN:" << tn << std::endl;
		std::cout << "FP:" << fp << std::endl;
		std::cout << "FN:" << fn << std::endl;
		std::cout << "daichubi fp/(tn+fp):" << 1.0*fp / (tn + fp) << std::endl;
		std::cout << "kunzabi fn/(tp+fn):" << 1.0*fn / (tp + fn) << std::endl;

		
		svm.save("svm.dat", "svm");
		
	}
	~goodBadDetecctor_svm() {
		
	}
};