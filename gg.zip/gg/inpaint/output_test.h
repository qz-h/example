#pragma once
class test_moudule{
	//int selected_col[80] = { 3,4,5,6,28,29,30,31,32,33,34,35,36,37,38,53,54,55,56,57,58,59,60,61,62,63,64,65,66,78,79,80,81,82,83,84,85,86,87,88,89,90,91,92,93,104,105,106,107,108,109,110,111,112,113,114,115,116,117,129,130,131,132,133,134,135,136,137,138,139,140,141,142,143,157,158,166,167,168 };
	unsigned char predict_0(unsigned char ptr[]) {
		if (ptr[13] <= 0) {
			if (ptr[16] <= 10) {
				if (ptr[31] <= 28) {
					if (ptr[37] <= 7) {
						if (ptr[26] <= 0) {
							if (ptr[37] <= 2) {
								if (ptr[20] <= 0) {
									if (ptr[18] <= 0) {
										if (ptr[44] <= 0) {
											if (ptr[7] <= 0) {
												return 1;//short version
											}
											else {
												return 0;//short version
											}
										}
										else {
											if (ptr[55] <= 7) {
												if (ptr[42] <= 31) {
													return 0;
												}
												else {
													return 1;
												}
											}
											else {
												return 0;
											}
										}
									}
									else {
										if (ptr[8] <= 0) {
											if (ptr[27] <= 0) {
												if (ptr[7] <= 0) {
													return 1;
												}
												else {
													return 0;
												}
											}
											else {
												return 0;
											}
										}
										else {
											if (ptr[38] <= 2) {
												return 0;//short version
											}
											else {
												return 0;
											}
										}
									}
								}
								else {
									if (ptr[39] <= 0) {
										if (ptr[63] <= 0) {
											if (ptr[54] <= 2) {
												if (ptr[23] <= 2) {
													return 0;
												}
												else {
													return 1;
												}
											}
											else {
												if (ptr[43] <= 7) {
													return 1;
												}
												else {
													return 0;
												}
											}
										}
										else {
											if (ptr[54] <= 0) {
												if (ptr[38] <= 2) {
													return 0;
												}
												else {
													return 1;
												}
											}
											else {
												return 1;
											}
										}
									}
									else {
										if (ptr[27] <= 0) {
											if (ptr[11] <= 0) {
												if (ptr[44] <= 0) {
													return 1;
												}
												else {
													return 0;
												}
											}
											else {
												if (ptr[21] <= 20) {
													return 0;
												}
												else {
													return 1;
												}
											}
										}
										else {
											if (ptr[16] <= 5) {
												if (ptr[56] <= 20) {
													return 0;
												}
												else {
													return 1;
												}
											}
											else {
												return 0;
											}
										}
									}
								}
							}
							else {
								if (ptr[44] <= 0) {
									if (ptr[12] <= 2) {
										if (ptr[59] <= 0) {
											if (ptr[64] <= 5) {
												if (ptr[61] <= 0) {
													return 1;
												}
												else {
													return 0;
												}
											}
											else {
												if (ptr[53] <= 2) {
													return 0;
												}
												else {
													return 1;
												}
											}
										}
										else {
											return 0;
										}
									}
									else {
										if (ptr[69] <= 0) {
											if (ptr[22] <= 17) {
												return 0;//short version
											}
											else {
												return 1;
											}
										}
										else {
											return 0;
										}
									}
								}
								else {
									if (ptr[39] <= 24) {
										if (ptr[33] <= 5) {
											if (ptr[32] <= 2) {
												if (ptr[53] <= 10) {
													return 0;
												}
												else {
													return 1;
												}
											}
											else {
												return 0;
											}
										}
										else {
											return 1;
										}
									}
									else {
										return 1;
									}
								}
							}
						}
						else {
							if (ptr[77] <= 0) {
								if (ptr[20] <= 7) {
									if (ptr[28] <= 0) {
										if (ptr[56] <= 20) {
											if (ptr[33] <= 10) {
												return 0;//short version
											}
											else {
												return 1;
											}
										}
										else {
											return 1;
										}
									}
									else {
										if (ptr[8] <= 12) {
											if (ptr[9] <= 12) {
												if (ptr[45] <= 5) {
													return 0;
												}
												else {
													return 1;
												}
											}
											else {
												return 0;
											}
										}
										else {
											return 0;
										}
									}
								}
								else {
									if (ptr[43] <= 0) {
										if (ptr[35] <= 7) {
											if (ptr[21] <= 10) {
												return 0;
											}
											else {
												return 1;
											}
										}
										else {
											return 1;
										}
									}
									else {
										return 0;//short version
									}
								}
							}
							else {
								if (ptr[39] <= 22) {
									if (ptr[32] <= 12) {
										if (ptr[52] <= 7) {
											if (ptr[35] <= 5) {
												if (ptr[36] <= 20) {
													return 0;
												}
												else {
													return 1;
												}
											}
											else {
												return 0;//short version
											}
										}
										else {
											return 0;
										}
									}
									else {
										return 1;
									}
								}
								else {
									return 1;
								}
							}
						}
					}
					else {
						if (ptr[34] <= 5) {
							if (ptr[33] <= 2) {
								if (ptr[12] <= 0) {
									if (ptr[38] <= 10) {
										if (ptr[44] <= 0) {
											if (ptr[39] <= 10) {
												if (ptr[31] <= 2) {
													return 0;
												}
												else {
													return 1;
												}
											}
											else {
												if (ptr[71] <= 0) {
													return 1;
												}
												else {
													return 0;
												}
											}
										}
										else {
											if (ptr[27] <= 0) {
												return 0;
											}
											else {
												if (ptr[71] <= 22) {
													return 0;
												}
												else {
													return 1;
												}
											}
										}
									}
									else {
										if (ptr[27] <= 5) {
											if (ptr[77] <= 0) {
												if (ptr[11] <= 7) {
													return 1;
												}
												else {
													return 0;
												}
											}
											else {
												return 0;
											}
										}
										else {
											return 0;
										}
									}
								}
								else {
									if (ptr[50] <= 20) {
										if (ptr[21] <= 10) {
											if (ptr[6] <= 30) {
												return 0;//short version
											}
											else {
												return 1;
											}
										}
										else {
											return 0;
										}
									}
									else {
										return 1;
									}
								}
							}
							else {
								if (ptr[35] <= 12) {
									if (ptr[33] <= 10) {
										if (ptr[25] <= 2) {
											if (ptr[36] <= 5) {
												if (ptr[28] <= 2) {
													return 1;
												}
												else {
													return 0;
												}
											}
											else {
												if (ptr[68] <= 10) {
													return 1;
												}
												else {
													return 0;
												}
											}
										}
										else {
											if (ptr[38] <= 15) {
												if (ptr[20] <= 10) {
													return 0;
												}
												else {
													return 1;
												}
											}
											else {
												return 1;
											}
										}
									}
									else {
										if (ptr[61] <= 0) {
											if (ptr[12] <= 0) {
												return 1;//short version
											}
											else {
												return 0;
											}
										}
										else {
											return 0;
										}
									}
								}
								else {
									if (ptr[14] <= 2) {
										if (ptr[60] <= 0) {
											if (ptr[10] <= 2) {
												if (ptr[64] <= 16) {
													return 1;
												}
												else {
													return 0;
												}
											}
											else {
												return 1;
											}
										}
										else {
											return 0;
										}
									}
									else {
										return 0;
									}
								}
							}
						}
						else {
							if (ptr[75] <= 0) {
								if (ptr[11] <= 2) {
									if (ptr[27] <= 5) {
										if (ptr[62] <= 0) {
											if (ptr[63] <= 0) {
												return 1;//short version
											}
											else {
												if (ptr[55] <= 0) {
													return 0;
												}
												else {
													return 1;
												}
											}
										}
										else {
											if (ptr[69] <= 0) {
												return 0;
											}
											else {
												return 1;
											}
										}
									}
									else {
										return 0;
									}
								}
								else {
									if (ptr[21] <= 10) {
										if (ptr[35] <= 17) {
											if (ptr[17] <= 22) {
												return 0;//short version
											}
											else {
												return 1;
											}
										}
										else {
											return 1;
										}
									}
									else {
										return 1;
									}
								}
							}
							else {
								if (ptr[57] <= 0) {
									if (ptr[68] <= 0) {
										if (ptr[33] <= 25) {
											return 0;//short version
										}
										else {
											return 1;
										}
									}
									else {
										return 1;
									}
								}
								else {
									return 1;
								}
							}
						}
					}
				}
				else {
					if (ptr[8] <= 2) {
						if (ptr[5] <= 2) {
							if (ptr[31] <= 43) {
								if (ptr[2] <= 0) {
									if (ptr[19] <= 15) {
										if (ptr[52] <= 19) {
											if (ptr[6] <= 7) {
												return 1;//short version
											}
											else {
												return 1;
											}
										}
										else {
											return 0;
										}
									}
									else {
										return 0;
									}
								}
								else {
									return 0;
								}
							}
							else {
								if (ptr[6] <= 12) {
									if (ptr[19] <= 30) {
										if (ptr[7] <= 2) {
											if (ptr[46] <= 94) {
												return 1;//short version
											}
											else {
												return 0;
											}
										}
										else {
											return 1;
										}
									}
									else {
										return 0;
									}
								}
								else {
									return 0;
								}
							}
						}
						else {
							if (ptr[33] <= 5) {
								if (ptr[48] <= 33) {
									if (ptr[31] <= 61) {
										return 0;//short version
									}
									else {
										return 1;
									}
								}
								else {
									return 1;
								}
							}
							else {
								if (ptr[2] <= 2) {
									if (ptr[48] <= 17) {
										if (ptr[6] <= 15) {
											if (ptr[7] <= 2) {
												if (ptr[52] <= 16) {
													return 1;
												}
												else {
													return 0;
												}
											}
											else {
												return 0;
											}
										}
										else {
											return 0;
										}
									}
									else {
										return 1;
									}
								}
								else {
									return 0;
								}
							}
						}
					}
					else {
						if (ptr[38] <= 1) {
							if (ptr[3] <= 0) {
								if (ptr[16] <= 5) {
									if (ptr[19] <= 20) {
										return 0;//short version
									}
									else {
										return 0;
									}
								}
								else {
									return 0;
								}
							}
							else {
								return 0;
							}
						}
						else {
							return 1;
						}
					}
				}
			}
			else {
				if (ptr[8] <= 0) {
					if (ptr[31] <= 30) {
						if (ptr[6] <= 17) {
							if (ptr[63] <= 0) {
								if (ptr[17] <= 51) {
									if (ptr[19] <= 30) {
										if (ptr[3] <= 5) {
											if (ptr[26] <= 2) {
												return 1;//short version
											}
											else {
												return 0;
											}
										}
										else {
											return 0;
										}
									}
									else {
										return 0;
									}
								}
								else {
									if (ptr[47] <= 7) {
										if (ptr[21] <= 8) {
											if (ptr[48] <= 26) {
												if (ptr[64] <= 15) {
													return 1;
												}
												else {
													return 0;
												}
											}
											else {
												return 0;
											}
										}
										else {
											return 0;
										}
									}
									else {
										return 1;
									}
								}
							}
							else {
								if (ptr[34] <= 2) {
									if (ptr[31] <= 17) {
										return 1;
									}
									else {
										return 1;//short version
									}
								}
								else {
									if (ptr[19] <= 0) {
										return 1;
									}
									else {
										if (ptr[47] <= 28) {
											if (ptr[31] <= 17) {
												return 0;//short version
											}
											else {
												return 1;
											}
										}
										else {
											return 1;
										}
									}
								}
							}
						}
						else {
							if (ptr[2] <= 0) {
								if (ptr[16] <= 15) {
									if (ptr[37] <= 1) {
										return 0;
									}
									else {
										return 1;
									}
								}
								else {
									if (ptr[7] <= 7) {
										if (ptr[62] <= 1) {
											if (ptr[50] <= 5) {
												return 1;
											}
											else {
												return 0;
											}
										}
										else {
											return 0;
										}
									}
									else {
										return 0;
									}
								}
							}
							else {
								return 0;//short version
							}
						}
					}
					else {
						if (ptr[7] <= 2) {
							if (ptr[61] <= 2) {
								if (ptr[1] <= 7) {
									if (ptr[20] <= 2) {
										if (ptr[62] <= 10) {
											if (ptr[19] <= 7) {
												return 1;//short version
											}
											else {
												return 1;
											}
										}
										else {
											return 1;
										}
									}
									else {
										return 1;
									}
								}
								else {
									return 0;
								}
							}
							else {
								if (ptr[2] <= 1) {
									if (ptr[17] <= 1) {
										return 1;
									}
									else {
										if (ptr[62] <= 48) {
											if (ptr[62] <= 15) {
												return 1;//short version
											}
											else {
												return 1;
											}
										}
										else {
											return 0;
										}
									}
								}
								else {
									return 0;
								}
							}
						}
						else {
							if (ptr[32] <= 40) {
								if (ptr[20] <= 12) {
									if (ptr[31] <= 48) {
										return 0;
									}
									else {
										return 1;
									}
								}
								else {
									return 0;
								}
							}
							else {
								return 1;
							}
						}
					}
				}
				else {
					if (ptr[36] <= 2) {
						if (ptr[17] <= 20) {
							if (ptr[11] <= 1) {
								if (ptr[22] <= 2) {
									if (ptr[64] <= 0) {
										if (ptr[23] <= 5) {
											if (ptr[32] <= 48) {
												return 0;//short version
											}
											else {
												return 1;
											}
										}
										else {
											return 1;
										}
									}
									else {
										return 0;
									}
								}
								else {
									return 1;
								}
							}
							else {
								return 1;
							}
						}
						else {
							if (ptr[10] <= 0) {
								if (ptr[16] <= 17) {
									if (ptr[37] <= 1) {
										if (ptr[8] <= 2) {
											return 1;
										}
										else {
											if (ptr[53] <= 1) {
												return 0;//short version
											}
											else {
												return 1;
											}
										}
									}
									else {
										return 1;
									}
								}
								else {
									return 0;
								}
							}
							else {
								return 1;
							}
						}
					}
					else {
						if (ptr[63] <= 0) {
							if (ptr[37] <= 0) {
								return 0;
							}
							else {
								if (ptr[58] <= 16) {
									if (ptr[32] <= 22) {
										if (ptr[66] <= 2) {
											if (ptr[65] <= 7) {
												if (ptr[1] <= 7) {
													return 1;
												}
												else {
													return 0;
												}
											}
											else {
												return 0;
											}
										}
										else {
											return 1;
										}
									}
									else {
										return 0;
									}
								}
								else {
									return 0;
								}
							}
						}
						else {
							return 0;
						}
					}
				}
			}
		}
		else {
			if (ptr[20] <= 10) {
				if (ptr[35] <= 12) {
					if (ptr[18] <= 10) {
						if (ptr[39] <= 22) {
							if (ptr[36] <= 12) {
								if (ptr[7] <= 35) {
									if (ptr[33] <= 2) {
										if (ptr[10] <= 38) {
											if (ptr[21] <= 17) {
												if (ptr[37] <= 33) {
													return 0;
												}
												else {
													return 1;
												}
											}
											else {
												return 0;
											}
										}
										else {
											return 1;
										}
									}
									else {
										if (ptr[22] <= 28) {
											if (ptr[9] <= 30) {
												return 0;//short version
											}
											else {
												return 1;
											}
										}
										else {
											return 1;
										}
									}
								}
								else {
									return 1;
								}
							}
							else {
								if (ptr[54] <= 17) {
									if (ptr[47] <= 10) {
										if (ptr[14] <= 0) {
											return 0;//short version
										}
										else {
											if (ptr[73] <= 2) {
												if (ptr[1] <= 17) {
													return 0;
												}
												else {
													return 1;
												}
											}
											else {
												return 0;
											}
										}
									}
									else {
										return 1;
									}
								}
								else {
									return 0;
								}
							}
						}
						else {
							return 0;
						}
					}
					else {
						if (ptr[17] <= 12) {
							if (ptr[33] <= 7) {
								if (ptr[34] <= 17) {
									if (ptr[8] <= 25) {
										if (ptr[54] <= 21) {
											if (ptr[14] <= 0) {
												return 0;
											}
											else {
												if (ptr[22] <= 24) {
													return 0;
												}
												else {
													return 1;
												}
											}
										}
										else {
											return 1;
										}
									}
									else {
										return 1;
									}
								}
								else {
									return 1;
								}
							}
							else {
								return 0;
							}
						}
						else {
							return 0;
						}
					}
				}
				else {
					if (ptr[17] <= 7) {
						if (ptr[11] <= 2) {
							return 0;
						}
						else {
							return 0;//short version
						}
					}
					else {
						return 0;
					}
				}
			}
			else {
				if (ptr[21] <= 7) {
					if (ptr[34] <= 10) {
						if (ptr[18] <= 10) {
							if (ptr[39] <= 10) {
								if (ptr[40] <= 17) {
									if (ptr[16] <= 7) {
										if (ptr[30] <= 2) {
											if (ptr[5] <= 21) {
												if (ptr[6] <= 24) {
													return 0;
												}
												else {
													return 1;
												}
											}
											else {
												return 1;
											}
										}
										else {
											return 0;
										}
									}
									else {
										return 0;
									}
								}
								else {
									return 1;
								}
							}
							else {
								return 0;
							}
						}
						else {
							return 0;
						}
					}
					else {
						return 0;
					}
				}
				else {
					if (ptr[12] <= 2) {
						return 1;
					}
					else {
						if (ptr[18] <= 15) {
							return 0;//short version
						}
						else {
							return 1;
						}
					}
				}
			}
		}
	}
	unsigned char predict_1(unsigned char ptr[]) {
		if (ptr[30] <= 5) {
			if (ptr[16] <= 2) {
				if (ptr[2] <= 0) {
					if (ptr[28] <= 0) {
						if (ptr[37] <= 2) {
							if (ptr[6] <= 0) {
								if (ptr[32] <= 38) {
									if (ptr[46] <= 10) {
										if (ptr[21] <= 0) {
											if (ptr[18] <= 0) {
												if (ptr[12] <= 0) {
													return 1;
												}
												else {
													return 0;
												}
											}
											else {
												return 0;//short version
											}
										}
										else {
											if (ptr[68] <= 2) {
												return 0;//short version
											}
											else {
												return 0;
											}
										}
									}
									else {
										if (ptr[36] <= 2) {
											if (ptr[31] <= 7) {
												return 0;
											}
											else {
												if (ptr[21] <= 1) {
													return 1;
												}
												else {
													return 0;
												}
											}
										}
										else {
											return 0;
										}
									}
								}
								else {
									if (ptr[47] <= 20) {
										if (ptr[18] <= 12) {
											return 1;
										}
										else {
											return 0;
										}
									}
									else {
										return 1;
									}
								}
							}
							else {
								if (ptr[52] <= 2) {
									if (ptr[19] <= 0) {
										if (ptr[32] <= 2) {
											if (ptr[66] <= 2) {
												if (ptr[46] <= 11) {
													return 0;
												}
												else {
													return 1;
												}
											}
											else {
												return 0;
											}
										}
										else {
											if (ptr[18] <= 17) {
												return 0;//short version
											}
											else {
												return 0;
											}
										}
									}
									else {
										if (ptr[23] <= 2) {
											if (ptr[54] <= 2) {
												return 0;//short version
											}
											else {
												return 0;
											}
										}
										else {
											if (ptr[17] <= 10) {
												if (ptr[31] <= 7) {
													return 0;
												}
												else {
													return 1;
												}
											}
											else {
												return 1;
											}
										}
									}
								}
								else {
									if (ptr[77] <= 0) {
										if (ptr[69] <= 0) {
											if (ptr[17] <= 15) {
												return 0;//short version
											}
											else {
												return 1;
											}
										}
										else {
											return 0;
										}
									}
									else {
										return 1;
									}
								}
							}
						}
						else {
							if (ptr[14] <= 0) {
								if (ptr[35] <= 5) {
									if (ptr[25] <= 0) {
										if (ptr[27] <= 0) {
											if (ptr[10] <= 0) {
												return 1;//short version
											}
											else {
												if (ptr[19] <= 15) {
													return 0;
												}
												else {
													return 1;
												}
											}
										}
										else {
											return 0;
										}
									}
									else {
										if (ptr[12] <= 0) {
											if (ptr[32] <= 7) {
												return 0;//short version
											}
											else {
												return 1;
											}
										}
										else {
											if (ptr[33] <= 10) {
												return 0;//short version
											}
											else {
												return 1;
											}
										}
									}
								}
								else {
									if (ptr[39] <= 0) {
										if (ptr[38] <= 0) {
											if (ptr[34] <= 20) {
												return 0;//short version
											}
											else {
												if (ptr[62] <= 0) {
													return 1;
												}
												else {
													return 0;
												}
											}
										}
										else {
											if (ptr[10] <= 2) {
												if (ptr[12] <= 7) {
													return 1;
												}
												else {
													return 0;
												}
											}
											else {
												return 0;
											}
										}
									}
									else {
										if (ptr[25] <= 2) {
											if (ptr[44] <= 2) {
												return 1;//short version
											}
											else {
												return 0;
											}
										}
										else {
											if (ptr[34] <= 7) {
												if (ptr[12] <= 2) {
													return 1;
												}
												else {
													return 0;
												}
											}
											else {
												return 1;
											}
										}
									}
								}
							}
							else {
								if (ptr[33] <= 7) {
									if (ptr[8] <= 17) {
										if (ptr[53] <= 26) {
											if (ptr[7] <= 30) {
												return 0;//short version
											}
											else {
												return 1;
											}
										}
										else {
											return 1;
										}
									}
									else {
										return 1;
									}
								}
								else {
									return 0;
								}
							}
						}
					}
					else {
						if (ptr[32] <= 2) {
							if (ptr[18] <= 33) {
								if (ptr[34] <= 7) {
									if (ptr[38] <= 22) {
										if (ptr[36] <= 25) {
											if (ptr[37] <= 22) {
												if (ptr[8] <= 36) {
													return 0;
												}
												else {
													return 1;
												}
											}
											else {
												return 0;
											}
										}
										else {
											return 0;
										}
									}
									else {
										return 0;
									}
								}
								else {
									return 0;
								}
							}
							else {
								return 1;
							}
						}
						else {
							if (ptr[14] <= 0) {
								if (ptr[13] <= 0) {
									if (ptr[36] <= 10) {
										return 0;//short version
									}
									else {
										return 1;
									}
								}
								else {
									return 0;
								}
							}
							else {
								if (ptr[20] <= 28) {
									if (ptr[52] <= 25) {
										if (ptr[10] <= 24) {
											if (ptr[8] <= 10) {
												if (ptr[31] <= 16) {
													return 0;
												}
												else {
													return 1;
												}
											}
											else {
												return 0;
											}
										}
										else {
											return 1;
										}
									}
									else {
										return 1;
									}
								}
								else {
									return 1;
								}
							}
						}
					}
				}
				else {
					if (ptr[27] <= 0) {
						if (ptr[62] <= 0) {
							if (ptr[35] <= 5) {
								if (ptr[36] <= 5) {
									if (ptr[28] <= 0) {
										if (ptr[51] <= 5) {
											if (ptr[43] <= 5) {
												return 0;//short version
											}
											else {
												if (ptr[39] <= 22) {
													return 0;
												}
												else {
													return 1;
												}
											}
										}
										else {
											return 0;
										}
									}
									else {
										if (ptr[19] <= 33) {
											if (ptr[47] <= 14) {
												return 0;//short version
											}
											else {
												return 1;
											}
										}
										else {
											return 1;
										}
									}
								}
								else {
									if (ptr[12] <= 0) {
										if (ptr[25] <= 5) {
											if (ptr[55] <= 5) {
												if (ptr[21] <= 25) {
													return 0;
												}
												else {
													return 1;
												}
											}
											else {
												return 1;
											}
										}
										else {
											return 0;
										}
									}
									else {
										if (ptr[78] <= 2) {
											if (ptr[33] <= 15) {
												return 0;//short version
											}
											else {
												return 1;
											}
										}
										else {
											return 0;
										}
									}
								}
							}
							else {
								if (ptr[11] <= 5) {
									if (ptr[38] <= 0) {
										if (ptr[55] <= 0) {
											if (ptr[69] <= 2) {
												return 0;//short version
											}
											else {
												return 1;
											}
										}
										else {
											return 1;
										}
									}
									else {
										if (ptr[13] <= 0) {
											if (ptr[10] <= 7) {
												return 1;//short version
											}
											else {
												return 0;
											}
										}
										else {
											return 0;
										}
									}
								}
								else {
									if (ptr[14] <= 0) {
										return 0;//short version
									}
									else {
										return 0;
									}
								}
							}
						}
						else {
							if (ptr[77] <= 2) {
								if (ptr[70] <= 0) {
									if (ptr[67] <= 2) {
										if (ptr[55] <= 12) {
											if (ptr[58] <= 10) {
												return 0;//short version
											}
											else {
												return 1;
											}
										}
										else {
											return 1;
										}
									}
									else {
										return 0;
									}
								}
								else {
									return 0;
								}
							}
							else {
								return 0;
							}
						}
					}
					else {
						if (ptr[33] <= 7) {
							if (ptr[20] <= 2) {
								if (ptr[50] <= 5) {
									if (ptr[38] <= 15) {
										if (ptr[17] <= 38) {
											if (ptr[5] <= 19) {
												if (ptr[29] <= 0) {
													return 0;
												}
												else {
													return 1;
												}
											}
											else {
												return 1;
											}
										}
										else {
											return 1;
										}
									}
									else {
										return 0;
									}
								}
								else {
									return 0;
								}
							}
							else {
								if (ptr[37] <= 10) {
									if (ptr[18] <= 15) {
										if (ptr[9] <= 7) {
											if (ptr[6] <= 33) {
												if (ptr[17] <= 33) {
													return 0;
												}
												else {
													return 1;
												}
											}
											else {
												return 1;
											}
										}
										else {
											return 0;
										}
									}
									else {
										return 1;
									}
								}
								else {
									return 0;//short version
								}
							}
						}
						else {
							return 0;//short version
						}
					}
				}
			}
			else {
				if (ptr[31] <= 30) {
					if (ptr[48] <= 0) {
						if (ptr[13] <= 0) {
							if (ptr[37] <= 2) {
								if (ptr[8] <= 0) {
									if (ptr[62] <= 0) {
										if (ptr[2] <= 0) {
											if (ptr[16] <= 12) {
												return 0;//short version
											}
											else {
												if (ptr[26] <= 2) {
													return 1;
												}
												else {
													return 0;
												}
											}
										}
										else {
											if (ptr[22] <= 5) {
												if (ptr[35] <= 20) {
													return 0;
												}
												else {
													return 1;
												}
											}
											else {
												return 1;
											}
										}
									}
									else {
										if (ptr[70] <= 0) {
											if (ptr[35] <= 0) {
												return 0;
											}
											else {
												if (ptr[68] <= 1) {
													return 0;
												}
												else {
													return 1;
												}
											}
										}
										else {
											return 1;
										}
									}
								}
								else {
									if (ptr[62] <= 0) {
										if (ptr[38] <= 2) {
											if (ptr[10] <= 2) {
												return 0;//short version
											}
											else {
												if (ptr[12] <= 7) {
													return 1;
												}
												else {
													return 0;
												}
											}
										}
										else {
											return 0;//short version
										}
									}
									else {
										if (ptr[58] <= 2) {
											if (ptr[16] <= 20) {
												if (ptr[39] <= 5) {
													return 0;
												}
												else {
													return 1;
												}
											}
											else {
												return 1;
											}
										}
										else {
											return 1;
										}
									}
								}
							}
							else {
								if (ptr[14] <= 0) {
									if (ptr[12] <= 0) {
										if (ptr[43] <= 0) {
											if (ptr[11] <= 2) {
												if (ptr[28] <= 2) {
													return 1;
												}
												else {
													return 0;
												}
											}
											else {
												if (ptr[67] <= 2) {
													return 1;
												}
												else {
													return 0;
												}
											}
										}
										else {
											if (ptr[37] <= 12) {
												return 0;//short version
											}
											else {
												return 1;
											}
										}
									}
									else {
										if (ptr[17] <= 7) {
											if (ptr[21] <= 12) {
												return 0;//short version
											}
											else {
												return 0;
											}
										}
										else {
											return 1;
										}
									}
								}
								else {
									if (ptr[27] <= 5) {
										if (ptr[23] <= 21) {
											if (ptr[19] <= 12) {
												return 0;
											}
											else {
												return 1;
											}
										}
										else {
											return 1;
										}
									}
									else {
										return 0;
									}
								}
							}
						}
						else {
							if (ptr[19] <= 17) {
								if (ptr[14] <= 0) {
									if (ptr[17] <= 15) {
										if (ptr[21] <= 22) {
											if (ptr[26] <= 0) {
												if (ptr[33] <= 7) {
													return 0;
												}
												else {
													return 1;
												}
											}
											else {
												if (ptr[33] <= 15) {
													return 0;
												}
												else {
													return 1;
												}
											}
										}
										else {
											return 1;
										}
									}
									else {
										return 0;
									}
								}
								else {
									if (ptr[17] <= 28) {
										if (ptr[22] <= 17) {
											if (ptr[20] <= 28) {
												if (ptr[57] <= 16) {
													return 0;
												}
												else {
													return 1;
												}
											}
											else {
												return 1;
											}
										}
										else {
											return 0;
										}
									}
									else {
										return 1;
									}
								}
							}
							else {
								return 1;
							}
						}
					}
					else {
						if (ptr[20] <= 2) {
							if (ptr[8] <= 0) {
								if (ptr[7] <= 0) {
									if (ptr[19] <= 0) {
										if (ptr[40] <= 0) {
											if (ptr[2] <= 5) {
												return 1;//short version
											}
											else {
												return 0;
											}
										}
										else {
											return 0;
										}
									}
									else {
										if (ptr[75] <= 0) {
											if (ptr[32] <= 17) {
												if (ptr[37] <= 17) {
													return 0;
												}
												else {
													return 1;
												}
											}
											else {
												return 1;//short version
											}
										}
										else {
											if (ptr[31] <= 15) {
												return 0;
											}
											else {
												return 1;
											}
										}
									}
								}
								else {
									if (ptr[7] <= 7) {
										if (ptr[75] <= 5) {
											if (ptr[17] <= 30) {
												if (ptr[66] <= 2) {
													return 0;
												}
												else {
													return 1;
												}
											}
											else {
												return 1;
											}
										}
										else {
											return 0;
										}
									}
									else {
										if (ptr[36] <= 7) {
											if (ptr[2] <= 0) {
												return 0;//short version
											}
											else {
												return 0;
											}
										}
										else {
											return 0;
										}
									}
								}
							}
							else {
								if (ptr[36] <= 10) {
									if (ptr[38] <= 2) {
										if (ptr[76] <= 5) {
											if (ptr[48] <= 38) {
												if (ptr[69] <= 12) {
													return 0;
												}
												else {
													return 1;
												}
											}
											else {
												return 0;
											}
										}
										else {
											return 1;
										}
									}
									else {
										return 0;
									}
								}
								else {
									return 1;
								}
							}
						}
						else {
							if (ptr[52] <= 0) {
								if (ptr[23] <= 2) {
									if (ptr[38] <= 0) {
										if (ptr[37] <= 7) {
											if (ptr[53] <= 5) {
												return 0;//short version
											}
											else {
												return 1;
											}
										}
										else {
											return 0;
										}
									}
									else {
										return 1;
									}
								}
								else {
									if (ptr[14] <= 0) {
										return 1;
									}
									else {
										return 0;
									}
								}
							}
							else {
								if (ptr[54] <= 0) {
									if (ptr[64] <= 0) {
										return 0;//short version
									}
									else {
										return 0;
									}
								}
								else {
									if (ptr[25] <= 2) {
										if (ptr[2] <= 5) {
											if (ptr[66] <= 7) {
												return 1;
											}
											else {
												return 0;
											}
										}
										else {
											return 0;
										}
									}
									else {
										return 0;
									}
								}
							}
						}
					}
				}
				else {
					if (ptr[2] <= 2) {
						if (ptr[6] <= 0) {
							if (ptr[34] <= 10) {
								if (ptr[35] <= 2) {
									if (ptr[33] <= 22) {
										if (ptr[32] <= 38) {
											if (ptr[60] <= 29) {
												if (ptr[46] <= 44) {
													return 1;
												}
												else {
													return 0;
												}
											}
											else {
												return 0;
											}
										}
										else {
											return 1;//short version
										}
									}
									else {
										if (ptr[8] <= 6) {
											if (ptr[19] <= 38) {
												return 1;//short version
											}
											else {
												return 0;
											}
										}
										else {
											return 0;
										}
									}
								}
								else {
									return 0;
								}
							}
							else {
								return 1;
							}
						}
						else {
							if (ptr[62] <= 20) {
								if (ptr[19] <= 7) {
									if (ptr[33] <= 17) {
										if (ptr[17] <= 76) {
											if (ptr[9] <= 0) {
												if (ptr[8] <= 5) {
													return 1;
												}
												else {
													return 0;
												}
											}
											else {
												return 0;
											}
										}
										else {
											return 1;
										}
									}
									else {
										return 1;
									}
								}
								else {
									return 0;//short version
								}
							}
							else {
								return 0;
							}
						}
					}
					else {
						return 0;
					}
				}
			}
		}
		else {
			if (ptr[9] <= 0) {
				if (ptr[7] <= 0) {
					if (ptr[8] <= 0) {
						if (ptr[31] <= 17) {
							if (ptr[31] <= 5) {
								if (ptr[63] <= 0) {
									if (ptr[14] <= 0) {
										if (ptr[51] <= 24) {
											if (ptr[72] <= 0) {
												if (ptr[10] <= 0) {
													return 1;
												}
												else {
													return 0;
												}
											}
											else {
												return 0;
											}
										}
										else {
											return 0;
										}
									}
									else {
										return 0;
									}
								}
								else {
									return 0;
								}
							}
							else {
								if (ptr[48] <= 12) {
									if (ptr[55] <= 7) {
										if (ptr[2] <= 24) {
											if (ptr[37] <= 15) {
												if (ptr[20] <= 0) {
													return 1;
												}
												else {
													return 0;
												}
											}
											else {
												return 1;
											}
										}
										else {
											return 0;
										}
									}
									else {
										return 1;
									}
								}
								else {
									if (ptr[17] <= 48) {
										if (ptr[20] <= 0) {
											if (ptr[34] <= 20) {
												return 1;//short version
											}
											else {
												return 1;
											}
										}
										else {
											return 1;
										}
									}
									else {
										return 0;
									}
								}
							}
						}
						else {
							if (ptr[51] <= 7) {
								if (ptr[2] <= 7) {
									if (ptr[31] <= 38) {
										if (ptr[34] <= 15) {
											if (ptr[5] <= 0) {
												if (ptr[20] <= 25) {
													return 1;
												}
												else {
													return 0;
												}
											}
											else {
												if (ptr[35] <= 10) {
													return 1;
												}
												else {
													return 0;
												}
											}
										}
										else {
											if (ptr[61] <= 15) {
												if (ptr[20] <= 15) {
													return 1;
												}
												else {
													return 0;
												}
											}
											else {
												return 0;
											}
										}
									}
									else {
										if (ptr[1] <= 7) {
											if (ptr[32] <= 17) {
												if (ptr[2] <= 1) {
													return 1;
												}
												else {
													return 0;
												}
											}
											else {
												return 1;//short version
											}
										}
										else {
											return 0;
										}
									}
								}
								else {
									return 0;
								}
							}
							else {
								return 1;
							}
						}
					}
					else {
						if (ptr[54] <= 2) {
							if (ptr[53] <= 5) {
								if (ptr[30] <= 17) {
									if (ptr[34] <= 40) {
										if (ptr[31] <= 30) {
											return 0;//short version
										}
										else {
											return 1;
										}
									}
									else {
										return 1;
									}
								}
								else {
									return 1;
								}
							}
							else {
								return 1;
							}
						}
						else {
							return 1;
						}
					}
				}
				else {
					if (ptr[8] <= 0) {
						if (ptr[37] <= 2) {
							if (ptr[31] <= 28) {
								if (ptr[52] <= 0) {
									if (ptr[17] <= 25) {
										if (ptr[66] <= 2) {
											if (ptr[5] <= 33) {
												return 0;//short version
											}
											else {
												return 1;
											}
										}
										else {
											return 1;
										}
									}
									else {
										if (ptr[16] <= 12) {
											return 0;
										}
										else {
											return 1;
										}
									}
								}
								else {
									return 1;
								}
							}
							else {
								if (ptr[16] <= 5) {
									if (ptr[18] <= 10) {
										return 1;
									}
									else {
										return 0;
									}
								}
								else {
									if (ptr[34] <= 2) {
										return 1;//short version
									}
									else {
										return 0;
									}
								}
							}
						}
						else {
							return 1;//short version
						}
					}
					else {
						if (ptr[54] <= 2) {
							if (ptr[53] <= 0) {
								if (ptr[37] <= 2) {
									if (ptr[7] <= 25) {
										if (ptr[19] <= 15) {
											return 0;//short version
										}
										else {
											if (ptr[35] <= 7) {
												if (ptr[10] <= 3) {
													return 0;
												}
												else {
													return 1;
												}
											}
											else {
												return 0;
											}
										}
									}
									else {
										if (ptr[40] <= 1) {
											if (ptr[16] <= 22) {
												return 0;//short version
											}
											else {
												return 1;
											}
										}
										else {
											return 1;
										}
									}
								}
								else {
									return 1;
								}
							}
							else {
								return 0;
							}
						}
						else {
							return 1;
						}
					}
				}
			}
			else {
				if (ptr[23] <= 2) {
					if (ptr[52] <= 0) {
						if (ptr[55] <= 10) {
							if (ptr[31] <= 35) {
								if (ptr[37] <= 5) {
									if (ptr[32] <= 35) {
										if (ptr[17] <= 51) {
											if (ptr[45] <= 11) {
												if (ptr[47] <= 30) {
													return 0;
												}
												else {
													return 1;
												}
											}
											else {
												return 1;
											}
										}
										else {
											return 1;
										}
									}
									else {
										return 0;
									}
								}
								else {
									return 1;
								}
							}
							else {
								return 0;
							}
						}
						else {
							return 1;
						}
					}
					else {
						return 0;
					}
				}
				else {
					if (ptr[33] <= 5) {
						return 0;//short version
					}
					else {
						return 1;
					}
				}
			}
		}
	}
	unsigned char predict_2(unsigned char ptr[]) {
		if (ptr[28] <= 0) {
			if (ptr[31] <= 30) {
				if (ptr[38] <= 2) {
					if (ptr[31] <= 12) {
						if (ptr[68] <= 2) {
							if (ptr[37] <= 2) {
								if (ptr[17] <= 28) {
									if (ptr[64] <= 0) {
										if (ptr[14] <= 0) {
											if (ptr[62] <= 0) {
												return 0;//short version
											}
											else {
												return 0;//short version
											}
										}
										else {
											if (ptr[23] <= 15) {
												if (ptr[19] <= 17) {
													return 0;
												}
												else {
													return 1;
												}
											}
											else {
												return 0;
											}
										}
									}
									else {
										if (ptr[20] <= 0) {
											if (ptr[8] <= 0) {
												return 0;//short version
											}
											else {
												if (ptr[54] <= 15) {
													return 0;
												}
												else {
													return 1;
												}
											}
										}
										else {
											if (ptr[70] <= 5) {
												return 0;//short version
											}
											else {
												return 0;
											}
										}
									}
								}
								else {
									if (ptr[17] <= 66) {
										if (ptr[46] <= 0) {
											if (ptr[47] <= 0) {
												if (ptr[33] <= 20) {
													return 0;
												}
												else {
													return 1;
												}
											}
											else {
												return 0;//short version
											}
										}
										else {
											if (ptr[16] <= 17) {
												return 0;//short version
											}
											else {
												return 1;
											}
										}
									}
									else {
										return 1;
									}
								}
							}
							else {
								if (ptr[26] <= 0) {
									if (ptr[75] <= 0) {
										if (ptr[12] <= 0) {
											if (ptr[48] <= 0) {
												if (ptr[64] <= 5) {
													return 1;
												}
												else {
													return 0;
												}
											}
											else {
												if (ptr[53] <= 0) {
													return 0;
												}
												else {
													return 1;
												}
											}
										}
										else {
											if (ptr[34] <= 5) {
												if (ptr[22] <= 35) {
													return 0;
												}
												else {
													return 1;
												}
											}
											else {
												return 0;//short version
											}
										}
									}
									else {
										if (ptr[76] <= 10) {
											if (ptr[18] <= 34) {
												if (ptr[55] <= 0) {
													return 0;
												}
												else {
													return 1;
												}
											}
											else {
												return 1;
											}
										}
										else {
											return 1;
										}
									}
								}
								else {
									if (ptr[20] <= 15) {
										if (ptr[34] <= 12) {
											if (ptr[17] <= 20) {
												return 0;//short version
											}
											else {
												return 1;
											}
										}
										else {
											return 1;
										}
									}
									else {
										return 0;
									}
								}
							}
						}
						else {
							if (ptr[25] <= 0) {
								if (ptr[12] <= 0) {
									if (ptr[34] <= 5) {
										if (ptr[22] <= 0) {
											if (ptr[41] <= 2) {
												return 1;//short version
											}
											else {
												return 0;
											}
										}
										else {
											if (ptr[51] <= 0) {
												return 0;
											}
											else {
												return 1;
											}
										}
									}
									else {
										if (ptr[11] <= 2) {
											if (ptr[14] <= 0) {
												return 1;//short version
											}
											else {
												return 0;
											}
										}
										else {
											return 0;
										}
									}
								}
								else {
									return 0;
								}
							}
							else {
								if (ptr[24] <= 0) {
									return 0;//short version
								}
								else {
									if (ptr[51] <= 5) {
										if (ptr[68] <= 22) {
											if (ptr[36] <= 25) {
												if (ptr[16] <= 14) {
													return 0;
												}
												else {
													return 1;
												}
											}
											else {
												return 1;
											}
										}
										else {
											return 1;
										}
									}
									else {
										return 0;
									}
								}
							}
						}
					}
					else {
						if (ptr[2] <= 0) {
							if (ptr[7] <= 0) {
								if (ptr[8] <= 0) {
									if (ptr[34] <= 7) {
										if (ptr[21] <= 0) {
											if (ptr[17] <= 12) {
												if (ptr[60] <= 28) {
													return 1;
												}
												else {
													return 0;
												}
											}
											else {
												return 1;//short version
											}
										}
										else {
											return 0;
										}
									}
									else {
										if (ptr[19] <= 5) {
											if (ptr[33] <= 22) {
												if (ptr[20] <= 0) {
													return 1;
												}
												else {
													return 0;
												}
											}
											else {
												if (ptr[65] <= 20) {
													return 1;
												}
												else {
													return 0;
												}
											}
										}
										else {
											if (ptr[64] <= 0) {
												if (ptr[48] <= 0) {
													return 1;
												}
												else {
													return 0;
												}
											}
											else {
												return 0;//short version
											}
										}
									}
								}
								else {
									if (ptr[48] <= 0) {
										return 0;
									}
									else {
										if (ptr[48] <= 45) {
											if (ptr[66] <= 5) {
												return 0;//short version
											}
											else {
												return 1;
											}
										}
										else {
											return 1;
										}
									}
								}
							}
							else {
								if (ptr[37] <= 0) {
									if (ptr[17] <= 33) {
										if (ptr[7] <= 7) {
											if (ptr[30] <= 5) {
												if (ptr[53] <= 1) {
													return 0;
												}
												else {
													return 1;
												}
											}
											else {
												if (ptr[48] <= 20) {
													return 0;
												}
												else {
													return 1;
												}
											}
										}
										else {
											if (ptr[53] <= 1) {
												if (ptr[23] <= 2) {
													return 0;
												}
												else {
													return 1;
												}
											}
											else {
												return 1;
											}
										}
									}
									else {
										if (ptr[7] <= 15) {
											if (ptr[19] <= 20) {
												if (ptr[6] <= 30) {
													return 1;
												}
												else {
													return 0;
												}
											}
											else {
												return 0;
											}
										}
										else {
											return 0;//short version
										}
									}
								}
								else {
									return 1;
								}
							}
						}
						else {
							if (ptr[53] <= 0) {
								if (ptr[7] <= 17) {
									if (ptr[37] <= 2) {
										if (ptr[18] <= 71) {
											if (ptr[10] <= 12) {
												if (ptr[17] <= 58) {
													return 0;
												}
												else {
													return 1;
												}
											}
											else {
												return 1;
											}
										}
										else {
											return 1;
										}
									}
									else {
										return 1;
									}
								}
								else {
									if (ptr[11] <= 1) {
										if (ptr[26] <= 2) {
											if (ptr[16] <= 20) {
												if (ptr[18] <= 58) {
													return 0;
												}
												else {
													return 1;
												}
											}
											else {
												return 0;
											}
										}
										else {
											return 1;
										}
									}
									else {
										return 1;
									}
								}
							}
							else {
								return 1;
							}
						}
					}
				}
				else {
					if (ptr[13] <= 0) {
						if (ptr[14] <= 0) {
							if (ptr[33] <= 5) {
								if (ptr[32] <= 0) {
									if (ptr[12] <= 0) {
										if (ptr[78] <= 0) {
											if (ptr[20] <= 12) {
												if (ptr[10] <= 2) {
													return 1;
												}
												else {
													return 0;
												}
											}
											else {
												return 1;//short version
											}
										}
										else {
											if (ptr[31] <= 2) {
												return 0;//short version
											}
											else {
												return 0;
											}
										}
									}
									else {
										if (ptr[8] <= 15) {
											if (ptr[34] <= 10) {
												if (ptr[74] <= 1) {
													return 0;
												}
												else {
													return 1;
												}
											}
											else {
												return 0;
											}
										}
										else {
											return 1;
										}
									}
								}
								else {
									if (ptr[12] <= 0) {
										if (ptr[26] <= 0) {
											if (ptr[68] <= 2) {
												return 1;//short version
											}
											else {
												if (ptr[23] <= 5) {
													return 1;
												}
												else {
													return 0;
												}
											}
										}
										else {
											if (ptr[31] <= 0) {
												return 0;
											}
											else {
												return 1;//short version
											}
										}
									}
									else {
										if (ptr[35] <= 15) {
											if (ptr[19] <= 10) {
												return 0;//short version
											}
											else {
												return 1;
											}
										}
										else {
											return 1;
										}
									}
								}
							}
							else {
								if (ptr[10] <= 2) {
									if (ptr[44] <= 5) {
										if (ptr[27] <= 0) {
											if (ptr[64] <= 10) {
												return 1;//short version
											}
											else {
												return 0;
											}
										}
										else {
											return 1;
										}
									}
									else {
										return 0;
									}
								}
								else {
									if (ptr[34] <= 5) {
										if (ptr[69] <= 2) {
											if (ptr[16] <= 0) {
												return 0;
											}
											else {
												return 1;
											}
										}
										else {
											return 0;
										}
									}
									else {
										if (ptr[43] <= 5) {
											if (ptr[11] <= 5) {
												return 1;//short version
											}
											else {
												return 1;
											}
										}
										else {
											return 0;
										}
									}
								}
							}
						}
						else {
							if (ptr[36] <= 15) {
								if (ptr[20] <= 2) {
									if (ptr[34] <= 5) {
										if (ptr[57] <= 15) {
											if (ptr[51] <= 5) {
												return 0;//short version
											}
											else {
												return 0;
											}
										}
										else {
											return 1;
										}
									}
									else {
										return 0;
									}
								}
								else {
									if (ptr[35] <= 7) {
										if (ptr[39] <= 15) {
											return 0;//short version
										}
										else {
											return 0;
										}
									}
									else {
										return 0;
									}
								}
							}
							else {
								return 0;
							}
						}
					}
					else {
						if (ptr[18] <= 12) {
							if (ptr[36] <= 7) {
								if (ptr[32] <= 7) {
									if (ptr[7] <= 39) {
										if (ptr[26] <= 0) {
											if (ptr[34] <= 12) {
												return 0;//short version
											}
											else {
												return 1;
											}
										}
										else {
											if (ptr[21] <= 10) {
												return 0;//short version
											}
											else {
												return 0;
											}
										}
									}
									else {
										return 1;
									}
								}
								else {
									return 0;
								}
							}
							else {
								if (ptr[11] <= 2) {
									if (ptr[25] <= 5) {
										return 0;
									}
									else {
										return 0;//short version
									}
								}
								else {
									if (ptr[56] <= 12) {
										if (ptr[65] <= 5) {
											if (ptr[16] <= 15) {
												if (ptr[73] <= 17) {
													return 0;
												}
												else {
													return 1;
												}
											}
											else {
												return 1;
											}
										}
										else {
											return 1;
										}
									}
									else {
										return 1;
									}
								}
							}
						}
						else {
							return 0;
						}
					}
				}
			}
			else {
				if (ptr[19] <= 2) {
					if (ptr[6] <= 7) {
						if (ptr[2] <= 0) {
							if (ptr[74] <= 5) {
								if (ptr[61] <= 15) {
									if (ptr[7] <= 7) {
										if (ptr[67] <= 1) {
											if (ptr[60] <= 20) {
												if (ptr[51] <= 19) {
													return 1;
												}
												else {
													return 0;
												}
											}
											else {
												return 1;
											}
										}
										else {
											return 0;
										}
									}
									else {
										return 1;
									}
								}
								else {
									if (ptr[5] <= 2) {
										return 1;//short version
									}
									else {
										return 0;
									}
								}
							}
							else {
								if (ptr[31] <= 61) {
									if (ptr[31] <= 35) {
										return 1;
									}
									else {
										return 1;//short version
									}
								}
								else {
									return 1;
								}
							}
						}
						else {
							return 0;
						}
					}
					else {
						if (ptr[61] <= 7) {
							if (ptr[7] <= 7) {
								if (ptr[16] <= 12) {
									if (ptr[2] <= 2) {
										if (ptr[20] <= 2) {
											if (ptr[6] <= 28) {
												return 1;
											}
											else {
												return 0;
											}
										}
										else {
											return 0;
										}
									}
									else {
										return 0;
									}
								}
								else {
									if (ptr[75] <= 1) {
										if (ptr[2] <= 2) {
											if (ptr[1] <= 12) {
												return 1;//short version
											}
											else {
												return 0;
											}
										}
										else {
											return 0;
										}
									}
									else {
										return 0;
									}
								}
							}
							else {
								return 0;
							}
						}
						else {
							return 0;
						}
					}
				}
				else {
					if (ptr[6] <= 7) {
						if (ptr[20] <= 2) {
							if (ptr[8] <= 2) {
								if (ptr[36] <= 12) {
									if (ptr[19] <= 28) {
										if (ptr[16] <= 5) {
											return 1;//short version
										}
										else {
											if (ptr[49] <= 22) {
												return 1;//short version
											}
											else {
												return 1;
											}
										}
									}
									else {
										return 0;
									}
								}
								else {
									return 0;
								}
							}
							else {
								return 0;
							}
						}
						else {
							if (ptr[19] <= 20) {
								if (ptr[2] <= 0) {
									if (ptr[47] <= 17) {
										if (ptr[9] <= 0) {
											return 1;
										}
										else {
											return 0;
										}
									}
									else {
										return 1;
									}
								}
								else {
									return 0;
								}
							}
							else {
								return 0;
							}
						}
					}
					else {
						if (ptr[33] <= 10) {
							if (ptr[18] <= 61) {
								if (ptr[16] <= 17) {
									if (ptr[8] <= 0) {
										return 0;//short version
									}
									else {
										if (ptr[17] <= 1) {
											return 1;
										}
										else {
											return 0;//short version
										}
									}
								}
								else {
									return 0;
								}
							}
							else {
								return 1;
							}
						}
						else {
							if (ptr[16] <= 20) {
								if (ptr[7] <= 0) {
									return 1;
								}
								else {
									return 0;//short version
								}
							}
							else {
								return 1;
							}
						}
					}
				}
			}
		}
		else {
			if (ptr[34] <= 7) {
				if (ptr[37] <= 15) {
					if (ptr[35] <= 7) {
						if (ptr[20] <= 12) {
							if (ptr[19] <= 2) {
								if (ptr[27] <= 0) {
									if (ptr[58] <= 19) {
										if (ptr[8] <= 34) {
											if (ptr[41] <= 17) {
												if (ptr[22] <= 20) {
													return 0;
												}
												else {
													return 1;
												}
											}
											else {
												return 0;
											}
										}
										else {
											return 1;
										}
									}
									else {
										return 1;
									}
								}
								else {
									if (ptr[17] <= 38) {
										if (ptr[15] <= 2) {
											if (ptr[52] <= 15) {
												if (ptr[16] <= 15) {
													return 0;
												}
												else {
													return 1;
												}
											}
											else {
												return 0;
											}
										}
										else {
											return 1;
										}
									}
									else {
										return 1;
									}
								}
							}
							else {
								if (ptr[22] <= 22) {
									if (ptr[56] <= 30) {
										if (ptr[59] <= 2) {
											if (ptr[31] <= 2) {
												if (ptr[5] <= 12) {
													return 0;
												}
												else {
													return 1;
												}
											}
											else {
												return 0;//short version
											}
										}
										else {
											return 1;
										}
									}
									else {
										return 1;
									}
								}
								else {
									return 1;
								}
							}
						}
						else {
							return 0;//short version
						}
					}
					else {
						if (ptr[7] <= 12) {
							if (ptr[36] <= 25) {
								if (ptr[18] <= 15) {
									if (ptr[20] <= 25) {
										if (ptr[33] <= 7) {
											if (ptr[17] <= 7) {
												return 0;//short version
											}
											else {
												return 0;
											}
										}
										else {
											return 0;
										}
									}
									else {
										return 1;
									}
								}
								else {
									return 1;
								}
							}
							else {
								return 1;
							}
						}
						else {
							return 1;
						}
					}
				}
				else {
					if (ptr[33] <= 10) {
						if (ptr[35] <= 10) {
							if (ptr[37] <= 22) {
								if (ptr[22] <= 20) {
									if (ptr[38] <= 20) {
										return 0;//short version
									}
									else {
										return 1;
									}
								}
								else {
									return 1;
								}
							}
							else {
								return 0;
							}
						}
						else {
							return 0;
						}
					}
					else {
						return 1;
					}
				}
			}
			else {
				if (ptr[13] <= 0) {
					if (ptr[18] <= 5) {
						if (ptr[36] <= 12) {
							if (ptr[22] <= 21) {
								if (ptr[37] <= 20) {
									if (ptr[62] <= 10) {
										return 0;//short version
									}
									else {
										return 1;
									}
								}
								else {
									return 1;
								}
							}
							else {
								return 1;
							}
						}
						else {
							return 1;
						}
					}
					else {
						return 0;
					}
				}
				else {
					if (ptr[5] <= 12) {
						if (ptr[67] <= 5) {
							if (ptr[33] <= 10) {
								if (ptr[58] <= 10) {
									if (ptr[6] <= 15) {
										if (ptr[21] <= 10) {
											if (ptr[63] <= 2) {
												if (ptr[17] <= 22) {
													return 0;
												}
												else {
													return 1;
												}
											}
											else {
												return 1;
											}
										}
										else {
											return 0;
										}
									}
									else {
										return 0;
									}
								}
								else {
									return 1;
								}
							}
							else {
								return 0;
							}
						}
						else {
							return 1;
						}
					}
					else {
						return 1;
					}
				}
			}
		}
	}
	unsigned char predict_3(unsigned char ptr[]) {
		if (ptr[27] <= 0) {
			if (ptr[30] <= 5) {
				if (ptr[38] <= 2) {
					if (ptr[7] <= 0) {
						if (ptr[21] <= 0) {
							if (ptr[32] <= 28) {
								if (ptr[14] <= 0) {
									if (ptr[17] <= 53) {
										if (ptr[53] <= 2) {
											if (ptr[47] <= 12) {
												return 0;//short version
											}
											else {
												if (ptr[18] <= 2) {
													return 1;
												}
												else {
													return 0;
												}
											}
										}
										else {
											if (ptr[26] <= 2) {
												if (ptr[63] <= 0) {
													return 1;
												}
												else {
													return 0;
												}
											}
											else {
												return 0;
											}
										}
									}
									else {
										if (ptr[62] <= 1) {
											if (ptr[6] <= 86) {
												return 1;//short version
											}
											else {
												return 0;
											}
										}
										else {
											return 0;
										}
									}
								}
								else {
									return 0;//short version
								}
							}
							else {
								if (ptr[19] <= 7) {
									if (ptr[16] <= 5) {
										if (ptr[1] <= 2) {
											if (ptr[8] <= 2) {
												return 1;//short version
											}
											else {
												return 0;
											}
										}
										else {
											return 0;
										}
									}
									else {
										if (ptr[2] <= 1) {
											if (ptr[6] <= 12) {
												if (ptr[52] <= 7) {
													return 1;
												}
												else {
													return 0;
												}
											}
											else {
												return 1;
											}
										}
										else {
											return 0;
										}
									}
								}
								else {
									if (ptr[49] <= 2) {
										if (ptr[63] <= 2) {
											return 1;//short version
										}
										else {
											return 0;
										}
									}
									else {
										if (ptr[17] <= 35) {
											return 0;
										}
										else {
											return 1;
										}
									}
								}
							}
						}
						else {
							if (ptr[39] <= 0) {
								if (ptr[48] <= 0) {
									if (ptr[65] <= 0) {
										if (ptr[17] <= 15) {
											if (ptr[61] <= 0) {
												if (ptr[36] <= 12) {
													return 0;
												}
												else {
													return 1;
												}
											}
											else {
												return 0;
											}
										}
										else {
											if (ptr[46] <= 0) {
												return 1;//short version
											}
											else {
												return 0;
											}
										}
									}
									else {
										if (ptr[69] <= 0) {
											if (ptr[54] <= 0) {
												if (ptr[68] <= 2) {
													return 0;
												}
												else {
													return 1;
												}
											}
											else {
												return 1;
											}
										}
										else {
											return 1;
										}
									}
								}
								else {
									if (ptr[17] <= 30) {
										if (ptr[77] <= 2) {
											if (ptr[68] <= 2) {
												if (ptr[49] <= 30) {
													return 0;
												}
												else {
													return 1;
												}
											}
											else {
												return 1;
											}
										}
										else {
											return 1;
										}
									}
									else {
										return 1;
									}
								}
							}
							else {
								if (ptr[25] <= 0) {
									if (ptr[44] <= 0) {
										if (ptr[34] <= 12) {
											if (ptr[12] <= 2) {
												if (ptr[2] <= 5) {
													return 1;
												}
												else {
													return 0;
												}
											}
											else {
												return 0;
											}
										}
										else {
											return 1;
										}
									}
									else {
										return 0;
									}
								}
								else {
									if (ptr[19] <= 7) {
										if (ptr[33] <= 7) {
											if (ptr[35] <= 5) {
												return 0;//short version
											}
											else {
												return 0;
											}
										}
										else {
											return 0;
										}
									}
									else {
										return 0;
									}
								}
							}
						}
					}
					else {
						if (ptr[53] <= 2) {
							if (ptr[37] <= 2) {
								if (ptr[63] <= 0) {
									if (ptr[17] <= 38) {
										if (ptr[22] <= 2) {
											if (ptr[52] <= 2) {
												return 0;//short version
											}
											else {
												return 0;//short version
											}
										}
										else {
											if (ptr[6] <= 20) {
												return 0;//short version
											}
											else {
												return 1;
											}
										}
									}
									else {
										if (ptr[7] <= 20) {
											if (ptr[46] <= 0) {
												if (ptr[17] <= 58) {
													return 0;
												}
												else {
													return 1;
												}
											}
											else {
												return 0;
											}
										}
										else {
											if (ptr[5] <= 20) {
												if (ptr[21] <= 12) {
													return 0;
												}
												else {
													return 1;
												}
											}
											else {
												return 1;
											}
										}
									}
								}
								else {
									if (ptr[56] <= 12) {
										if (ptr[2] <= 75) {
											if (ptr[16] <= 15) {
												return 0;//short version
											}
											else {
												return 0;
											}
										}
										else {
											return 1;
										}
									}
									else {
										return 1;
									}
								}
							}
							else {
								if (ptr[13] <= 0) {
									if (ptr[64] <= 0) {
										if (ptr[12] <= 0) {
											if (ptr[18] <= 12) {
												if (ptr[37] <= 7) {
													return 0;
												}
												else {
													return 1;
												}
											}
											else {
												if (ptr[46] <= 0) {
													return 1;
												}
												else {
													return 0;
												}
											}
										}
										else {
											return 0;//short version
										}
									}
									else {
										if (ptr[56] <= 0) {
											if (ptr[54] <= 0) {
												return 0;//short version
											}
											else {
												return 1;
											}
										}
										else {
											return 1;
										}
									}
								}
								else {
									if (ptr[33] <= 12) {
										if (ptr[25] <= 0) {
											return 0;
										}
										else {
											if (ptr[60] <= 0) {
												if (ptr[16] <= 15) {
													return 0;
												}
												else {
													return 1;
												}
											}
											else {
												return 0;
											}
										}
									}
									else {
										return 1;
									}
								}
							}
						}
						else {
							if (ptr[10] <= 0) {
								if (ptr[24] <= 2) {
									if (ptr[75] <= 0) {
										if (ptr[26] <= 0) {
											if (ptr[36] <= 5) {
												return 1;//short version
											}
											else {
												if (ptr[31] <= 33) {
													return 1;
												}
												else {
													return 0;
												}
											}
										}
										else {
											return 0;
										}
									}
									else {
										return 0;
									}
								}
								else {
									return 0;
								}
							}
							else {
								if (ptr[34] <= 10) {
									return 0;//short version
								}
								else {
									return 1;
								}
							}
						}
					}
				}
				else {
					if (ptr[33] <= 5) {
						if (ptr[24] <= 0) {
							if (ptr[14] <= 0) {
								if (ptr[11] <= 0) {
									if (ptr[25] <= 0) {
										if (ptr[28] <= 2) {
											if (ptr[10] <= 5) {
												return 1;//short version
											}
											else {
												return 0;
											}
										}
										else {
											return 0;
										}
									}
									else {
										if (ptr[32] <= 0) {
											return 0;//short version
										}
										else {
											if (ptr[44] <= 0) {
												return 1;
											}
											else {
												return 0;
											}
										}
									}
								}
								else {
									if (ptr[70] <= 2) {
										if (ptr[32] <= 0) {
											if (ptr[17] <= 20) {
												if (ptr[35] <= 20) {
													return 0;
												}
												else {
													return 1;
												}
											}
											else {
												return 1;
											}
										}
										else {
											if (ptr[20] <= 10) {
												return 0;
											}
											else {
												return 1;
											}
										}
									}
									else {
										if (ptr[40] <= 17) {
											return 0;
										}
										else {
											return 1;
										}
									}
								}
							}
							else {
								if (ptr[58] <= 10) {
									if (ptr[40] <= 26) {
										if (ptr[19] <= 19) {
											if (ptr[39] <= 15) {
												if (ptr[2] <= 22) {
													return 0;
												}
												else {
													return 1;
												}
											}
											else {
												return 0;
											}
										}
										else {
											return 1;
										}
									}
									else {
										return 1;
									}
								}
								else {
									return 1;
								}
							}
						}
						else {
							if (ptr[36] <= 7) {
								if (ptr[13] <= 0) {
									if (ptr[19] <= 12) {
										if (ptr[34] <= 5) {
											if (ptr[21] <= 20) {
												return 0;//short version
											}
											else {
												return 1;
											}
										}
										else {
											if (ptr[21] <= 0) {
												return 0;
											}
											else {
												return 1;
											}
										}
									}
									else {
										return 1;
									}
								}
								else {
									if (ptr[18] <= 5) {
										if (ptr[7] <= 20) {
											if (ptr[38] <= 22) {
												if (ptr[40] <= 25) {
													return 0;
												}
												else {
													return 1;
												}
											}
											else {
												return 0;
											}
										}
										else {
											return 1;
										}
									}
									else {
										return 0;
									}
								}
							}
							else {
								if (ptr[34] <= 5) {
									if (ptr[25] <= 2) {
										if (ptr[18] <= 5) {
											if (ptr[40] <= 5) {
												return 0;
											}
											else {
												return 1;
											}
										}
										else {
											return 1;
										}
									}
									else {
										if (ptr[12] <= 0) {
											return 0;//short version
										}
										else {
											if (ptr[20] <= 17) {
												return 0;//short version
											}
											else {
												return 0;
											}
										}
									}
								}
								else {
									if (ptr[35] <= 15) {
										if (ptr[13] <= 0) {
											if (ptr[21] <= 10) {
												if (ptr[14] <= 2) {
													return 1;
												}
												else {
													return 0;
												}
											}
											else {
												return 1;
											}
										}
										else {
											return 0;
										}
									}
									else {
										return 1;
									}
								}
							}
						}
					}
					else {
						if (ptr[11] <= 0) {
							if (ptr[25] <= 5) {
								if (ptr[13] <= 2) {
									if (ptr[9] <= 7) {
										if (ptr[64] <= 7) {
											if (ptr[49] <= 26) {
												return 1;//short version
											}
											else {
												return 0;
											}
										}
										else {
											return 0;
										}
									}
									else {
										return 1;
									}
								}
								else {
									return 0;
								}
							}
							else {
								if (ptr[13] <= 0) {
									return 1;//short version
								}
								else {
									return 0;
								}
							}
						}
						else {
							if (ptr[18] <= 12) {
								if (ptr[13] <= 0) {
									if (ptr[37] <= 5) {
										return 0;
									}
									else {
										if (ptr[11] <= 10) {
											if (ptr[42] <= 2) {
												return 1;
											}
											else {
												return 0;
											}
										}
										else {
											return 0;
										}
									}
								}
								else {
									return 0;
								}
							}
							else {
								return 1;
							}
						}
					}
				}
			}
			else {
				if (ptr[20] <= 0) {
					if (ptr[6] <= 2) {
						if (ptr[8] <= 0) {
							if (ptr[1] <= 0) {
								if (ptr[36] <= 0) {
									if (ptr[19] <= 5) {
										if (ptr[16] <= 0) {
											if (ptr[65] <= 17) {
												return 1;//short version
											}
											else {
												return 0;
											}
										}
										else {
											if (ptr[3] <= 7) {
												if (ptr[37] <= 3) {
													return 1;
												}
												else {
													return 0;
												}
											}
											else {
												return 0;
											}
										}
									}
									else {
										if (ptr[7] <= 1) {
											if (ptr[34] <= 30) {
												return 1;//short version
											}
											else {
												return 1;
											}
										}
										else {
											return 0;
										}
									}
								}
								else {
									return 1;
								}
							}
							else {
								return 0;
							}
						}
						else {
							return 0;
						}
					}
					else {
						if (ptr[6] <= 25) {
							if (ptr[31] <= 48) {
								if (ptr[16] <= 20) {
									if (ptr[19] <= 2) {
										if (ptr[2] <= 5) {
											if (ptr[33] <= 22) {
												if (ptr[60] <= 5) {
													return 1;
												}
												else {
													return 0;
												}
											}
											else {
												return 1;
											}
										}
										else {
											return 0;
										}
									}
									else {
										if (ptr[38] <= 5) {
											if (ptr[37] <= 2) {
												if (ptr[32] <= 28) {
													return 0;
												}
												else {
													return 1;
												}
											}
											else {
												return 1;
											}
										}
										else {
											return 1;
										}
									}
								}
								else {
									if (ptr[5] <= 15) {
										if (ptr[2] <= 1) {
											return 1;//short version
										}
										else {
											return 0;
										}
									}
									else {
										return 1;
									}
								}
							}
							else {
								if (ptr[50] <= 1) {
									if (ptr[74] <= 2) {
										if (ptr[30] <= 25) {
											if (ptr[8] <= 1) {
												if (ptr[2] <= 0) {
													return 1;
												}
												else {
													return 0;
												}
											}
											else {
												return 0;
											}
										}
										else {
											return 1;
										}
									}
									else {
										return 1;
									}
								}
								else {
									return 0;
								}
							}
						}
						else {
							if (ptr[8] <= 1) {
								if (ptr[19] <= 0) {
									if (ptr[62] <= 2) {
										if (ptr[1] <= 7) {
											if (ptr[17] <= 68) {
												if (ptr[7] <= 15) {
													return 1;
												}
												else {
													return 0;
												}
											}
											else {
												return 1;
											}
										}
										else {
											return 0;
										}
									}
									else {
										return 0;
									}
								}
								else {
									return 0;//short version
								}
							}
							else {
								return 0;
							}
						}
					}
				}
				else {
					if (ptr[52] <= 2) {
						if (ptr[7] <= 0) {
							if (ptr[49] <= 0) {
								if (ptr[38] <= 5) {
									if (ptr[31] <= 22) {
										if (ptr[67] <= 5) {
											if (ptr[17] <= 20) {
												return 0;
											}
											else {
												return 1;
											}
										}
										else {
											return 1;
										}
									}
									else {
										return 1;
									}
								}
								else {
									return 1;
								}
							}
							else {
								if (ptr[38] <= 0) {
									if (ptr[30] <= 10) {
										if (ptr[19] <= 7) {
											return 0;
										}
										else {
											if (ptr[49] <= 29) {
												return 0;
											}
											else {
												return 1;
											}
										}
									}
									else {
										return 1;
									}
								}
								else {
									return 1;
								}
							}
						}
						else {
							if (ptr[23] <= 0) {
								if (ptr[40] <= 2) {
									if (ptr[53] <= 2) {
										if (ptr[39] <= 2) {
											if (ptr[68] <= 0) {
												return 0;//short version
											}
											else {
												return 1;
											}
										}
										else {
											return 1;
										}
									}
									else {
										return 1;
									}
								}
								else {
									return 1;
								}
							}
							else {
								return 1;
							}
						}
					}
					else {
						if (ptr[62] <= 0) {
							if (ptr[39] <= 0) {
								if (ptr[9] <= 0) {
									return 1;//short version
								}
								else {
									return 0;
								}
							}
							else {
								return 1;//short version
							}
						}
						else {
							return 0;
						}
					}
				}
			}
		}
		else {
			if (ptr[37] <= 7) {
				if (ptr[35] <= 7) {
					if (ptr[22] <= 10) {
						if (ptr[33] <= 7) {
							if (ptr[21] <= 15) {
								if (ptr[58] <= 28) {
									if (ptr[20] <= 12) {
										if (ptr[14] <= 0) {
											if (ptr[16] <= 15) {
												return 0;//short version
											}
											else {
												return 1;
											}
										}
										else {
											if (ptr[5] <= 15) {
												if (ptr[39] <= 44) {
													return 0;
												}
												else {
													return 1;
												}
											}
											else {
												return 0;
											}
										}
									}
									else {
										if (ptr[36] <= 15) {
											return 0;//short version
										}
										else {
											return 0;
										}
									}
								}
								else {
									return 1;
								}
							}
							else {
								return 0;
							}
						}
						else {
							if (ptr[19] <= 10) {
								if (ptr[35] <= 2) {
									if (ptr[53] <= 12) {
										return 0;//short version
									}
									else {
										return 1;
									}
								}
								else {
									return 0;
								}
							}
							else {
								return 0;
							}
						}
					}
					else {
						if (ptr[19] <= 10) {
							if (ptr[8] <= 10) {
								if (ptr[6] <= 28) {
									if (ptr[21] <= 28) {
										if (ptr[9] <= 12) {
											if (ptr[7] <= 31) {
												if (ptr[17] <= 22) {
													return 0;
												}
												else {
													return 1;
												}
											}
											else {
												return 1;
											}
										}
										else {
											return 0;
										}
									}
									else {
										return 1;
									}
								}
								else {
									return 1;
								}
							}
							else {
								return 0;
							}
						}
						else {
							return 0;
						}
					}
				}
				else {
					if (ptr[14] <= 0) {
						if (ptr[18] <= 12) {
							if (ptr[16] <= 7) {
								if (ptr[34] <= 12) {
									if (ptr[35] <= 15) {
										if (ptr[20] <= 22) {
											if (ptr[39] <= 7) {
												return 0;//short version
											}
											else {
												return 0;
											}
										}
										else {
											return 1;
										}
									}
									else {
										return 0;
									}
								}
								else {
									return 0;
								}
							}
							else {
								return 1;
							}
						}
						else {
							return 1;
						}
					}
					else {
						if (ptr[18] <= 15) {
							if (ptr[20] <= 10) {
								if (ptr[38] <= 22) {
									if (ptr[55] <= 16) {
										if (ptr[17] <= 7) {
											if (ptr[64] <= 2) {
												if (ptr[33] <= 24) {
													return 0;
												}
												else {
													return 1;
												}
											}
											else {
												return 0;
											}
										}
										else {
											return 0;
										}
									}
									else {
										return 1;
									}
								}
								else {
									return 1;
								}
							}
							else {
								return 0;
							}
						}
						else {
							return 1;
						}
					}
				}
			}
			else {
				if (ptr[34] <= 10) {
					if (ptr[13] <= 0) {
						if (ptr[33] <= 2) {
							if (ptr[27] <= 5) {
								if (ptr[5] <= 7) {
									if (ptr[35] <= 5) {
										if (ptr[39] <= 22) {
											if (ptr[17] <= 17) {
												return 0;//short version
											}
											else {
												return 1;
											}
										}
										else {
											return 1;
										}
									}
									else {
										return 0;
									}
								}
								else {
									return 1;
								}
							}
							else {
								if (ptr[20] <= 15) {
									if (ptr[37] <= 17) {
										if (ptr[4] <= 0) {
											if (ptr[35] <= 17) {
												return 0;//short version
											}
											else {
												return 1;
											}
										}
										else {
											return 1;
										}
									}
									else {
										return 0;
									}
								}
								else {
									return 1;
								}
							}
						}
						else {
							if (ptr[35] <= 10) {
								if (ptr[25] <= 2) {
									return 0;
								}
								else {
									if (ptr[21] <= 10) {
										if (ptr[19] <= 16) {
											if (ptr[16] <= 7) {
												if (ptr[32] <= 16) {
													return 0;
												}
												else {
													return 1;
												}
											}
											else {
												return 1;
											}
										}
										else {
											return 1;
										}
									}
									else {
										return 0;
									}
								}
							}
							else {
								return 1;
							}
						}
					}
					else {
						if (ptr[21] <= 20) {
							if (ptr[33] <= 7) {
								if (ptr[14] <= 0) {
									if (ptr[23] <= 28) {
										if (ptr[30] <= 2) {
											if (ptr[17] <= 7) {
												if (ptr[21] <= 17) {
													return 0;
												}
												else {
													return 1;
												}
											}
											else {
												return 0;
											}
										}
										else {
											return 0;
										}
									}
									else {
										return 1;
									}
								}
								else {
									if (ptr[16] <= 17) {
										if (ptr[35] <= 10) {
											if (ptr[15] <= 1) {
												return 0;//short version
											}
											else {
												return 1;
											}
										}
										else {
											return 0;
										}
									}
									else {
										return 1;
									}
								}
							}
							else {
								return 0;
							}
						}
						else {
							return 1;
						}
					}
				}
				else {
					if (ptr[25] <= 10) {
						return 1;//short version
					}
					else {
						return 0;
					}
				}
			}
		}
	}
	unsigned char predict_4(unsigned char ptr[]) {
		if (ptr[16] <= 10) {
			if (ptr[14] <= 0) {
				if (ptr[54] <= 2) {
					if (ptr[30] <= 5) {
						if (ptr[38] <= 2) {
							if (ptr[20] <= 0) {
								if (ptr[31] <= 20) {
									if (ptr[3] <= 0) {
										if (ptr[7] <= 0) {
											if (ptr[28] <= 0) {
												if (ptr[18] <= 0) {
													return 1;
												}
												else {
													return 0;
												}
											}
											else {
												if (ptr[21] <= 22) {
													return 0;
												}
												else {
													return 1;
												}
											}
										}
										else {
											if (ptr[36] <= 12) {
												if (ptr[37] <= 17) {
													return 0;
												}
												else {
													return 1;
												}
											}
											else {
												return 0;
											}
										}
									}
									else {
										if (ptr[1] <= 12) {
											if (ptr[17] <= 68) {
												return 0;//short version
											}
											else {
												return 1;
											}
										}
										else {
											return 0;
										}
									}
								}
								else {
									if (ptr[48] <= 12) {
										if (ptr[6] <= 0) {
											if (ptr[8] <= 1) {
												if (ptr[7] <= 2) {
													return 1;
												}
												else {
													return 0;
												}
											}
											else {
												return 0;
											}
										}
										else {
											if (ptr[6] <= 7) {
												if (ptr[17] <= 45) {
													return 0;
												}
												else {
													return 1;
												}
											}
											else {
												return 0;//short version
											}
										}
									}
									else {
										if (ptr[7] <= 2) {
											if (ptr[18] <= 2) {
												if (ptr[6] <= 25) {
													return 1;
												}
												else {
													return 0;
												}
											}
											else {
												return 1;//short version
											}
										}
										else {
											return 0;
										}
									}
								}
							}
							else {
								if (ptr[52] <= 2) {
									if (ptr[49] <= 0) {
										if (ptr[22] <= 2) {
											if (ptr[5] <= 10) {
												return 0;//short version
											}
											else {
												return 0;//short version
											}
										}
										else {
											if (ptr[44] <= 0) {
												if (ptr[17] <= 12) {
													return 0;
												}
												else {
													return 1;
												}
											}
											else {
												if (ptr[7] <= 24) {
													return 0;
												}
												else {
													return 1;
												}
											}
										}
									}
									else {
										if (ptr[53] <= 2) {
											if (ptr[24] <= 2) {
												return 0;//short version
											}
											else {
												return 0;
											}
										}
										else {
											return 0;
										}
									}
								}
								else {
									if (ptr[68] <= 0) {
										if (ptr[63] <= 0) {
											if (ptr[26] <= 0) {
												return 0;//short version
											}
											else {
												return 0;
											}
										}
										else {
											if (ptr[67] <= 10) {
												return 0;//short version
											}
											else {
												return 1;
											}
										}
									}
									else {
										if (ptr[26] <= 0) {
											if (ptr[30] <= 0) {
												if (ptr[78] <= 2) {
													return 1;
												}
												else {
													return 0;
												}
											}
											else {
												return 1;
											}
										}
										else {
											return 0;
										}
									}
								}
							}
						}
						else {
							if (ptr[28] <= 0) {
								if (ptr[34] <= 5) {
									if (ptr[77] <= 0) {
										if (ptr[20] <= 7) {
											if (ptr[35] <= 12) {
												return 0;//short version
											}
											else {
												if (ptr[12] <= 2) {
													return 1;
												}
												else {
													return 0;
												}
											}
										}
										else {
											if (ptr[10] <= 5) {
												return 1;//short version
											}
											else {
												return 0;//short version
											}
										}
									}
									else {
										if (ptr[25] <= 0) {
											if (ptr[63] <= 2) {
												return 0;//short version
											}
											else {
												return 1;
											}
										}
										else {
											if (ptr[32] <= 12) {
												if (ptr[38] <= 20) {
													return 0;
												}
												else {
													return 1;
												}
											}
											else {
												return 1;
											}
										}
									}
								}
								else {
									if (ptr[19] <= 12) {
										if (ptr[13] <= 0) {
											if (ptr[10] <= 2) {
												if (ptr[27] <= 2) {
													return 1;
												}
												else {
													return 0;
												}
											}
											else {
												if (ptr[18] <= 7) {
													return 0;
												}
												else {
													return 1;
												}
											}
										}
										else {
											return 0;
										}
									}
									else {
										if (ptr[60] <= 8) {
											if (ptr[75] <= 1) {
												return 1;//short version
											}
											else {
												return 0;
											}
										}
										else {
											return 0;
										}
									}
								}
							}
							else {
								if (ptr[35] <= 10) {
									if (ptr[20] <= 10) {
										if (ptr[35] <= 2) {
											if (ptr[37] <= 12) {
												return 0;//short version
											}
											else {
												return 0;
											}
										}
										else {
											if (ptr[34] <= 7) {
												if (ptr[21] <= 17) {
													return 0;
												}
												else {
													return 1;
												}
											}
											else {
												return 0;
											}
										}
									}
									else {
										return 0;
									}
								}
								else {
									return 0;
								}
							}
						}
					}
					else {
						if (ptr[7] <= 0) {
							if (ptr[2] <= 2) {
								if (ptr[19] <= 0) {
									if (ptr[30] <= 22) {
										if (ptr[25] <= 5) {
											if (ptr[20] <= 0) {
												return 1;//short version
											}
											else {
												return 1;
											}
										}
										else {
											return 0;
										}
									}
									else {
										if (ptr[5] <= 28) {
											if (ptr[60] <= 5) {
												return 1;//short version
											}
											else {
												return 1;
											}
										}
										else {
											return 0;
										}
									}
								}
								else {
									if (ptr[21] <= 0) {
										if (ptr[32] <= 22) {
											if (ptr[20] <= 0) {
												if (ptr[30] <= 12) {
													return 0;
												}
												else {
													return 1;
												}
											}
											else {
												if (ptr[30] <= 15) {
													return 0;
												}
												else {
													return 1;
												}
											}
										}
										else {
											if (ptr[18] <= 61) {
												if (ptr[19] <= 25) {
													return 1;
												}
												else {
													return 0;
												}
											}
											else {
												return 0;
											}
										}
									}
									else {
										if (ptr[49] <= 0) {
											return 1;
										}
										else {
											return 0;
										}
									}
								}
							}
							else {
								return 0;
							}
						}
						else {
							if (ptr[37] <= 2) {
								if (ptr[30] <= 12) {
									if (ptr[39] <= 5) {
										if (ptr[31] <= 43) {
											if (ptr[33] <= 40) {
												return 0;//short version
											}
											else {
												return 0;
											}
										}
										else {
											return 0;
										}
									}
									else {
										return 1;
									}
								}
								else {
									if (ptr[32] <= 30) {
										if (ptr[19] <= 17) {
											return 0;//short version
										}
										else {
											return 0;
										}
									}
									else {
										return 1;
									}
								}
							}
							else {
								if (ptr[18] <= 7) {
									if (ptr[63] <= 5) {
										return 1;
									}
									else {
										return 0;
									}
								}
								else {
									return 1;
								}
							}
						}
					}
				}
				else {
					if (ptr[28] <= 0) {
						if (ptr[41] <= 2) {
							if (ptr[10] <= 0) {
								if (ptr[26] <= 0) {
									if (ptr[23] <= 5) {
										if (ptr[11] <= 2) {
											if (ptr[42] <= 2) {
												if (ptr[13] <= 0) {
													return 1;
												}
												else {
													return 0;
												}
											}
											else {
												return 1;
											}
										}
										else {
											return 0;
										}
									}
									else {
										if (ptr[35] <= 7) {
											if (ptr[12] <= 0) {
												return 1;
											}
											else {
												return 0;
											}
										}
										else {
											return 1;//short version
										}
									}
								}
								else {
									if (ptr[36] <= 7) {
										return 0;
									}
									else {
										return 1;
									}
								}
							}
							else {
								if (ptr[11] <= 2) {
									if (ptr[33] <= 0) {
										return 0;//short version
									}
									else {
										if (ptr[35] <= 5) {
											return 1;
										}
										else {
											if (ptr[13] <= 6) {
												return 1;//short version
											}
											else {
												return 0;
											}
										}
									}
								}
								else {
									if (ptr[32] <= 7) {
										if (ptr[68] <= 2) {
											if (ptr[69] <= 0) {
												return 0;//short version
											}
											else {
												return 0;
											}
										}
										else {
											return 0;//short version
										}
									}
									else {
										return 0;
									}
								}
							}
						}
						else {
							if (ptr[36] <= 7) {
								if (ptr[12] <= 0) {
									if (ptr[32] <= 0) {
										if (ptr[77] <= 0) {
											if (ptr[39] <= 20) {
												if (ptr[34] <= 7) {
													return 0;
												}
												else {
													return 1;
												}
											}
											else {
												return 1;
											}
										}
										else {
											return 0;
										}
									}
									else {
										if (ptr[31] <= 5) {
											if (ptr[24] <= 0) {
												if (ptr[43] <= 5) {
													return 1;
												}
												else {
													return 0;
												}
											}
											else {
												return 0;
											}
										}
										else {
											if (ptr[43] <= 15) {
												return 1;//short version
											}
											else {
												return 0;
											}
										}
									}
								}
								else {
									if (ptr[35] <= 7) {
										if (ptr[26] <= 2) {
											if (ptr[58] <= 12) {
												if (ptr[54] <= 22) {
													return 0;
												}
												else {
													return 1;
												}
											}
											else {
												return 1;
											}
										}
										else {
											if (ptr[40] <= 34) {
												return 0;//short version
											}
											else {
												return 1;
											}
										}
									}
									else {
										return 0;
									}
								}
							}
							else {
								if (ptr[26] <= 2) {
									if (ptr[10] <= 2) {
										if (ptr[27] <= 2) {
											if (ptr[24] <= 2) {
												if (ptr[11] <= 5) {
													return 1;
												}
												else {
													return 0;
												}
											}
											else {
												if (ptr[11] <= 2) {
													return 1;
												}
												else {
													return 0;
												}
											}
										}
										else {
											return 0;
										}
									}
									else {
										return 0;
									}
								}
								else {
									return 0;//short version
								}
							}
						}
					}
					else {
						if (ptr[36] <= 15) {
							if (ptr[50] <= 7) {
								if (ptr[33] <= 7) {
									if (ptr[56] <= 21) {
										if (ptr[35] <= 21) {
											if (ptr[34] <= 0) {
												return 0;//short version
											}
											else {
												return 0;//short version
											}
										}
										else {
											return 1;
										}
									}
									else {
										return 1;
									}
								}
								else {
									return 0;
								}
							}
							else {
								return 0;
							}
						}
						else {
							return 0;
						}
					}
				}
			}
			else {
				if (ptr[34] <= 10) {
					if (ptr[35] <= 2) {
						if (ptr[20] <= 25) {
							if (ptr[21] <= 20) {
								if (ptr[30] <= 2) {
									if (ptr[17] <= 38) {
										if (ptr[9] <= 20) {
											if (ptr[10] <= 33) {
												return 0;//short version
											}
											else {
												return 1;
											}
										}
										else {
											return 0;
										}
									}
									else {
										return 1;
									}
								}
								else {
									if (ptr[28] <= 20) {
										if (ptr[23] <= 20) {
											if (ptr[69] <= 22) {
												return 0;//short version
											}
											else {
												return 1;
											}
										}
										else {
											return 0;
										}
									}
									else {
										return 0;
									}
								}
							}
							else {
								return 0;
							}
						}
						else {
							return 1;
						}
					}
					else {
						if (ptr[32] <= 5) {
							if (ptr[25] <= 0) {
								if (ptr[7] <= 17) {
									if (ptr[16] <= 0) {
										if (ptr[57] <= 10) {
											if (ptr[18] <= 22) {
												return 0;//short version
											}
											else {
												return 1;
											}
										}
										else {
											return 1;
										}
									}
									else {
										return 0;
									}
								}
								else {
									return 1;
								}
							}
							else {
								if (ptr[20] <= 7) {
									if (ptr[33] <= 7) {
										if (ptr[64] <= 11) {
											if (ptr[1] <= 25) {
												return 0;//short version
											}
											else {
												return 1;
											}
										}
										else {
											return 1;
										}
									}
									else {
										return 0;
									}
								}
								else {
									if (ptr[33] <= 12) {
										if (ptr[13] <= 2) {
											return 0;
										}
										else {
											if (ptr[39] <= 21) {
												return 0;//short version
											}
											else {
												return 1;
											}
										}
									}
									else {
										return 1;
									}
								}
							}
						}
						else {
							if (ptr[33] <= 10) {
								if (ptr[51] <= 0) {
									if (ptr[35] <= 15) {
										if (ptr[30] <= 10) {
											if (ptr[39] <= 28) {
												return 0;//short version
											}
											else {
												return 1;
											}
										}
										else {
											return 0;
										}
									}
									else {
										return 0;
									}
								}
								else {
									return 0;
								}
							}
							else {
								return 0;
							}
						}
					}
				}
				else {
					if (ptr[16] <= 5) {
						if (ptr[51] <= 10) {
							if (ptr[33] <= 15) {
								if (ptr[19] <= 2) {
									return 0;
								}
								else {
									if (ptr[14] <= 2) {
										return 1;
									}
									else {
										return 0;
									}
								}
							}
							else {
								return 1;
							}
						}
						else {
							return 1;
						}
					}
					else {
						return 1;
					}
				}
			}
		}
		else {
			if (ptr[6] <= 0) {
				if (ptr[21] <= 0) {
					if (ptr[30] <= 7) {
						if (ptr[8] <= 0) {
							if (ptr[7] <= 0) {
								if (ptr[31] <= 17) {
									if (ptr[20] <= 0) {
										return 1;//short version
									}
									else {
										return 0;
									}
								}
								else {
									if (ptr[62] <= 5) {
										if (ptr[47] <= 10) {
											if (ptr[46] <= 38) {
												return 1;//short version
											}
											else {
												return 0;
											}
										}
										else {
											if (ptr[5] <= 22) {
												return 1;//short version
											}
											else {
												return 0;
											}
										}
									}
									else {
										if (ptr[5] <= 5) {
											if (ptr[74] <= 5) {
												if (ptr[35] <= 8) {
													return 1;
												}
												else {
													return 0;
												}
											}
											else {
												return 1;
											}
										}
										else {
											return 0;
										}
									}
								}
							}
							else {
								return 0;
							}
						}
						else {
							return 0;
						}
					}
					else {
						if (ptr[5] <= 17) {
							if (ptr[77] <= 3) {
								if (ptr[8] <= 1) {
									if (ptr[62] <= 51) {
										if (ptr[7] <= 15) {
											if (ptr[49] <= 51) {
												return 1;//short version
											}
											else {
												return 1;
											}
										}
										else {
											return 0;
										}
									}
									else {
										return 0;
									}
								}
								else {
									return 0;
								}
							}
							else {
								return 0;
							}
						}
						else {
							return 1;
						}
					}
				}
				else {
					if (ptr[53] <= 2) {
						if (ptr[18] <= 10) {
							return 0;
						}
						else {
							return 1;
						}
					}
					else {
						return 1;
					}
				}
			}
			else {
				if (ptr[19] <= 0) {
					if (ptr[2] <= 0) {
						if (ptr[61] <= 2) {
							if (ptr[16] <= 17) {
								if (ptr[27] <= 0) {
									if (ptr[3] <= 7) {
										if (ptr[7] <= 28) {
											if (ptr[31] <= 48) {
												if (ptr[64] <= 20) {
													return 1;
												}
												else {
													return 0;
												}
											}
											else {
												return 1;
											}
										}
										else {
											return 0;
										}
									}
									else {
										return 0;
									}
								}
								else {
									return 0;
								}
							}
							else {
								if (ptr[6] <= 82) {
									if (ptr[8] <= 0) {
										if (ptr[47] <= 25) {
											if (ptr[14] <= 2) {
												if (ptr[75] <= 17) {
													return 1;
												}
												else {
													return 0;
												}
											}
											else {
												return 0;
											}
										}
										else {
											return 1;
										}
									}
									else {
										return 0;
									}
								}
								else {
									return 0;
								}
							}
						}
						else {
							if (ptr[6] <= 25) {
								if (ptr[35] <= 10) {
									if (ptr[16] <= 22) {
										return 0;
									}
									else {
										return 1;
									}
								}
								else {
									return 0;
								}
							}
							else {
								return 0;
							}
						}
					}
					else {
						if (ptr[37] <= 10) {
							return 0;//short version
						}
						else {
							return 1;
						}
					}
				}
				else {
					if (ptr[53] <= 0) {
						if (ptr[37] <= 0) {
							if (ptr[17] <= 30) {
								if (ptr[8] <= 0) {
									if (ptr[63] <= 7) {
										if (ptr[7] <= 0) {
											if (ptr[19] <= 10) {
												return 1;
											}
											else {
												return 0;
											}
										}
										else {
											if (ptr[61] <= 0) {
												return 0;//short version
											}
											else {
												return 0;
											}
										}
									}
									else {
										return 0;
									}
								}
								else {
									if (ptr[11] <= 0) {
										if (ptr[24] <= 1) {
											if (ptr[49] <= 0) {
												if (ptr[38] <= 2) {
													return 0;
												}
												else {
													return 1;
												}
											}
											else {
												return 0;
											}
										}
										else {
											return 1;
										}
									}
									else {
										return 1;
									}
								}
							}
							else {
								if (ptr[7] <= 7) {
									if (ptr[35] <= 10) {
										if (ptr[7] <= 2) {
											if (ptr[16] <= 15) {
												return 1;
											}
											else {
												return 1;//short version
											}
										}
										else {
											return 1;
										}
									}
									else {
										return 1;
									}
								}
								else {
									if (ptr[5] <= 5) {
										return 0;//short version
									}
									else {
										return 0;
									}
								}
							}
						}
						else {
							if (ptr[3] <= 1) {
								if (ptr[19] <= 10) {
									return 1;
								}
								else {
									if (ptr[7] <= 40) {
										if (ptr[27] <= 17) {
											if (ptr[25] <= 7) {
												return 1;//short version
											}
											else {
												return 1;
											}
										}
										else {
											return 0;
										}
									}
									else {
										return 0;
									}
								}
							}
							else {
								return 0;
							}
						}
					}
					else {
						if (ptr[12] <= 5) {
							return 1;//short version
						}
						else {
							return 0;
						}
					}
				}
			}
		}
	}
	unsigned char predict_5(unsigned char ptr[]) {
		if (ptr[31] <= 22) {
			if (ptr[27] <= 0) {
				if (ptr[39] <= 2) {
					if (ptr[8] <= 0) {
						if (ptr[68] <= 2) {
							if (ptr[53] <= 2) {
								if (ptr[7] <= 0) {
									if (ptr[19] <= 0) {
										if (ptr[20] <= 0) {
											if (ptr[1] <= 0) {
												if (ptr[51] <= 7) {
													return 1;
												}
												else {
													return 0;
												}
											}
											else {
												return 0;
											}
										}
										else {
											return 0;//short version
										}
									}
									else {
										if (ptr[17] <= 22) {
											if (ptr[38] <= 2) {
												return 0;//short version
											}
											else {
												if (ptr[34] <= 10) {
													return 0;
												}
												else {
													return 1;
												}
											}
										}
										else {
											if (ptr[37] <= 0) {
												if (ptr[30] <= 2) {
													return 0;
												}
												else {
													return 1;
												}
											}
											else {
												return 1;
											}
										}
									}
								}
								else {
									if (ptr[63] <= 0) {
										if (ptr[16] <= 12) {
											if (ptr[48] <= 0) {
												if (ptr[36] <= 10) {
													return 0;
												}
												else {
													return 1;
												}
											}
											else {
												return 0;//short version
											}
										}
										else {
											if (ptr[7] <= 22) {
												if (ptr[17] <= 43) {
													return 0;
												}
												else {
													return 1;
												}
											}
											else {
												return 0;
											}
										}
									}
									else {
										if (ptr[30] <= 12) {
											if (ptr[20] <= 0) {
												return 0;//short version
											}
											else {
												if (ptr[54] <= 3) {
													return 0;
												}
												else {
													return 1;
												}
											}
										}
										else {
											return 1;
										}
									}
								}
							}
							else {
								if (ptr[25] <= 0) {
									if (ptr[63] <= 0) {
										if (ptr[11] <= 0) {
											if (ptr[59] <= 0) {
												if (ptr[78] <= 12) {
													return 1;
												}
												else {
													return 0;
												}
											}
											else {
												return 0;
											}
										}
										else {
											return 0;
										}
									}
									else {
										return 0;
									}
								}
								else {
									return 0;
								}
							}
						}
						else {
							if (ptr[25] <= 0) {
								if (ptr[34] <= 5) {
									if (ptr[13] <= 0) {
										if (ptr[11] <= 2) {
											if (ptr[1] <= 2) {
												return 1;//short version
											}
											else {
												return 0;
											}
										}
										else {
											return 0;
										}
									}
									else {
										return 0;
									}
								}
								else {
									if (ptr[11] <= 2) {
										if (ptr[2] <= 15) {
											if (ptr[40] <= 10) {
												if (ptr[9] <= 7) {
													return 1;
												}
												else {
													return 0;
												}
											}
											else {
												return 0;
											}
										}
										else {
											return 0;
										}
									}
									else {
										return 0;
									}
								}
							}
							else {
								return 0;//short version
							}
						}
					}
					else {
						if (ptr[37] <= 2) {
							if (ptr[48] <= 0) {
								if (ptr[46] <= 0) {
									if (ptr[10] <= 2) {
										if (ptr[63] <= 0) {
											if (ptr[36] <= 2) {
												return 0;//short version
											}
											else {
												return 0;//short version
											}
										}
										else {
											if (ptr[67] <= 2) {
												if (ptr[56] <= 12) {
													return 0;
												}
												else {
													return 1;
												}
											}
											else {
												return 1;
											}
										}
									}
									else {
										if (ptr[16] <= 5) {
											if (ptr[18] <= 7) {
												if (ptr[32] <= 15) {
													return 0;
												}
												else {
													return 1;
												}
											}
											else {
												if (ptr[17] <= 12) {
													return 0;
												}
												else {
													return 1;
												}
											}
										}
										else {
											return 1;
										}
									}
								}
								else {
									if (ptr[53] <= 2) {
										if (ptr[55] <= 7) {
											if (ptr[5] <= 17) {
												return 0;//short version
											}
											else {
												return 0;
											}
										}
										else {
											return 1;
										}
									}
									else {
										return 0;
									}
								}
							}
							else {
								if (ptr[68] <= 2) {
									if (ptr[30] <= 31) {
										if (ptr[38] <= 2) {
											if (ptr[69] <= 0) {
												return 0;//short version
											}
											else {
												return 0;
											}
										}
										else {
											return 0;
										}
									}
									else {
										return 1;
									}
								}
								else {
									return 1;
								}
							}
						}
						else {
							if (ptr[17] <= 12) {
								if (ptr[11] <= 0) {
									if (ptr[74] <= 0) {
										if (ptr[47] <= 0) {
											if (ptr[75] <= 0) {
												if (ptr[63] <= 0) {
													return 1;
												}
												else {
													return 0;
												}
											}
											else {
												return 0;
											}
										}
										else {
											if (ptr[38] <= 5) {
												if (ptr[55] <= 2) {
													return 0;
												}
												else {
													return 1;
												}
											}
											else {
												return 1;
											}
										}
									}
									else {
										return 0;
									}
								}
								else {
									if (ptr[13] <= 0) {
										if (ptr[18] <= 15) {
											if (ptr[5] <= 12) {
												return 0;//short version
											}
											else {
												return 1;
											}
										}
										else {
											return 1;
										}
									}
									else {
										if (ptr[6] <= 30) {
											if (ptr[20] <= 30) {
												return 0;//short version
											}
											else {
												return 1;
											}
										}
										else {
											return 1;
										}
									}
								}
							}
							else {
								if (ptr[12] <= 10) {
									if (ptr[64] <= 2) {
										if (ptr[14] <= 1) {
											if (ptr[48] <= 5) {
												return 1;//short version
											}
											else {
												return 0;
											}
										}
										else {
											return 0;
										}
									}
									else {
										return 0;
									}
								}
								else {
									return 0;
								}
							}
						}
					}
				}
				else {
					if (ptr[25] <= 0) {
						if (ptr[11] <= 0) {
							if (ptr[34] <= 5) {
								if (ptr[28] <= 0) {
									if (ptr[12] <= 0) {
										if (ptr[36] <= 5) {
											if (ptr[33] <= 5) {
												if (ptr[44] <= 0) {
													return 1;
												}
												else {
													return 0;
												}
											}
											else {
												if (ptr[77] <= 15) {
													return 1;
												}
												else {
													return 0;
												}
											}
										}
										else {
											if (ptr[10] <= 12) {
												if (ptr[43] <= 12) {
													return 1;
												}
												else {
													return 0;
												}
											}
											else {
												return 0;
											}
										}
									}
									else {
										return 0;
									}
								}
								else {
									return 0;
								}
							}
							else {
								if (ptr[12] <= 5) {
									if (ptr[9] <= 12) {
										if (ptr[35] <= 5) {
											if (ptr[44] <= 0) {
												return 1;//short version
											}
											else {
												return 0;
											}
										}
										else {
											if (ptr[24] <= 7) {
												return 1;//short version
											}
											else {
												return 1;
											}
										}
									}
									else {
										return 1;
									}
								}
								else {
									return 0;
								}
							}
						}
						else {
							if (ptr[33] <= 5) {
								if (ptr[19] <= 10) {
									if (ptr[11] <= 7) {
										if (ptr[12] <= 0) {
											if (ptr[32] <= 2) {
												return 0;
											}
											else {
												return 1;
											}
										}
										else {
											if (ptr[31] <= 10) {
												if (ptr[22] <= 17) {
													return 0;
												}
												else {
													return 1;
												}
											}
											else {
												return 1;
											}
										}
									}
									else {
										if (ptr[9] <= 25) {
											if (ptr[17] <= 20) {
												return 0;//short version
											}
											else {
												return 0;
											}
										}
										else {
											return 1;
										}
									}
								}
								else {
									return 1;
								}
							}
							else {
								if (ptr[11] <= 7) {
									if (ptr[26] <= 2) {
										return 1;//short version
									}
									else {
										return 0;
									}
								}
								else {
									return 0;
								}
							}
						}
					}
					else {
						if (ptr[28] <= 0) {
							if (ptr[35] <= 7) {
								if (ptr[21] <= 12) {
									if (ptr[13] <= 0) {
										if (ptr[33] <= 5) {
											if (ptr[38] <= 10) {
												if (ptr[17] <= 17) {
													return 0;
												}
												else {
													return 1;
												}
											}
											else {
												if (ptr[25] <= 2) {
													return 1;
												}
												else {
													return 0;
												}
											}
										}
										else {
											if (ptr[19] <= 12) {
												if (ptr[39] <= 22) {
													return 0;
												}
												else {
													return 1;
												}
											}
											else {
												return 1;
											}
										}
									}
									else {
										if (ptr[34] <= 5) {
											if (ptr[23] <= 39) {
												return 0;//short version
											}
											else {
												return 1;
											}
										}
										else {
											return 0;
										}
									}
								}
								else {
									if (ptr[12] <= 5) {
										if (ptr[70] <= 2) {
											if (ptr[69] <= 2) {
												return 1;//short version
											}
											else {
												return 0;
											}
										}
										else {
											return 0;
										}
									}
									else {
										return 0;
									}
								}
							}
							else {
								if (ptr[33] <= 10) {
									if (ptr[12] <= 0) {
										if (ptr[26] <= 2) {
											if (ptr[37] <= 5) {
												return 1;
											}
											else {
												if (ptr[66] <= 7) {
													return 1;
												}
												else {
													return 0;
												}
											}
										}
										else {
											return 1;
										}
									}
									else {
										if (ptr[24] <= 7) {
											return 0;//short version
										}
										else {
											return 0;
										}
									}
								}
								else {
									return 1;//short version
								}
							}
						}
						else {
							if (ptr[16] <= 2) {
								if (ptr[37] <= 22) {
									if (ptr[39] <= 30) {
										if (ptr[37] <= 5) {
											if (ptr[19] <= 21) {
												if (ptr[49] <= 11) {
													return 0;
												}
												else {
													return 1;
												}
											}
											else {
												return 1;
											}
										}
										else {
											return 0;
										}
									}
									else {
										return 1;
									}
								}
								else {
									return 1;
								}
							}
							else {
								return 0;
							}
						}
					}
				}
			}
			else {
				if (ptr[33] <= 7) {
					if (ptr[36] <= 7) {
						if (ptr[37] <= 12) {
							if (ptr[21] <= 15) {
								if (ptr[18] <= 20) {
									if (ptr[32] <= 2) {
										if (ptr[22] <= 12) {
											if (ptr[34] <= 5) {
												return 0;//short version
											}
											else {
												if (ptr[30] <= 10) {
													return 0;
												}
												else {
													return 1;
												}
											}
										}
										else {
											if (ptr[51] <= 11) {
												return 0;//short version
											}
											else {
												return 1;
											}
										}
									}
									else {
										if (ptr[34] <= 7) {
											if (ptr[19] <= 15) {
												if (ptr[30] <= 10) {
													return 0;
												}
												else {
													return 1;
												}
											}
											else {
												return 0;
											}
										}
										else {
											return 0;
										}
									}
								}
								else {
									return 0;
								}
							}
							else {
								return 0;//short version
							}
						}
						else {
							if (ptr[35] <= 12) {
								if (ptr[28] <= 0) {
									if (ptr[16] <= 5) {
										if (ptr[20] <= 12) {
											if (ptr[50] <= 15) {
												if (ptr[34] <= 15) {
													return 0;
												}
												else {
													return 1;
												}
											}
											else {
												return 1;
											}
										}
										else {
											return 1;
										}
									}
									else {
										return 1;
									}
								}
								else {
									if (ptr[20] <= 17) {
										if (ptr[7] <= 17) {
											if (ptr[66] <= 10) {
												if (ptr[71] <= 22) {
													return 0;
												}
												else {
													return 1;
												}
											}
											else {
												return 1;
											}
										}
										else {
											return 1;
										}
									}
									else {
										return 1;
									}
								}
							}
							else {
								return 0;
							}
						}
					}
					else {
						if (ptr[34] <= 10) {
							if (ptr[13] <= 0) {
								if (ptr[35] <= 5) {
									if (ptr[23] <= 15) {
										if (ptr[57] <= 10) {
											if (ptr[18] <= 5) {
												return 0;//short version
											}
											else {
												return 0;
											}
										}
										else {
											return 0;
										}
									}
									else {
										return 0;
									}
								}
								else {
									if (ptr[14] <= 0) {
										if (ptr[27] <= 7) {
											if (ptr[12] <= 2) {
												return 1;
											}
											else {
												return 0;
											}
										}
										else {
											return 0;
										}
									}
									else {
										return 0;
									}
								}
							}
							else {
								if (ptr[14] <= 2) {
									if (ptr[12] <= 25) {
										if (ptr[26] <= 0) {
											return 0;
										}
										else {
											if (ptr[38] <= 20) {
												return 0;//short version
											}
											else {
												return 1;
											}
										}
									}
									else {
										return 0;
									}
								}
								else {
									if (ptr[15] <= 1) {
										if (ptr[30] <= 2) {
											if (ptr[17] <= 15) {
												return 0;//short version
											}
											else {
												return 0;
											}
										}
										else {
											return 0;
										}
									}
									else {
										return 1;
									}
								}
							}
						}
						else {
							if (ptr[17] <= 10) {
								return 0;
							}
							else {
								return 1;
							}
						}
					}
				}
				else {
					if (ptr[33] <= 12) {
						if (ptr[37] <= 2) {
							if (ptr[19] <= 10) {
								return 0;//short version
							}
							else {
								return 0;
							}
						}
						else {
							if (ptr[18] <= 10) {
								if (ptr[35] <= 10) {
									if (ptr[31] <= 5) {
										if (ptr[1] <= 7) {
											if (ptr[20] <= 20) {
												return 0;//short version
											}
											else {
												return 1;
											}
										}
										else {
											return 1;
										}
									}
									else {
										return 0;
									}
								}
								else {
									return 1;
								}
							}
							else {
								return 1;
							}
						}
					}
					else {
						if (ptr[36] <= 10) {
							return 0;
						}
						else {
							return 1;
						}
					}
				}
			}
		}
		else {
			if (ptr[48] <= 5) {
				if (ptr[16] <= 12) {
					if (ptr[19] <= 2) {
						if (ptr[6] <= 12) {
							if (ptr[7] <= 0) {
								if (ptr[11] <= 1) {
									if (ptr[69] <= 1) {
										if (ptr[36] <= 0) {
											if (ptr[5] <= 2) {
												if (ptr[61] <= 85) {
													return 1;
												}
												else {
													return 0;
												}
											}
											else {
												return 1;//short version
											}
										}
										else {
											return 1;
										}
									}
									else {
										return 0;
									}
								}
								else {
									return 0;
								}
							}
							else {
								return 0;
							}
						}
						else {
							if (ptr[47] <= 7) {
								if (ptr[31] <= 89) {
									if (ptr[38] <= 1) {
										return 0;
									}
									else {
										return 1;
									}
								}
								else {
									return 1;
								}
							}
							else {
								return 0;
							}
						}
					}
					else {
						if (ptr[7] <= 7) {
							if (ptr[7] <= 0) {
								if (ptr[20] <= 17) {
									if (ptr[6] <= 25) {
										if (ptr[8] <= 0) {
											if (ptr[14] <= 1) {
												if (ptr[19] <= 51) {
													return 1;
												}
												else {
													return 0;
												}
											}
											else {
												return 0;
											}
										}
										else {
											return 0;
										}
									}
									else {
										return 0;
									}
								}
								else {
									return 0;
								}
							}
							else {
								if (ptr[39] <= 1) {
									if (ptr[33] <= 28) {
										if (ptr[30] <= 38) {
											return 0;//short version
										}
										else {
											return 1;
										}
									}
									else {
										return 1;
									}
								}
								else {
									return 1;
								}
							}
						}
						else {
							if (ptr[22] <= 1) {
								if (ptr[68] <= 2) {
									if (ptr[7] <= 20) {
										if (ptr[39] <= 1) {
											if (ptr[49] <= 24) {
												return 0;//short version
											}
											else {
												return 1;
											}
										}
										else {
											return 1;
										}
									}
									else {
										if (ptr[30] <= 10) {
											if (ptr[6] <= 2) {
												return 0;
											}
											else {
												return 0;//short version
											}
										}
										else {
											return 0;
										}
									}
								}
								else {
									return 1;
								}
							}
							else {
								return 1;
							}
						}
					}
				}
				else {
					if (ptr[7] <= 2) {
						if (ptr[20] <= 15) {
							if (ptr[35] <= 5) {
								if (ptr[1] <= 12) {
									if (ptr[61] <= 51) {
										if (ptr[6] <= 15) {
											if (ptr[2] <= 7) {
												return 1;//short version
											}
											else {
												return 0;
											}
										}
										else {
											return 1;//short version
										}
									}
									else {
										return 0;
									}
								}
								else {
									return 0;
								}
							}
							else {
								return 1;
							}
						}
						else {
							return 0;
						}
					}
					else {
						if (ptr[2] <= 1) {
							if (ptr[7] <= 7) {
								return 1;
							}
							else {
								if (ptr[16] <= 30) {
									return 0;
								}
								else {
									return 1;
								}
							}
						}
						else {
							return 0;
						}
					}
				}
			}
			else {
				if (ptr[6] <= 2) {
					if (ptr[8] <= 0) {
						if (ptr[20] <= 5) {
							if (ptr[46] <= 81) {
								if (ptr[61] <= 15) {
									if (ptr[5] <= 12) {
										if (ptr[19] <= 10) {
											if (ptr[74] <= 7) {
												return 1;//short version
											}
											else {
												return 1;
											}
										}
										else {
											return 1;
										}
									}
									else {
										return 1;
									}
								}
								else {
									return 1;//short version
								}
							}
							else {
								return 0;
							}
						}
						else {
							return 1;
						}
					}
					else {
						return 0;
					}
				}
				else {
					if (ptr[16] <= 5) {
						if (ptr[8] <= 2) {
							if (ptr[32] <= 38) {
								if (ptr[6] <= 17) {
									if (ptr[48] <= 25) {
										return 0;//short version
									}
									else {
										return 1;
									}
								}
								else {
									return 0;
								}
							}
							else {
								return 1;
							}
						}
						else {
							return 0;
						}
					}
					else {
						if (ptr[7] <= 7) {
							if (ptr[32] <= 25) {
								if (ptr[6] <= 12) {
									if (ptr[21] <= 1) {
										return 1;
									}
									else {
										return 0;
									}
								}
								else {
									return 0;
								}
							}
							else {
								if (ptr[62] <= 7) {
									if (ptr[20] <= 14) {
										if (ptr[19] <= 40) {
											if (ptr[60] <= 5) {
												return 1;//short version
											}
											else {
												return 1;
											}
										}
										else {
											return 0;
										}
									}
									else {
										return 0;
									}
								}
								else {
									return 1;
								}
							}
						}
						else {
							return 0;
						}
					}
				}
			}
		}
	}
	unsigned char predict_6(unsigned char ptr[]) {
		if (ptr[28] <= 0) {
			if (ptr[17] <= 25) {
				if (ptr[12] <= 0) {
					if (ptr[52] <= 2) {
						if (ptr[31] <= 25) {
							if (ptr[75] <= 0) {
								if (ptr[40] <= 2) {
									if (ptr[37] <= 2) {
										if (ptr[30] <= 5) {
											if (ptr[38] <= 2) {
												if (ptr[23] <= 7) {
													return 0;
												}
												else {
													return 1;
												}
											}
											else {
												if (ptr[41] <= 0) {
													return 1;
												}
												else {
													return 0;
												}
											}
										}
										else {
											if (ptr[19] <= 2) {
												if (ptr[32] <= 15) {
													return 0;
												}
												else {
													return 1;
												}
											}
											else {
												return 0;//short version
											}
										}
									}
									else {
										if (ptr[37] <= 12) {
											if (ptr[18] <= 12) {
												return 0;//short version
											}
											else {
												if (ptr[50] <= 7) {
													return 1;
												}
												else {
													return 0;
												}
											}
										}
										else {
											if (ptr[35] <= 5) {
												if (ptr[39] <= 7) {
													return 0;
												}
												else {
													return 1;
												}
											}
											else {
												return 1;//short version
											}
										}
									}
								}
								else {
									if (ptr[34] <= 5) {
										if (ptr[33] <= 2) {
											if (ptr[35] <= 7) {
												return 0;//short version
											}
											else {
												if (ptr[44] <= 2) {
													return 1;
												}
												else {
													return 0;
												}
											}
										}
										else {
											if (ptr[26] <= 0) {
												return 1;//short version
											}
											else {
												if (ptr[37] <= 7) {
													return 0;
												}
												else {
													return 1;
												}
											}
										}
									}
									else {
										if (ptr[10] <= 2) {
											if (ptr[78] <= 5) {
												if (ptr[14] <= 0) {
													return 1;
												}
												else {
													return 0;
												}
											}
											else {
												return 0;
											}
										}
										else {
											if (ptr[34] <= 15) {
												if (ptr[20] <= 5) {
													return 0;
												}
												else {
													return 1;
												}
											}
											else {
												return 1;
											}
										}
									}
								}
							}
							else {
								if (ptr[20] <= 0) {
									if (ptr[6] <= 2) {
										if (ptr[19] <= 0) {
											if (ptr[31] <= 5) {
												return 1;
											}
											else {
												if (ptr[36] <= 5) {
													return 1;
												}
												else {
													return 0;
												}
											}
										}
										else {
											if (ptr[19] <= 7) {
												return 0;//short version
											}
											else {
												if (ptr[46] <= 10) {
													return 0;
												}
												else {
													return 1;
												}
											}
										}
									}
									else {
										if (ptr[7] <= 2) {
											if (ptr[31] <= 12) {
												if (ptr[53] <= 1) {
													return 0;
												}
												else {
													return 1;
												}
											}
											else {
												return 0;
											}
										}
										else {
											if (ptr[46] <= 20) {
												if (ptr[45] <= 15) {
													return 0;
												}
												else {
													return 1;
												}
											}
											else {
												return 1;
											}
										}
									}
								}
								else {
									if (ptr[69] <= 2) {
										if (ptr[68] <= 0) {
											if (ptr[38] <= 7) {
												if (ptr[48] <= 52) {
													return 0;
												}
												else {
													return 1;
												}
											}
											else {
												return 1;
											}
										}
										else {
											return 1;
										}
									}
									else {
										return 1;
									}
								}
							}
						}
						else {
							if (ptr[8] <= 0) {
								if (ptr[30] <= 5) {
									if (ptr[20] <= 2) {
										if (ptr[2] <= 1) {
											if (ptr[18] <= 12) {
												if (ptr[7] <= 5) {
													return 1;
												}
												else {
													return 0;
												}
											}
											else {
												if (ptr[33] <= 30) {
													return 0;
												}
												else {
													return 1;
												}
											}
										}
										else {
											return 0;
										}
									}
									else {
										if (ptr[20] <= 22) {
											return 0;//short version
										}
										else {
											return 0;
										}
									}
								}
								else {
									if (ptr[34] <= 7) {
										if (ptr[3] <= 0) {
											if (ptr[61] <= 22) {
												return 1;//short version
											}
											else {
												return 1;
											}
										}
										else {
											return 0;
										}
									}
									else {
										if (ptr[32] <= 10) {
											return 0;
										}
										else {
											if (ptr[7] <= 10) {
												if (ptr[2] <= 7) {
													return 1;
												}
												else {
													return 0;
												}
											}
											else {
												return 0;
											}
										}
									}
								}
							}
							else {
								if (ptr[39] <= 1) {
									if (ptr[35] <= 15) {
										if (ptr[31] <= 51) {
											if (ptr[46] <= 15) {
												if (ptr[15] <= 0) {
													return 0;
												}
												else {
													return 1;
												}
											}
											else {
												return 0;
											}
										}
										else {
											return 0;
										}
									}
									else {
										return 0;
									}
								}
								else {
									return 1;
								}
							}
						}
					}
					else {
						if (ptr[62] <= 0) {
							if (ptr[26] <= 0) {
								if (ptr[63] <= 0) {
									if (ptr[11] <= 2) {
										if (ptr[37] <= 5) {
											if (ptr[34] <= 25) {
												if (ptr[61] <= 0) {
													return 1;
												}
												else {
													return 0;
												}
											}
											else {
												return 1;//short version
											}
										}
										else {
											if (ptr[13] <= 0) {
												if (ptr[74] <= 0) {
													return 1;
												}
												else {
													return 0;
												}
											}
											else {
												return 0;
											}
										}
									}
									else {
										if (ptr[50] <= 0) {
											if (ptr[20] <= 12) {
												return 0;//short version
											}
											else {
												return 1;
											}
										}
										else {
											if (ptr[23] <= 2) {
												return 1;
											}
											else {
												return 0;
											}
										}
									}
								}
								else {
									if (ptr[70] <= 0) {
										if (ptr[64] <= 5) {
											if (ptr[54] <= 0) {
												if (ptr[6] <= 20) {
													return 0;
												}
												else {
													return 1;
												}
											}
											else {
												return 1;
											}
										}
										else {
											return 0;
										}
									}
									else {
										if (ptr[11] <= 0) {
											return 1;
										}
										else {
											return 0;
										}
									}
								}
							}
							else {
								if (ptr[33] <= 5) {
									if (ptr[37] <= 22) {
										if (ptr[25] <= 2) {
											return 0;
										}
										else {
											if (ptr[19] <= 12) {
												return 0;//short version
											}
											else {
												return 0;
											}
										}
									}
									else {
										return 1;
									}
								}
								else {
									if (ptr[34] <= 7) {
										return 0;
									}
									else {
										return 1;
									}
								}
							}
						}
						else {
							if (ptr[56] <= 0) {
								if (ptr[70] <= 0) {
									if (ptr[32] <= 15) {
										if (ptr[38] <= 2) {
											if (ptr[76] <= 0) {
												if (ptr[69] <= 0) {
													return 0;
												}
												else {
													return 1;
												}
											}
											else {
												return 1;
											}
										}
										else {
											return 1;
										}
									}
									else {
										return 0;
									}
								}
								else {
									return 1;
								}
							}
							else {
								return 1;
							}
						}
					}
				}
				else {
					if (ptr[13] <= 0) {
						if (ptr[17] <= 10) {
							if (ptr[26] <= 0) {
								if (ptr[71] <= 0) {
									if (ptr[20] <= 15) {
										if (ptr[11] <= 5) {
											if (ptr[38] <= 5) {
												return 0;//short version
											}
											else {
												return 0;
											}
										}
										else {
											if (ptr[16] <= 5) {
												if (ptr[34] <= 20) {
													return 0;
												}
												else {
													return 1;
												}
											}
											else {
												return 0;
											}
										}
									}
									else {
										return 1;
									}
								}
								else {
									if (ptr[31] <= 5) {
										if (ptr[61] <= 0) {
											if (ptr[34] <= 10) {
												if (ptr[33] <= 10) {
													return 0;
												}
												else {
													return 1;
												}
											}
											else {
												return 1;
											}
										}
										else {
											return 1;
										}
									}
									else {
										return 0;
									}
								}
							}
							else {
								if (ptr[35] <= 15) {
									if (ptr[19] <= 12) {
										if (ptr[39] <= 22) {
											if (ptr[32] <= 15) {
												return 0;//short version
											}
											else {
												return 1;
											}
										}
										else {
											return 0;
										}
									}
									else {
										return 0;
									}
								}
								else {
									return 0;
								}
							}
						}
						else {
							if (ptr[19] <= 2) {
								return 0;
							}
							else {
								if (ptr[34] <= 5) {
									return 0;
								}
								else {
									return 1;
								}
							}
						}
					}
					else {
						if (ptr[18] <= 10) {
							if (ptr[18] <= 2) {
								if (ptr[34] <= 7) {
									if (ptr[49] <= 15) {
										if (ptr[19] <= 12) {
											if (ptr[38] <= 26) {
												return 0;//short version
											}
											else {
												return 1;
											}
										}
										else {
											return 0;
										}
									}
									else {
										return 1;
									}
								}
								else {
									return 0;//short version
								}
							}
							else {
								if (ptr[19] <= 22) {
									if (ptr[35] <= 7) {
										if (ptr[50] <= 12) {
											if (ptr[15] <= 0) {
												if (ptr[1] <= 20) {
													return 0;
												}
												else {
													return 1;
												}
											}
											else {
												return 1;
											}
										}
										else {
											return 1;
										}
									}
									else {
										if (ptr[16] <= 0) {
											return 0;//short version
										}
										else {
											return 0;
										}
									}
								}
								else {
									return 1;
								}
							}
						}
						else {
							if (ptr[35] <= 10) {
								if (ptr[33] <= 10) {
									return 0;//short version
								}
								else {
									return 1;
								}
							}
							else {
								return 1;
							}
						}
					}
				}
			}
			else {
				if (ptr[16] <= 12) {
					if (ptr[3] <= 0) {
						if (ptr[8] <= 2) {
							if (ptr[38] <= 0) {
								if (ptr[74] <= 2) {
									if (ptr[6] <= 22) {
										if (ptr[7] <= 0) {
											if (ptr[62] <= 5) {
												return 1;//short version
											}
											else {
												if (ptr[61] <= 15) {
													return 1;
												}
												else {
													return 0;
												}
											}
										}
										else {
											if (ptr[37] <= 2) {
												return 0;//short version
											}
											else {
												return 1;
											}
										}
									}
									else {
										if (ptr[16] <= 5) {
											if (ptr[36] <= 0) {
												if (ptr[19] <= 34) {
													return 0;
												}
												else {
													return 1;
												}
											}
											else {
												return 1;
											}
										}
										else {
											if (ptr[22] <= 1) {
												if (ptr[30] <= 5) {
													return 0;
												}
												else {
													return 1;
												}
											}
											else {
												return 1;
											}
										}
									}
								}
								else {
									if (ptr[6] <= 0) {
										return 1;
									}
									else {
										return 0;
									}
								}
							}
							else {
								if (ptr[12] <= 7) {
									if (ptr[72] <= 5) {
										return 1;//short version
									}
									else {
										return 0;
									}
								}
								else {
									return 0;
								}
							}
						}
						else {
							if (ptr[22] <= 0) {
								if (ptr[37] <= 1) {
									if (ptr[61] <= 0) {
										if (ptr[7] <= 20) {
											if (ptr[6] <= 22) {
												if (ptr[52] <= 0) {
													return 0;
												}
												else {
													return 1;
												}
											}
											else {
												return 0;
											}
										}
										else {
											return 0;//short version
										}
									}
									else {
										return 0;
									}
								}
								else {
									return 1;
								}
							}
							else {
								return 1;
							}
						}
					}
					else {
						if (ptr[38] <= 0) {
							if (ptr[23] <= 5) {
								if (ptr[30] <= 29) {
									if (ptr[39] <= 0) {
										if (ptr[46] <= 43) {
											if (ptr[17] <= 68) {
												if (ptr[32] <= 58) {
													return 0;
												}
												else {
													return 1;
												}
											}
											else {
												return 1;
											}
										}
										else {
											return 1;
										}
									}
									else {
										return 1;
									}
								}
								else {
									return 1;
								}
							}
							else {
								return 1;
							}
						}
						else {
							return 1;
						}
					}
				}
				else {
					if (ptr[2] <= 0) {
						if (ptr[7] <= 7) {
							if (ptr[31] <= 30) {
								if (ptr[19] <= 17) {
									if (ptr[17] <= 68) {
										if (ptr[61] <= 7) {
											if (ptr[59] <= 7) {
												return 1;//short version
											}
											else {
												return 0;
											}
										}
										else {
											return 0;
										}
									}
									else {
										if (ptr[6] <= 89) {
											return 1;//short version
										}
										else {
											return 0;
										}
									}
								}
								else {
									return 1;
								}
							}
							else {
								if (ptr[46] <= 68) {
									if (ptr[61] <= 15) {
										if (ptr[17] <= 28) {
											return 1;
										}
										else {
											if (ptr[75] <= 7) {
												return 1;//short version
											}
											else {
												return 0;
											}
										}
									}
									else {
										return 1;
									}
								}
								else {
									return 0;
								}
							}
						}
						else {
							if (ptr[5] <= 5) {
								if (ptr[15] <= 5) {
									if (ptr[33] <= 7) {
										return 0;
									}
									else {
										return 1;
									}
								}
								else {
									return 1;
								}
							}
							else {
								return 1;
							}
						}
					}
					else {
						return 0;//short version
					}
				}
			}
		}
		else {
			if (ptr[34] <= 7) {
				if (ptr[35] <= 7) {
					if (ptr[16] <= 2) {
						if (ptr[8] <= 29) {
							if (ptr[19] <= 25) {
								if (ptr[48] <= 15) {
									if (ptr[36] <= 2) {
										if (ptr[33] <= 15) {
											if (ptr[6] <= 39) {
												if (ptr[9] <= 25) {
													return 0;
												}
												else {
													return 1;
												}
											}
											else {
												return 1;
											}
										}
										else {
											return 1;
										}
									}
									else {
										if (ptr[39] <= 25) {
											if (ptr[58] <= 25) {
												if (ptr[17] <= 34) {
													return 0;
												}
												else {
													return 1;
												}
											}
											else {
												return 1;
											}
										}
										else {
											return 0;
										}
									}
								}
								else {
									return 1;
								}
							}
							else {
								return 1;
							}
						}
						else {
							return 1;
						}
					}
					else {
						if (ptr[37] <= 12) {
							if (ptr[10] <= 2) {
								if (ptr[58] <= 20) {
									if (ptr[19] <= 22) {
										if (ptr[53] <= 17) {
											if (ptr[49] <= 15) {
												if (ptr[17] <= 44) {
													return 0;
												}
												else {
													return 1;
												}
											}
											else {
												return 1;
											}
										}
										else {
											return 1;
										}
									}
									else {
										return 1;
									}
								}
								else {
									return 1;
								}
							}
							else {
								if (ptr[38] <= 21) {
									if (ptr[6] <= 28) {
										if (ptr[72] <= 0) {
											if (ptr[39] <= 17) {
												if (ptr[21] <= 22) {
													return 0;
												}
												else {
													return 1;
												}
											}
											else {
												return 1;
											}
										}
										else {
											return 0;
										}
									}
									else {
										return 1;
									}
								}
								else {
									return 1;
								}
							}
						}
						else {
							return 0;
						}
					}
				}
				else {
					if (ptr[30] <= 10) {
						if (ptr[20] <= 10) {
							if (ptr[20] <= 2) {
								if (ptr[13] <= 0) {
									if (ptr[63] <= 2) {
										if (ptr[38] <= 17) {
											if (ptr[30] <= 7) {
												return 0;//short version
											}
											else {
												return 1;
											}
										}
										else {
											return 1;
										}
									}
									else {
										return 1;
									}
								}
								else {
									if (ptr[41] <= 25) {
										if (ptr[51] <= 5) {
											if (ptr[45] <= 0) {
												return 0;//short version
											}
											else {
												return 1;
											}
										}
										else {
											return 0;
										}
									}
									else {
										return 0;
									}
								}
							}
							else {
								if (ptr[36] <= 25) {
									if (ptr[38] <= 15) {
										if (ptr[19] <= 12) {
											if (ptr[23] <= 28) {
												return 0;//short version
											}
											else {
												return 1;
											}
										}
										else {
											return 0;
										}
									}
									else {
										return 1;
									}
								}
								else {
									return 1;
								}
							}
						}
						else {
							return 0;
						}
					}
					else {
						return 1;
					}
				}
			}
			else {
				if (ptr[35] <= 12) {
					if (ptr[14] <= 0) {
						return 0;//short version
					}
					else {
						if (ptr[39] <= 24) {
							if (ptr[5] <= 12) {
								if (ptr[26] <= 7) {
									return 0;//short version
								}
								else {
									return 0;
								}
							}
							else {
								return 1;
							}
						}
						else {
							return 1;
						}
					}
				}
				else {
					return 0;
				}
			}
		}
	}
	unsigned char predict_7(unsigned char ptr[]) {
		if (ptr[30] <= 5) {
			if (ptr[27] <= 0) {
				if (ptr[37] <= 2) {
					if (ptr[17] <= 28) {
						if (ptr[68] <= 2) {
							if (ptr[7] <= 0) {
								if (ptr[9] <= 0) {
									if (ptr[46] <= 7) {
										if (ptr[18] <= 0) {
											if (ptr[36] <= 0) {
												if (ptr[14] <= 0) {
													return 1;
												}
												else {
													return 0;
												}
											}
											else {
												return 0;//short version
											}
										}
										else {
											if (ptr[31] <= 15) {
												return 0;//short version
											}
											else {
												if (ptr[19] <= 7) {
													return 1;
												}
												else {
													return 0;
												}
											}
										}
									}
									else {
										if (ptr[48] <= 12) {
											if (ptr[20] <= 0) {
												if (ptr[19] <= 10) {
													return 1;
												}
												else {
													return 0;
												}
											}
											else {
												return 0;
											}
										}
										else {
											if (ptr[18] <= 2) {
												if (ptr[6] <= 20) {
													return 1;
												}
												else {
													return 0;
												}
											}
											else {
												if (ptr[6] <= 2) {
													return 1;
												}
												else {
													return 0;
												}
											}
										}
									}
								}
								else {
									if (ptr[38] <= 2) {
										if (ptr[40] <= 10) {
											if (ptr[23] <= 10) {
												if (ptr[8] <= 51) {
													return 0;
												}
												else {
													return 1;
												}
											}
											else {
												return 0;
											}
										}
										else {
											return 0;
										}
									}
									else {
										if (ptr[36] <= 12) {
											return 0;
										}
										else {
											return 1;
										}
									}
								}
							}
							else {
								if (ptr[63] <= 0) {
									if (ptr[23] <= 2) {
										if (ptr[54] <= 2) {
											if (ptr[53] <= 2) {
												return 0;//short version
											}
											else {
												return 1;
											}
										}
										else {
											if (ptr[26] <= 0) {
												if (ptr[34] <= 2) {
													return 0;
												}
												else {
													return 1;
												}
											}
											else {
												return 0;
											}
										}
									}
									else {
										if (ptr[14] <= 0) {
											if (ptr[19] <= 10) {
												return 0;//short version
											}
											else {
												return 1;//short version
											}
										}
										else {
											if (ptr[17] <= 15) {
												if (ptr[19] <= 17) {
													return 0;
												}
												else {
													return 1;
												}
											}
											else {
												return 1;
											}
										}
									}
								}
								else {
									if (ptr[53] <= 2) {
										if (ptr[48] <= 38) {
											if (ptr[8] <= 0) {
												if (ptr[46] <= 22) {
													return 0;
												}
												else {
													return 1;
												}
											}
											else {
												return 0;//short version
											}
										}
										else {
											return 0;
										}
									}
									else {
										return 1;
									}
								}
							}
						}
						else {
							if (ptr[11] <= 0) {
								if (ptr[50] <= 2) {
									if (ptr[43] <= 0) {
										if (ptr[12] <= 0) {
											if (ptr[42] <= 0) {
												if (ptr[10] <= 0) {
													return 1;
												}
												else {
													return 0;
												}
											}
											else {
												return 0;
											}
										}
										else {
											return 0;
										}
									}
									else {
										return 0;
									}
								}
								else {
									if (ptr[43] <= 2) {
										if (ptr[34] <= 0) {
											return 0;
										}
										else {
											if (ptr[9] <= 5) {
												if (ptr[26] <= 5) {
													return 1;
												}
												else {
													return 0;
												}
											}
											else {
												return 0;
											}
										}
									}
									else {
										return 0;
									}
								}
							}
							else {
								if (ptr[19] <= 17) {
									if (ptr[32] <= 10) {
										if (ptr[64] <= 7) {
											if (ptr[52] <= 22) {
												if (ptr[20] <= 22) {
													return 0;
												}
												else {
													return 1;
												}
											}
											else {
												return 1;
											}
										}
										else {
											return 1;
										}
									}
									else {
										return 1;
									}
								}
								else {
									return 1;
								}
							}
						}
					}
					else {
						if (ptr[6] <= 7) {
							if (ptr[16] <= 12) {
								if (ptr[19] <= 7) {
									if (ptr[30] <= 0) {
										return 1;//short version
									}
									else {
										if (ptr[18] <= 22) {
											return 1;//short version
										}
										else {
											return 1;
										}
									}
								}
								else {
									if (ptr[7] <= 17) {
										if (ptr[20] <= 15) {
											if (ptr[62] <= 0) {
												return 1;
											}
											else {
												return 0;
											}
										}
										else {
											return 0;
										}
									}
									else {
										return 0;
									}
								}
							}
							else {
								if (ptr[17] <= 38) {
									return 1;
								}
								else {
									if (ptr[19] <= 58) {
										if (ptr[8] <= 5) {
											if (ptr[21] <= 8) {
												return 1;//short version
											}
											else {
												return 0;
											}
										}
										else {
											return 0;
										}
									}
									else {
										return 0;
									}
								}
							}
						}
						else {
							if (ptr[54] <= 1) {
								if (ptr[62] <= 0) {
									if (ptr[3] <= 0) {
										if (ptr[46] <= 0) {
											if (ptr[2] <= 2) {
												if (ptr[8] <= 7) {
													return 1;
												}
												else {
													return 0;
												}
											}
											else {
												return 0;
											}
										}
										else {
											if (ptr[32] <= 28) {
												if (ptr[31] <= 75) {
													return 0;
												}
												else {
													return 1;
												}
											}
											else {
												return 0;
											}
										}
									}
									else {
										if (ptr[24] <= 1) {
											if (ptr[17] <= 58) {
												if (ptr[52] <= 1) {
													return 0;
												}
												else {
													return 1;
												}
											}
											else {
												return 0;
											}
										}
										else {
											return 1;
										}
									}
								}
								else {
									if (ptr[7] <= 15) {
										return 0;//short version
									}
									else {
										return 0;
									}
								}
							}
							else {
								return 1;
							}
						}
					}
				}
				else {
					if (ptr[33] <= 5) {
						if (ptr[19] <= 12) {
							if (ptr[34] <= 5) {
								if (ptr[37] <= 15) {
									if (ptr[24] <= 0) {
										if (ptr[10] <= 2) {
											if (ptr[52] <= 2) {
												if (ptr[38] <= 7) {
													return 0;
												}
												else {
													return 1;
												}
											}
											else {
												if (ptr[14] <= 0) {
													return 1;
												}
												else {
													return 0;
												}
											}
										}
										else {
											if (ptr[18] <= 10) {
												if (ptr[17] <= 20) {
													return 0;
												}
												else {
													return 1;
												}
											}
											else {
												return 0;
											}
										}
									}
									else {
										if (ptr[12] <= 0) {
											if (ptr[39] <= 12) {
												return 0;//short version
											}
											else {
												if (ptr[77] <= 0) {
													return 1;
												}
												else {
													return 0;
												}
											}
										}
										else {
											if (ptr[14] <= 5) {
												if (ptr[21] <= 30) {
													return 0;
												}
												else {
													return 1;
												}
											}
											else {
												return 0;//short version
											}
										}
									}
								}
								else {
									if (ptr[2] <= 5) {
										if (ptr[11] <= 2) {
											if (ptr[12] <= 0) {
												if (ptr[13] <= 0) {
													return 1;
												}
												else {
													return 0;
												}
											}
											else {
												return 0;
											}
										}
										else {
											if (ptr[21] <= 25) {
												return 0;//short version
											}
											else {
												return 1;
											}
										}
									}
									else {
										return 0;
									}
								}
							}
							else {
								if (ptr[12] <= 2) {
									if (ptr[63] <= 0) {
										if (ptr[10] <= 2) {
											if (ptr[37] <= 12) {
												if (ptr[25] <= 5) {
													return 1;
												}
												else {
													return 0;
												}
											}
											else {
												if (ptr[11] <= 5) {
													return 1;
												}
												else {
													return 0;
												}
											}
										}
										else {
											if (ptr[52] <= 5) {
												if (ptr[25] <= 12) {
													return 1;
												}
												else {
													return 0;
												}
											}
											else {
												return 0;
											}
										}
									}
									else {
										if (ptr[54] <= 0) {
											if (ptr[39] <= 0) {
												return 0;
											}
											else {
												return 1;
											}
										}
										else {
											return 1;
										}
									}
								}
								else {
									if (ptr[35] <= 12) {
										if (ptr[54] <= 12) {
											if (ptr[40] <= 20) {
												if (ptr[58] <= 12) {
													return 0;
												}
												else {
													return 1;
												}
											}
											else {
												return 1;
											}
										}
										else {
											return 1;
										}
									}
									else {
										return 0;
									}
								}
							}
						}
						else {
							if (ptr[75] <= 0) {
								if (ptr[34] <= 5) {
									if (ptr[11] <= 2) {
										if (ptr[20] <= 10) {
											return 1;
										}
										else {
											if (ptr[62] <= 2) {
												if (ptr[67] <= 0) {
													return 1;
												}
												else {
													return 0;
												}
											}
											else {
												return 0;
											}
										}
									}
									else {
										return 0;
									}
								}
								else {
									if (ptr[62] <= 0) {
										if (ptr[48] <= 7) {
											if (ptr[52] <= 28) {
												return 1;//short version
											}
											else {
												return 0;
											}
										}
										else {
											return 0;
										}
									}
									else {
										return 0;
									}
								}
							}
							else {
								return 0;
							}
						}
					}
					else {
						if (ptr[75] <= 0) {
							if (ptr[11] <= 2) {
								if (ptr[62] <= 0) {
									if (ptr[12] <= 5) {
										if (ptr[38] <= 0) {
											if (ptr[47] <= 0) {
												return 1;//short version
											}
											else {
												return 0;//short version
											}
										}
										else {
											if (ptr[63] <= 7) {
												return 1;//short version
											}
											else {
												return 0;
											}
										}
									}
									else {
										return 0;
									}
								}
								else {
									if (ptr[54] <= 0) {
										return 0;
									}
									else {
										return 1;
									}
								}
							}
							else {
								if (ptr[25] <= 5) {
									if (ptr[13] <= 2) {
										if (ptr[11] <= 7) {
											if (ptr[70] <= 2) {
												if (ptr[10] <= 12) {
													return 1;
												}
												else {
													return 0;
												}
											}
											else {
												return 0;
											}
										}
										else {
											return 0;
										}
									}
									else {
										return 0;
									}
								}
								else {
									return 0;//short version
								}
							}
						}
						else {
							if (ptr[42] <= 0) {
								if (ptr[70] <= 0) {
									if (ptr[71] <= 1) {
										if (ptr[76] <= 2) {
											if (ptr[34] <= 38) {
												if (ptr[41] <= 5) {
													return 0;
												}
												else {
													return 1;
												}
											}
											else {
												return 0;
											}
										}
										else {
											return 1;
										}
									}
									else {
										return 1;
									}
								}
								else {
									return 1;
								}
							}
							else {
								return 1;
							}
						}
					}
				}
			}
			else {
				if (ptr[37] <= 10) {
					if (ptr[34] <= 7) {
						if (ptr[19] <= 17) {
							if (ptr[32] <= 2) {
								if (ptr[33] <= 7) {
									if (ptr[35] <= 5) {
										if (ptr[5] <= 10) {
											if (ptr[16] <= 17) {
												return 0;//short version
											}
											else {
												return 1;
											}
										}
										else {
											return 0;
										}
									}
									else {
										if (ptr[40] <= 25) {
											if (ptr[13] <= 0) {
												if (ptr[7] <= 12) {
													return 0;
												}
												else {
													return 1;
												}
											}
											else {
												if (ptr[46] <= 7) {
													return 0;
												}
												else {
													return 1;
												}
											}
										}
										else {
											return 1;
										}
									}
								}
								else {
									if (ptr[17] <= 12) {
										if (ptr[40] <= 12) {
											return 0;//short version
										}
										else {
											return 1;
										}
									}
									else {
										return 1;
									}
								}
							}
							else {
								if (ptr[36] <= 7) {
									if (ptr[19] <= 12) {
										if (ptr[14] <= 0) {
											if (ptr[32] <= 17) {
												if (ptr[55] <= 20) {
													return 0;
												}
												else {
													return 1;
												}
											}
											else {
												return 1;
											}
										}
										else {
											if (ptr[11] <= 17) {
												return 0;//short version
											}
											else {
												return 0;
											}
										}
									}
									else {
										return 0;
									}
								}
								else {
									if (ptr[13] <= 0) {
										return 0;//short version
									}
									else {
										return 0;//short version
									}
								}
							}
						}
						else {
							return 1;
						}
					}
					else {
						if (ptr[19] <= 10) {
							if (ptr[32] <= 5) {
								if (ptr[18] <= 17) {
									if (ptr[33] <= 7) {
										if (ptr[16] <= 5) {
											if (ptr[17] <= 24) {
												if (ptr[15] <= 0) {
													return 0;
												}
												else {
													return 1;
												}
											}
											else {
												return 1;
											}
										}
										else {
											return 0;
										}
									}
									else {
										return 0;
									}
								}
								else {
									return 1;
								}
							}
							else {
								return 0;
							}
						}
						else {
							return 1;
						}
					}
				}
				else {
					if (ptr[12] <= 0) {
						if (ptr[35] <= 10) {
							if (ptr[13] <= 0) {
								if (ptr[28] <= 2) {
									if (ptr[21] <= 10) {
										if (ptr[26] <= 0) {
											return 1;
										}
										else {
											return 0;
										}
									}
									else {
										return 1;
									}
								}
								else {
									return 0;
								}
							}
							else {
								if (ptr[34] <= 17) {
									if (ptr[20] <= 15) {
										return 0;//short version
									}
									else {
										return 1;
									}
								}
								else {
									return 1;
								}
							}
						}
						else {
							if (ptr[10] <= 2) {
								if (ptr[26] <= 5) {
									return 1;
								}
								else {
									return 0;
								}
							}
							else {
								return 0;
							}
						}
					}
					else {
						if (ptr[33] <= 7) {
							if (ptr[52] <= 29) {
								if (ptr[20] <= 20) {
									if (ptr[14] <= 0) {
										if (ptr[20] <= 7) {
											if (ptr[35] <= 10) {
												if (ptr[21] <= 20) {
													return 0;
												}
												else {
													return 1;
												}
											}
											else {
												return 0;
											}
										}
										else {
											return 0;
										}
									}
									else {
										if (ptr[19] <= 17) {
											if (ptr[21] <= 28) {
												return 0;//short version
											}
											else {
												return 1;
											}
										}
										else {
											return 1;
										}
									}
								}
								else {
									return 1;
								}
							}
							else {
								return 1;
							}
						}
						else {
							return 0;
						}
					}
				}
			}
		}
		else {
			if (ptr[7] <= 0) {
				if (ptr[32] <= 20) {
					if (ptr[30] <= 12) {
						if (ptr[25] <= 0) {
							if (ptr[20] <= 0) {
								if (ptr[19] <= 0) {
									if (ptr[6] <= 25) {
										if (ptr[2] <= 7) {
											if (ptr[21] <= 0) {
												if (ptr[9] <= 0) {
													return 1;
												}
												else {
													return 0;
												}
											}
											else {
												return 1;
											}
										}
										else {
											return 0;
										}
									}
									else {
										return 0;
									}
								}
								else {
									if (ptr[8] <= 0) {
										if (ptr[17] <= 63) {
											if (ptr[19] <= 20) {
												if (ptr[36] <= 57) {
													return 1;
												}
												else {
													return 0;
												}
											}
											else {
												return 0;
											}
										}
										else {
											return 1;
										}
									}
									else {
										return 0;
									}
								}
							}
							else {
								if (ptr[40] <= 0) {
									if (ptr[48] <= 0) {
										if (ptr[55] <= 0) {
											if (ptr[70] <= 1) {
												if (ptr[38] <= 5) {
													return 0;
												}
												else {
													return 1;
												}
											}
											else {
												return 1;
											}
										}
										else {
											return 1;
										}
									}
									else {
										if (ptr[38] <= 1) {
											return 0;//short version
										}
										else {
											return 1;
										}
									}
								}
								else {
									return 1;
								}
							}
						}
						else {
							return 0;//short version
						}
					}
					else {
						if (ptr[25] <= 2) {
							if (ptr[2] <= 7) {
								if (ptr[6] <= 5) {
									if (ptr[1] <= 5) {
										if (ptr[46] <= 79) {
											if (ptr[19] <= 20) {
												return 1;//short version
											}
											else {
												return 1;
											}
										}
										else {
											return 0;
										}
									}
									else {
										return 0;
									}
								}
								else {
									if (ptr[30] <= 15) {
										return 1;
									}
									else {
										if (ptr[64] <= 1) {
											if (ptr[1] <= 12) {
												if (ptr[49] <= 12) {
													return 1;
												}
												else {
													return 0;
												}
											}
											else {
												return 0;
											}
										}
										else {
											return 0;
										}
									}
								}
							}
							else {
								return 0;
							}
						}
						else {
							return 0;
						}
					}
				}
				else {
					if (ptr[2] <= 2) {
						if (ptr[35] <= 7) {
							if (ptr[31] <= 22) {
								if (ptr[31] <= 12) {
									if (ptr[19] <= 38) {
										return 1;
									}
									else {
										return 0;
									}
								}
								else {
									if (ptr[16] <= 0) {
										return 1;
									}
									else {
										if (ptr[31] <= 15) {
											return 1;
										}
										else {
											if (ptr[61] <= 25) {
												if (ptr[19] <= 40) {
													return 1;
												}
												else {
													return 0;
												}
											}
											else {
												return 0;
											}
										}
									}
								}
							}
							else {
								if (ptr[1] <= 11) {
									if (ptr[32] <= 33) {
										if (ptr[50] <= 28) {
											if (ptr[16] <= 7) {
												return 1;//short version
											}
											else {
												if (ptr[5] <= 47) {
													return 1;
												}
												else {
													return 0;
												}
											}
										}
										else {
											return 0;
										}
									}
									else {
										if (ptr[63] <= 33) {
											if (ptr[6] <= 7) {
												return 1;//short version
											}
											else {
												return 1;
											}
										}
										else {
											return 1;
										}
									}
								}
								else {
									return 0;
								}
							}
						}
						else {
							return 1;//short version
						}
					}
					else {
						return 0;
					}
				}
			}
			else {
				if (ptr[37] <= 2) {
					if (ptr[9] <= 0) {
						if (ptr[3] <= 0) {
							if (ptr[7] <= 10) {
								if (ptr[16] <= 15) {
									if (ptr[8] <= 0) {
										if (ptr[20] <= 0) {
											if (ptr[32] <= 10) {
												return 0;
											}
											else {
												return 1;//short version
											}
										}
										else {
											return 0;
										}
									}
									else {
										if (ptr[23] <= 2) {
											if (ptr[67] <= 2) {
												if (ptr[69] <= 5) {
													return 0;
												}
												else {
													return 1;
												}
											}
											else {
												return 1;
											}
										}
										else {
											return 1;
										}
									}
								}
								else {
									if (ptr[2] <= 2) {
										return 1;//short version
									}
									else {
										return 0;
									}
								}
							}
							else {
								if (ptr[56] <= 5) {
									if (ptr[16] <= 5) {
										if (ptr[52] <= 8) {
											if (ptr[33] <= 73) {
												return 0;//short version
											}
											else {
												return 1;
											}
										}
										else {
											return 1;
										}
									}
									else {
										if (ptr[8] <= 2) {
											if (ptr[31] <= 40) {
												return 0;//short version
											}
											else {
												return 1;
											}
										}
										else {
											return 0;
										}
									}
								}
								else {
									return 1;
								}
							}
						}
						else {
							if (ptr[32] <= 48) {
								if (ptr[5] <= 17) {
									if (ptr[31] <= 57) {
										if (ptr[10] <= 20) {
											if (ptr[16] <= 15) {
												if (ptr[74] <= 6) {
													return 0;
												}
												else {
													return 1;
												}
											}
											else {
												return 0;
											}
										}
										else {
											return 1;
										}
									}
									else {
										return 1;
									}
								}
								else {
									return 0;
								}
							}
							else {
								return 1;
							}
						}
					}
					else {
						if (ptr[10] <= 0) {
							if (ptr[16] <= 5) {
								if (ptr[72] <= 7) {
									return 0;//short version
								}
								else {
									return 0;
								}
							}
							else {
								return 0;
							}
						}
						else {
							return 0;
						}
					}
				}
				else {
					if (ptr[35] <= 10) {
						if (ptr[13] <= 0) {
							if (ptr[19] <= 0) {
								return 0;
							}
							else {
								return 1;//short version
							}
						}
						else {
							return 0;
						}
					}
					else {
						if (ptr[10] <= 15) {
							if (ptr[75] <= 0) {
								if (ptr[35] <= 30) {
									if (ptr[26] <= 5) {
										if (ptr[49] <= 15) {
											if (ptr[11] <= 10) {
												if (ptr[21] <= 33) {
													return 1;
												}
												else {
													return 0;
												}
											}
											else {
												return 0;
											}
										}
										else {
											return 0;
										}
									}
									else {
										return 1;
									}
								}
								else {
									return 1;
								}
							}
							else {
								return 0;
							}
						}
						else {
							return 0;
						}
					}
				}
			}
		}
	}
	unsigned char predict_8(unsigned char ptr[]) {
		if (ptr[16] <= 10) {
			if (ptr[31] <= 22) {
				if (ptr[36] <= 7) {
					if (ptr[26] <= 0) {
						if (ptr[37] <= 2) {
							if (ptr[19] <= 0) {
								if (ptr[2] <= 0) {
									if (ptr[42] <= 0) {
										if (ptr[31] <= 5) {
											if (ptr[6] <= 0) {
												if (ptr[14] <= 0) {
													return 1;
												}
												else {
													return 0;
												}
											}
											else {
												if (ptr[76] <= 2) {
													return 0;
												}
												else {
													return 1;
												}
											}
										}
										else {
											if (ptr[7] <= 0) {
												if (ptr[6] <= 15) {
													return 1;
												}
												else {
													return 0;
												}
											}
											else {
												if (ptr[38] <= 2) {
													return 0;
												}
												else {
													return 1;
												}
											}
										}
									}
									else {
										if (ptr[33] <= 7) {
											if (ptr[32] <= 10) {
												return 0;//short version
											}
											else {
												return 1;
											}
										}
										else {
											return 1;
										}
									}
								}
								else {
									if (ptr[65] <= 5) {
										if (ptr[9] <= 20) {
											if (ptr[50] <= 2) {
												return 0;//short version
											}
											else {
												return 0;
											}
										}
										else {
											return 1;
										}
									}
									else {
										return 0;
									}
								}
							}
							else {
								if (ptr[53] <= 2) {
									if (ptr[63] <= 0) {
										if (ptr[47] <= 0) {
											if (ptr[22] <= 5) {
												return 0;//short version
											}
											else {
												if (ptr[18] <= 7) {
													return 0;
												}
												else {
													return 1;
												}
											}
										}
										else {
											if (ptr[66] <= 2) {
												return 0;//short version
											}
											else {
												return 0;
											}
										}
									}
									else {
										if (ptr[49] <= 30) {
											if (ptr[30] <= 5) {
												return 0;//short version
											}
											else {
												return 0;//short version
											}
										}
										else {
											return 0;
										}
									}
								}
								else {
									if (ptr[23] <= 0) {
										if (ptr[25] <= 2) {
											if (ptr[24] <= 2) {
												if (ptr[63] <= 12) {
													return 1;
												}
												else {
													return 0;
												}
											}
											else {
												return 0;
											}
										}
										else {
											return 0;
										}
									}
									else {
										if (ptr[34] <= 7) {
											return 0;
										}
										else {
											return 1;
										}
									}
								}
							}
						}
						else {
							if (ptr[27] <= 0) {
								if (ptr[12] <= 0) {
									if (ptr[18] <= 12) {
										if (ptr[10] <= 5) {
											if (ptr[75] <= 0) {
												if (ptr[31] <= 0) {
													return 0;
												}
												else {
													return 1;
												}
											}
											else {
												return 0;
											}
										}
										else {
											if (ptr[17] <= 17) {
												return 0;//short version
											}
											else {
												return 1;
											}
										}
									}
									else {
										if (ptr[63] <= 7) {
											if (ptr[25] <= 10) {
												if (ptr[77] <= 5) {
													return 1;
												}
												else {
													return 0;
												}
											}
											else {
												return 0;
											}
										}
										else {
											return 0;
										}
									}
								}
								else {
									if (ptr[31] <= 2) {
										if (ptr[17] <= 10) {
											if (ptr[20] <= 20) {
												if (ptr[35] <= 22) {
													return 0;
												}
												else {
													return 1;
												}
											}
											else {
												return 1;
											}
										}
										else {
											return 0;
										}
									}
									else {
										if (ptr[34] <= 5) {
											if (ptr[16] <= 5) {
												return 0;//short version
											}
											else {
												return 1;
											}
										}
										else {
											return 0;
										}
									}
								}
							}
							else {
								if (ptr[33] <= 10) {
									if (ptr[14] <= 0) {
										if (ptr[38] <= 10) {
											if (ptr[19] <= 10) {
												return 0;//short version
											}
											else {
												return 0;
											}
										}
										else {
											return 0;
										}
									}
									else {
										if (ptr[39] <= 28) {
											if (ptr[34] <= 10) {
												if (ptr[10] <= 25) {
													return 0;
												}
												else {
													return 1;
												}
											}
											else {
												return 0;
											}
										}
										else {
											return 1;
										}
									}
								}
								else {
									return 1;
								}
							}
						}
					}
					else {
						if (ptr[32] <= 2) {
							if (ptr[21] <= 15) {
								if (ptr[33] <= 2) {
									if (ptr[8] <= 17) {
										if (ptr[17] <= 38) {
											if (ptr[28] <= 0) {
												if (ptr[58] <= 26) {
													return 0;
												}
												else {
													return 1;
												}
											}
											else {
												if (ptr[66] <= 15) {
													return 0;
												}
												else {
													return 1;
												}
											}
										}
										else {
											return 1;
										}
									}
									else {
										return 0;
									}
								}
								else {
									if (ptr[18] <= 10) {
										if (ptr[35] <= 17) {
											if (ptr[38] <= 26) {
												return 0;//short version
											}
											else {
												return 1;
											}
										}
										else {
											return 0;
										}
									}
									else {
										return 0;
									}
								}
							}
							else {
								return 0;//short version
							}
						}
						else {
							if (ptr[33] <= 7) {
								if (ptr[20] <= 7) {
									if (ptr[7] <= 24) {
										if (ptr[35] <= 7) {
											if (ptr[14] <= 0) {
												return 0;//short version
											}
											else {
												return 0;//short version
											}
										}
										else {
											return 0;//short version
										}
									}
									else {
										return 1;
									}
								}
								else {
									if (ptr[17] <= 10) {
										if (ptr[18] <= 10) {
											return 0;//short version
										}
										else {
											return 1;
										}
									}
									else {
										return 1;
									}
								}
							}
							else {
								if (ptr[16] <= 5) {
									if (ptr[39] <= 7) {
										return 0;//short version
									}
									else {
										return 0;
									}
								}
								else {
									return 1;
								}
							}
						}
					}
				}
				else {
					if (ptr[13] <= 0) {
						if (ptr[38] <= 0) {
							if (ptr[63] <= 0) {
								if (ptr[52] <= 2) {
									if (ptr[37] <= 2) {
										if (ptr[6] <= 20) {
											if (ptr[70] <= 7) {
												if (ptr[53] <= 5) {
													return 0;
												}
												else {
													return 1;
												}
											}
											else {
												return 1;
											}
										}
										else {
											return 0;
										}
									}
									else {
										if (ptr[27] <= 0) {
											if (ptr[47] <= 0) {
												if (ptr[75] <= 0) {
													return 1;
												}
												else {
													return 0;
												}
											}
											else {
												return 0;
											}
										}
										else {
											return 0;
										}
									}
								}
								else {
									if (ptr[34] <= 5) {
										if (ptr[11] <= 0) {
											if (ptr[14] <= 0) {
												if (ptr[36] <= 10) {
													return 1;
												}
												else {
													return 0;
												}
											}
											else {
												return 0;
											}
										}
										else {
											return 0;
										}
									}
									else {
										if (ptr[62] <= 0) {
											if (ptr[74] <= 0) {
												if (ptr[25] <= 2) {
													return 1;
												}
												else {
													return 0;
												}
											}
											else {
												return 0;
											}
										}
										else {
											return 0;
										}
									}
								}
							}
							else {
								if (ptr[68] <= 0) {
									if (ptr[54] <= 0) {
										if (ptr[24] <= 2) {
											if (ptr[20] <= 0) {
												if (ptr[48] <= 25) {
													return 0;
												}
												else {
													return 1;
												}
											}
											else {
												if (ptr[69] <= 2) {
													return 0;
												}
												else {
													return 1;
												}
											}
										}
										else {
											return 0;
										}
									}
									else {
										return 1;
									}
								}
								else {
									return 1;
								}
							}
						}
						else {
							if (ptr[12] <= 0) {
								if (ptr[34] <= 5) {
									if (ptr[26] <= 0) {
										if (ptr[33] <= 7) {
											if (ptr[35] <= 10) {
												return 1;//short version
											}
											else {
												if (ptr[10] <= 2) {
													return 1;
												}
												else {
													return 0;
												}
											}
										}
										else {
											if (ptr[60] <= 1) {
												if (ptr[11] <= 22) {
													return 1;
												}
												else {
													return 0;
												}
											}
											else {
												return 0;
											}
										}
									}
									else {
										if (ptr[37] <= 17) {
											if (ptr[43] <= 2) {
												if (ptr[27] <= 5) {
													return 1;
												}
												else {
													return 0;
												}
											}
											else {
												return 0;
											}
										}
										else {
											return 1;
										}
									}
								}
								else {
									if (ptr[25] <= 2) {
										if (ptr[64] <= 5) {
											if (ptr[75] <= 2) {
												return 1;//short version
											}
											else {
												return 0;
											}
										}
										else {
											return 0;
										}
									}
									else {
										if (ptr[14] <= 2) {
											if (ptr[76] <= 0) {
												if (ptr[11] <= 7) {
													return 1;
												}
												else {
													return 0;
												}
											}
											else {
												return 0;
											}
										}
										else {
											return 0;
										}
									}
								}
							}
							else {
								if (ptr[38] <= 22) {
									if (ptr[19] <= 10) {
										if (ptr[34] <= 7) {
											if (ptr[20] <= 17) {
												return 0;//short version
											}
											else {
												return 1;
											}
										}
										else {
											return 0;
										}
									}
									else {
										return 1;
									}
								}
								else {
									return 1;
								}
							}
						}
					}
					else {
						if (ptr[14] <= 0) {
							if (ptr[37] <= 15) {
								if (ptr[32] <= 2) {
									if (ptr[20] <= 25) {
										if (ptr[17] <= 20) {
											if (ptr[18] <= 22) {
												return 0;//short version
											}
											else {
												return 1;
											}
										}
										else {
											return 1;
										}
									}
									else {
										return 1;
									}
								}
								else {
									if (ptr[34] <= 12) {
										return 0;//short version
									}
									else {
										return 1;
									}
								}
							}
							else {
								return 0;
							}
						}
						else {
							if (ptr[17] <= 20) {
								if (ptr[33] <= 12) {
									if (ptr[34] <= 7) {
										if (ptr[5] <= 17) {
											if (ptr[58] <= 17) {
												return 0;//short version
											}
											else {
												return 0;
											}
										}
										else {
											return 0;
										}
									}
									else {
										return 0;
									}
								}
								else {
									return 0;
								}
							}
							else {
								return 0;
							}
						}
					}
				}
			}
			else {
				if (ptr[6] <= 2) {
					if (ptr[20] <= 2) {
						if (ptr[18] <= 17) {
							if (ptr[36] <= 2) {
								if (ptr[7] <= 2) {
									if (ptr[8] <= 11) {
										if (ptr[31] <= 33) {
											if (ptr[30] <= 0) {
												return 1;
											}
											else {
												return 1;//short version
											}
										}
										else {
											if (ptr[1] <= 6) {
												return 1;//short version
											}
											else {
												return 0;
											}
										}
									}
									else {
										return 0;
									}
								}
								else {
									return 1;
								}
							}
							else {
								return 1;
							}
						}
						else {
							return 1;//short version
						}
					}
					else {
						if (ptr[20] <= 17) {
							if (ptr[30] <= 2) {
								return 0;
							}
							else {
								if (ptr[7] <= 2) {
									return 1;
								}
								else {
									return 0;
								}
							}
						}
						else {
							return 0;
						}
					}
				}
				else {
					if (ptr[32] <= 35) {
						if (ptr[37] <= 0) {
							if (ptr[17] <= 53) {
								if (ptr[20] <= 0) {
									if (ptr[30] <= 10) {
										if (ptr[48] <= 25) {
											if (ptr[35] <= 20) {
												if (ptr[33] <= 35) {
													return 0;
												}
												else {
													return 1;
												}
											}
											else {
												return 1;
											}
										}
										else {
											return 1;
										}
									}
									else {
										if (ptr[6] <= 12) {
											return 1;
										}
										else {
											return 0;
										}
									}
								}
								else {
									if (ptr[49] <= 17) {
										if (ptr[7] <= 0) {
											return 0;
										}
										else {
											if (ptr[8] <= 2) {
												if (ptr[15] <= 0) {
													return 0;
												}
												else {
													return 1;
												}
											}
											else {
												if (ptr[10] <= 5) {
													return 0;
												}
												else {
													return 1;
												}
											}
										}
									}
									else {
										return 1;
									}
								}
							}
							else {
								return 0;
							}
						}
						else {
							return 1;
						}
					}
					else {
						if (ptr[30] <= 5) {
							if (ptr[3] <= 1) {
								if (ptr[32] <= 48) {
									return 0;
								}
								else {
									return 1;
								}
							}
							else {
								return 0;
							}
						}
						else {
							return 1;//short version
						}
					}
				}
			}
		}
		else {
			if (ptr[34] <= 2) {
				if (ptr[31] <= 30) {
					if (ptr[8] <= 0) {
						if (ptr[14] <= 0) {
							if (ptr[16] <= 12) {
								if (ptr[32] <= 43) {
									if (ptr[7] <= 5) {
										return 1;
									}
									else {
										return 0;
									}
								}
								else {
									return 1;
								}
							}
							else {
								if (ptr[19] <= 7) {
									if (ptr[2] <= 2) {
										if (ptr[62] <= 12) {
											if (ptr[64] <= 16) {
												return 1;//short version
											}
											else {
												return 0;
											}
										}
										else {
											return 1;
										}
									}
									else {
										return 0;
									}
								}
								else {
									if (ptr[17] <= 68) {
										if (ptr[16] <= 40) {
											if (ptr[54] <= 1) {
												if (ptr[37] <= 2) {
													return 0;
												}
												else {
													return 1;
												}
											}
											else {
												return 1;
											}
										}
										else {
											return 1;
										}
									}
									else {
										return 1;
									}
								}
							}
						}
						else {
							return 0;
						}
					}
					else {
						if (ptr[37] <= 5) {
							if (ptr[5] <= 10) {
								if (ptr[23] <= 5) {
									if (ptr[16] <= 40) {
										if (ptr[56] <= 5) {
											return 0;//short version
										}
										else {
											return 1;
										}
									}
									else {
										return 1;
									}
								}
								else {
									return 1;
								}
							}
							else {
								return 0;
							}
						}
						else {
							return 1;
						}
					}
				}
				else {
					if (ptr[18] <= 28) {
						if (ptr[7] <= 15) {
							if (ptr[16] <= 22) {
								if (ptr[2] <= 2) {
									if (ptr[5] <= 30) {
										if (ptr[8] <= 36) {
											if (ptr[32] <= 10) {
												return 1;
											}
											else {
												if (ptr[20] <= 20) {
													return 1;
												}
												else {
													return 0;
												}
											}
										}
										else {
											return 0;
										}
									}
									else {
										return 0;
									}
								}
								else {
									return 0;
								}
							}
							else {
								if (ptr[2] <= 1) {
									if (ptr[6] <= 35) {
										if (ptr[31] <= 86) {
											if (ptr[5] <= 12) {
												return 1;//short version
											}
											else {
												return 1;
											}
										}
										else {
											return 1;
										}
									}
									else {
										return 1;
									}
								}
								else {
									return 0;
								}
							}
						}
						else {
							return 0;
						}
					}
					else {
						if (ptr[6] <= 2) {
							return 1;
						}
						else {
							return 0;
						}
					}
				}
			}
			else {
				if (ptr[7] <= 0) {
					if (ptr[19] <= 5) {
						if (ptr[36] <= 2) {
							if (ptr[1] <= 2) {
								if (ptr[30] <= 5) {
									if (ptr[32] <= 22) {
										return 1;
									}
									else {
										return 1;//short version
									}
								}
								else {
									if (ptr[49] <= 51) {
										if (ptr[17] <= 68) {
											if (ptr[35] <= 10) {
												return 1;//short version
											}
											else {
												return 1;
											}
										}
										else {
											return 1;
										}
									}
									else {
										return 0;
									}
								}
							}
							else {
								return 0;
							}
						}
						else {
							if (ptr[64] <= 0) {
								return 1;
							}
							else {
								return 0;
							}
						}
					}
					else {
						if (ptr[64] <= 0) {
							if (ptr[48] <= 0) {
								if (ptr[39] <= 0) {
									if (ptr[12] <= 1) {
										if (ptr[19] <= 48) {
											if (ptr[16] <= 15) {
												return 1;
											}
											else {
												if (ptr[65] <= 5) {
													return 1;
												}
												else {
													return 0;
												}
											}
										}
										else {
											return 0;
										}
									}
									else {
										return 0;
									}
								}
								else {
									return 1;
								}
							}
							else {
								if (ptr[20] <= 7) {
									return 1;
								}
								else {
									return 0;
								}
							}
						}
						else {
							return 0;
						}
					}
				}
				else {
					if (ptr[37] <= 0) {
						if (ptr[38] <= 1) {
							if (ptr[49] <= 0) {
								if (ptr[3] <= 0) {
									if (ptr[47] <= 2) {
										if (ptr[16] <= 15) {
											return 0;//short version
										}
										else {
											return 0;
										}
									}
									else {
										return 0;
									}
								}
								else {
									return 0;
								}
							}
							else {
								if (ptr[17] <= 17) {
									if (ptr[23] <= 7) {
										if (ptr[15] <= 1) {
											if (ptr[52] <= 2) {
												if (ptr[48] <= 39) {
													return 0;
												}
												else {
													return 1;
												}
											}
											else {
												return 1;
											}
										}
										else {
											return 1;
										}
									}
									else {
										return 1;
									}
								}
								else {
									return 0;
								}
							}
						}
						else {
							return 1;
						}
					}
					else {
						if (ptr[47] <= 2) {
							if (ptr[38] <= 0) {
								return 1;
							}
							else {
								if (ptr[36] <= 44) {
									if (ptr[78] <= 2) {
										if (ptr[44] <= 5) {
											if (ptr[8] <= 21) {
												return 1;//short version
											}
											else {
												return 1;
											}
										}
										else {
											return 0;
										}
									}
									else {
										return 1;
									}
								}
								else {
									return 0;
								}
							}
						}
						else {
							return 0;
						}
					}
				}
			}
		}
	}
	unsigned char predict_9(unsigned char ptr[]) {
		if (ptr[30] <= 5) {
			if (ptr[43] <= 0) {
				if (ptr[36] <= 7) {
					if (ptr[17] <= 28) {
						if (ptr[20] <= 0) {
							if (ptr[2] <= 0) {
								if (ptr[19] <= 0) {
									if (ptr[7] <= 0) {
										if (ptr[26] <= 0) {
											if (ptr[6] <= 2) {
												if (ptr[13] <= 2) {
													return 1;
												}
												else {
													return 0;
												}
											}
											else {
												if (ptr[5] <= 10) {
													return 1;
												}
												else {
													return 0;
												}
											}
										}
										else {
											return 0;
										}
									}
									else {
										if (ptr[13] <= 0) {
											if (ptr[53] <= 2) {
												if (ptr[33] <= 40) {
													return 0;
												}
												else {
													return 1;
												}
											}
											else {
												return 1;
											}
										}
										else {
											return 0;
										}
									}
								}
								else {
									if (ptr[6] <= 2) {
										if (ptr[14] <= 0) {
											if (ptr[8] <= 0) {
												if (ptr[32] <= 28) {
													return 0;
												}
												else {
													return 1;
												}
											}
											else {
												return 0;//short version
											}
										}
										else {
											return 0;
										}
									}
									else {
										if (ptr[62] <= 0) {
											if (ptr[35] <= 5) {
												return 0;//short version
											}
											else {
												if (ptr[54] <= 12) {
													return 0;
												}
												else {
													return 1;
												}
											}
										}
										else {
											if (ptr[52] <= 2) {
												return 0;//short version
											}
											else {
												return 1;
											}
										}
									}
								}
							}
							else {
								if (ptr[13] <= 0) {
									if (ptr[39] <= 12) {
										if (ptr[35] <= 5) {
											if (ptr[53] <= 2) {
												if (ptr[21] <= 21) {
													return 0;
												}
												else {
													return 1;
												}
											}
											else {
												return 0;
											}
										}
										else {
											if (ptr[55] <= 7) {
												if (ptr[1] <= 10) {
													return 0;
												}
												else {
													return 1;
												}
											}
											else {
												return 1;
											}
										}
									}
									else {
										return 0;
									}
								}
								else {
									if (ptr[6] <= 39) {
										if (ptr[9] <= 43) {
											if (ptr[4] <= 0) {
												return 0;//short version
											}
											else {
												return 1;
											}
										}
										else {
											return 1;
										}
									}
									else {
										return 1;
									}
								}
							}
						}
						else {
							if (ptr[37] <= 2) {
								if (ptr[38] <= 2) {
									if (ptr[23] <= 2) {
										if (ptr[67] <= 2) {
											if (ptr[63] <= 0) {
												return 0;//short version
											}
											else {
												return 0;//short version
											}
										}
										else {
											return 0;
										}
									}
									else {
										if (ptr[20] <= 10) {
											if (ptr[32] <= 7) {
												return 0;//short version
											}
											else {
												return 1;
											}
										}
										else {
											if (ptr[6] <= 7) {
												return 0;
											}
											else {
												return 1;
											}
										}
									}
								}
								else {
									if (ptr[25] <= 0) {
										if (ptr[11] <= 0) {
											if (ptr[28] <= 0) {
												return 1;
											}
											else {
												return 0;
											}
										}
										else {
											return 0;
										}
									}
									else {
										if (ptr[22] <= 12) {
											if (ptr[33] <= 7) {
												if (ptr[8] <= 20) {
													return 0;
												}
												else {
													return 1;
												}
											}
											else {
												return 0;
											}
										}
										else {
											return 0;
										}
									}
								}
							}
							else {
								if (ptr[25] <= 0) {
									if (ptr[11] <= 0) {
										if (ptr[62] <= 0) {
											if (ptr[14] <= 0) {
												if (ptr[3] <= 0) {
													return 1;
												}
												else {
													return 0;
												}
											}
											else {
												return 0;
											}
										}
										else {
											return 0;
										}
									}
									else {
										if (ptr[19] <= 12) {
											if (ptr[21] <= 17) {
												return 0;//short version
											}
											else {
												return 1;
											}
										}
										else {
											return 1;
										}
									}
								}
								else {
									if (ptr[18] <= 12) {
										if (ptr[13] <= 0) {
											if (ptr[14] <= 0) {
												return 0;//short version
											}
											else {
												return 0;//short version
											}
										}
										else {
											if (ptr[19] <= 20) {
												return 0;//short version
											}
											else {
												return 1;
											}
										}
									}
									else {
										return 1;
									}
								}
							}
						}
					}
					else {
						if (ptr[6] <= 7) {
							if (ptr[7] <= 0) {
								if (ptr[19] <= 7) {
									if (ptr[62] <= 5) {
										if (ptr[60] <= 19) {
											if (ptr[47] <= 2) {
												if (ptr[52] <= 20) {
													return 1;
												}
												else {
													return 0;
												}
											}
											else {
												return 1;//short version
											}
										}
										else {
											return 0;
										}
									}
									else {
										return 1;
									}
								}
								else {
									if (ptr[62] <= 0) {
										if (ptr[8] <= 7) {
											if (ptr[51] <= 28) {
												if (ptr[74] <= 1) {
													return 1;
												}
												else {
													return 0;
												}
											}
											else {
												return 0;
											}
										}
										else {
											return 0;
										}
									}
									else {
										return 0;
									}
								}
							}
							else {
								if (ptr[39] <= 0) {
									if (ptr[69] <= 1) {
										if (ptr[63] <= 0) {
											if (ptr[8] <= 2) {
												return 1;
											}
											else {
												return 0;
											}
										}
										else {
											return 0;
										}
									}
									else {
										return 1;
									}
								}
								else {
									return 1;
								}
							}
						}
						else {
							if (ptr[16] <= 12) {
								if (ptr[37] <= 0) {
									if (ptr[17] <= 53) {
										if (ptr[7] <= 7) {
											if (ptr[61] <= 2) {
												if (ptr[31] <= 1) {
													return 1;
												}
												else {
													return 0;
												}
											}
											else {
												return 0;
											}
										}
										else {
											if (ptr[22] <= 1) {
												return 0;//short version
											}
											else {
												return 1;
											}
										}
									}
									else {
										if (ptr[18] <= 43) {
											return 0;
										}
										else {
											return 1;
										}
									}
								}
								else {
									return 1;
								}
							}
							else {
								if (ptr[32] <= 12) {
									if (ptr[22] <= 1) {
										if (ptr[46] <= 2) {
											if (ptr[8] <= 1) {
												return 1;
											}
											else {
												return 0;
											}
										}
										else {
											return 0;
										}
									}
									else {
										return 1;
									}
								}
								else {
									if (ptr[3] <= 0) {
										if (ptr[5] <= 0) {
											return 1;
										}
										else {
											if (ptr[75] <= 5) {
												if (ptr[63] <= 2) {
													return 1;
												}
												else {
													return 0;
												}
											}
											else {
												return 0;
											}
										}
									}
									else {
										return 0;
									}
								}
							}
						}
					}
				}
				else {
					if (ptr[37] <= 2) {
						if (ptr[38] <= 0) {
							if (ptr[63] <= 0) {
								if (ptr[53] <= 0) {
									if (ptr[62] <= 0) {
										if (ptr[68] <= 5) {
											if (ptr[46] <= 0) {
												if (ptr[18] <= 17) {
													return 0;
												}
												else {
													return 1;
												}
											}
											else {
												return 0;//short version
											}
										}
										else {
											return 1;
										}
									}
									else {
										if (ptr[19] <= 0) {
											return 0;
										}
										else {
											if (ptr[31] <= 12) {
												if (ptr[49] <= 17) {
													return 0;
												}
												else {
													return 1;
												}
											}
											else {
												return 0;
											}
										}
									}
								}
								else {
									if (ptr[22] <= 0) {
										return 1;
									}
									else {
										return 0;
									}
								}
							}
							else {
								if (ptr[68] <= 0) {
									if (ptr[20] <= 0) {
										return 0;
									}
									else {
										if (ptr[40] <= 5) {
											if (ptr[24] <= 15) {
												if (ptr[5] <= 35) {
													return 0;
												}
												else {
													return 1;
												}
											}
											else {
												return 1;
											}
										}
										else {
											return 1;
										}
									}
								}
								else {
									return 1;
								}
							}
						}
						else {
							if (ptr[27] <= 0) {
								if (ptr[12] <= 0) {
									if (ptr[18] <= 7) {
										if (ptr[11] <= 0) {
											if (ptr[8] <= 10) {
												return 1;//short version
											}
											else {
												return 0;
											}
										}
										else {
											return 0;
										}
									}
									else {
										return 1;
									}
								}
								else {
									return 0;
								}
							}
							else {
								return 0;
							}
						}
					}
					else {
						if (ptr[64] <= 5) {
							if (ptr[23] <= 5) {
								if (ptr[14] <= 0) {
									if (ptr[75] <= 0) {
										if (ptr[11] <= 2) {
											if (ptr[62] <= 0) {
												if (ptr[10] <= 7) {
													return 1;
												}
												else {
													return 0;
												}
											}
											else {
												return 0;
											}
										}
										else {
											if (ptr[12] <= 5) {
												if (ptr[71] <= 2) {
													return 1;
												}
												else {
													return 0;
												}
											}
											else {
												return 0;
											}
										}
									}
									else {
										return 0;//short version
									}
								}
								else {
									if (ptr[32] <= 5) {
										if (ptr[33] <= 16) {
											if (ptr[3] <= 15) {
												if (ptr[11] <= 33) {
													return 0;
												}
												else {
													return 1;
												}
											}
											else {
												return 1;
											}
										}
										else {
											return 1;
										}
									}
									else {
										return 0;
									}
								}
							}
							else {
								if (ptr[14] <= 0) {
									if (ptr[34] <= 5) {
										if (ptr[33] <= 7) {
											if (ptr[35] <= 7) {
												return 0;//short version
											}
											else {
												if (ptr[11] <= 2) {
													return 1;
												}
												else {
													return 0;
												}
											}
										}
										else {
											return 1;
										}
									}
									else {
										if (ptr[34] <= 10) {
											if (ptr[11] <= 2) {
												if (ptr[24] <= 12) {
													return 1;
												}
												else {
													return 0;
												}
											}
											else {
												return 0;
											}
										}
										else {
											if (ptr[19] <= 7) {
												if (ptr[11] <= 10) {
													return 1;
												}
												else {
													return 0;
												}
											}
											else {
												if (ptr[11] <= 17) {
													return 1;
												}
												else {
													return 0;
												}
											}
										}
									}
								}
								else {
									if (ptr[14] <= 5) {
										return 0;//short version
									}
									else {
										if (ptr[36] <= 42) {
											if (ptr[22] <= 30) {
												if (ptr[37] <= 39) {
													return 0;
												}
												else {
													return 1;
												}
											}
											else {
												return 1;
											}
										}
										else {
											return 1;
										}
									}
								}
							}
						}
						else {
							if (ptr[68] <= 0) {
								if (ptr[54] <= 0) {
									if (ptr[55] <= 3) {
										if (ptr[39] <= 2) {
											if (ptr[32] <= 31) {
												if (ptr[17] <= 30) {
													return 0;
												}
												else {
													return 1;
												}
											}
											else {
												return 1;
											}
										}
										else {
											return 0;
										}
									}
									else {
										return 1;
									}
								}
								else {
									return 1;
								}
							}
							else {
								return 1;
							}
						}
					}
				}
			}
			else {
				if (ptr[35] <= 7) {
					if (ptr[20] <= 7) {
						if (ptr[25] <= 0) {
							if (ptr[52] <= 2) {
								if (ptr[27] <= 0) {
									if (ptr[55] <= 2) {
										if (ptr[33] <= 5) {
											if (ptr[36] <= 5) {
												return 0;//short version
											}
											else {
												return 0;
											}
										}
										else {
											return 0;
										}
									}
									else {
										if (ptr[37] <= 5) {
											return 0;
										}
										else {
											return 1;
										}
									}
								}
								else {
									if (ptr[38] <= 12) {
										if (ptr[37] <= 15) {
											if (ptr[37] <= 10) {
												if (ptr[58] <= 28) {
													return 0;
												}
												else {
													return 1;
												}
											}
											else {
												return 0;
											}
										}
										else {
											return 0;
										}
									}
									else {
										return 0;
									}
								}
							}
							else {
								if (ptr[11] <= 0) {
									if (ptr[27] <= 2) {
										return 1;
									}
									else {
										return 0;
									}
								}
								else {
									return 0;
								}
							}
						}
						else {
							if (ptr[39] <= 17) {
								if (ptr[34] <= 7) {
									if (ptr[34] <= 2) {
										if (ptr[68] <= 20) {
											if (ptr[29] <= 0) {
												return 0;//short version
											}
											else {
												return 1;
											}
										}
										else {
											return 1;
										}
									}
									else {
										if (ptr[40] <= 20) {
											if (ptr[37] <= 20) {
												if (ptr[31] <= 20) {
													return 0;
												}
												else {
													return 1;
												}
											}
											else {
												return 1;
											}
										}
										else {
											return 1;
										}
									}
								}
								else {
									if (ptr[18] <= 15) {
										if (ptr[16] <= 0) {
											if (ptr[74] <= 0) {
												return 0;//short version
											}
											else {
												return 1;
											}
										}
										else {
											return 0;
										}
									}
									else {
										return 1;
									}
								}
							}
							else {
								return 0;//short version
							}
						}
					}
					else {
						if (ptr[33] <= 2) {
							if (ptr[39] <= 20) {
								if (ptr[34] <= 10) {
									if (ptr[21] <= 15) {
										if (ptr[37] <= 12) {
											if (ptr[19] <= 17) {
												if (ptr[9] <= 25) {
													return 0;
												}
												else {
													return 1;
												}
											}
											else {
												return 0;
											}
										}
										else {
											return 0;
										}
									}
									else {
										return 0;
									}
								}
								else {
									return 1;
								}
							}
							else {
								return 1;
							}
						}
						else {
							if (ptr[11] <= 2) {
								if (ptr[77] <= 0) {
									if (ptr[12] <= 0) {
										return 1;
									}
									else {
										return 0;
									}
								}
								else {
									return 0;
								}
							}
							else {
								return 0;
							}
						}
					}
				}
				else {
					if (ptr[12] <= 0) {
						if (ptr[28] <= 0) {
							if (ptr[27] <= 2) {
								if (ptr[37] <= 7) {
									return 1;//short version
								}
								else {
									if (ptr[11] <= 7) {
										if (ptr[76] <= 10) {
											if (ptr[26] <= 0) {
												if (ptr[78] <= 7) {
													return 1;
												}
												else {
													return 0;
												}
											}
											else {
												return 1;
											}
										}
										else {
											return 0;
										}
									}
									else {
										return 0;
									}
								}
							}
							else {
								return 0;
							}
						}
						else {
							if (ptr[34] <= 15) {
								if (ptr[33] <= 5) {
									return 0;//short version
								}
								else {
									return 0;
								}
							}
							else {
								return 1;
							}
						}
					}
					else {
						if (ptr[18] <= 10) {
							if (ptr[37] <= 15) {
								if (ptr[34] <= 17) {
									if (ptr[37] <= 7) {
										if (ptr[32] <= 2) {
											if (ptr[22] <= 33) {
												return 0;//short version
											}
											else {
												return 1;
											}
										}
										else {
											return 0;
										}
									}
									else {
										return 0;
									}
								}
								else {
									return 0;
								}
							}
							else {
								return 0;
							}
						}
						else {
							return 0;
						}
					}
				}
			}
		}
		else {
			if (ptr[19] <= 0) {
				if (ptr[11] <= 0) {
					if (ptr[3] <= 0) {
						if (ptr[1] <= 0) {
							if (ptr[6] <= 22) {
								if (ptr[8] <= 0) {
									if (ptr[6] <= 2) {
										if (ptr[31] <= 10) {
											if (ptr[47] <= 20) {
												return 1;//short version
											}
											else {
												return 1;
											}
										}
										else {
											if (ptr[74] <= 7) {
												return 1;//short version
											}
											else {
												return 1;//short version
											}
										}
									}
									else {
										if (ptr[27] <= 0) {
											if (ptr[62] <= 5) {
												return 1;//short version
											}
											else {
												if (ptr[2] <= 2) {
													return 1;
												}
												else {
													return 0;
												}
											}
										}
										else {
											return 0;
										}
									}
								}
								else {
									return 0;
								}
							}
							else {
								if (ptr[47] <= 2) {
									return 1;
								}
								else {
									return 0;
								}
							}
						}
						else {
							if (ptr[62] <= 5) {
								if (ptr[36] <= 7) {
									return 0;
								}
								else {
									return 1;
								}
							}
							else {
								return 0;
							}
						}
					}
					else {
						return 0;
					}
				}
				else {
					if (ptr[35] <= 7) {
						return 0;
					}
					else {
						return 1;
					}
				}
			}
			else {
				if (ptr[31] <= 28) {
					if (ptr[38] <= 2) {
						if (ptr[7] <= 0) {
							if (ptr[32] <= 22) {
								if (ptr[54] <= 5) {
									if (ptr[17] <= 17) {
										if (ptr[48] <= 17) {
											if (ptr[37] <= 5) {
												return 0;//short version
											}
											else {
												return 0;
											}
										}
										else {
											return 1;
										}
									}
									else {
										if (ptr[18] <= 28) {
											if (ptr[37] <= 1) {
												return 0;
											}
											else {
												return 1;
											}
										}
										else {
											return 1;
										}
									}
								}
								else {
									return 1;
								}
							}
							else {
								if (ptr[48] <= 15) {
									if (ptr[33] <= 12) {
										return 0;
									}
									else {
										return 1;
									}
								}
								else {
									return 1;
								}
							}
						}
						else {
							if (ptr[37] <= 2) {
								if (ptr[5] <= 12) {
									if (ptr[55] <= 0) {
										if (ptr[30] <= 12) {
											if (ptr[22] <= 5) {
												if (ptr[51] <= 25) {
													return 0;
												}
												else {
													return 1;
												}
											}
											else {
												return 0;
											}
										}
										else {
											if (ptr[67] <= 1) {
												if (ptr[32] <= 51) {
													return 0;
												}
												else {
													return 1;
												}
											}
											else {
												return 1;
											}
										}
									}
									else {
										return 1;
									}
								}
								else {
									return 0;
								}
							}
							else {
								if (ptr[28] <= 2) {
									return 1;
								}
								else {
									return 0;
								}
							}
						}
					}
					else {
						if (ptr[13] <= 0) {
							if (ptr[28] <= 0) {
								if (ptr[11] <= 5) {
									if (ptr[27] <= 5) {
										if (ptr[44] <= 2) {
											if (ptr[67] <= 2) {
												return 1;//short version
											}
											else {
												return 1;
											}
										}
										else {
											return 0;
										}
									}
									else {
										return 0;
									}
								}
								else {
									return 0;
								}
							}
							else {
								return 0;
							}
						}
						else {
							return 0;
						}
					}
				}
				else {
					if (ptr[16] <= 5) {
						if (ptr[7] <= 2) {
							if (ptr[51] <= 2) {
								if (ptr[6] <= 10) {
									if (ptr[65] <= 5) {
										if (ptr[33] <= 63) {
											return 1;//short version
										}
										else {
											return 0;
										}
									}
									else {
										return 0;
									}
								}
								else {
									return 1;
								}
							}
							else {
								return 0;
							}
						}
						else {
							return 0;//short version
						}
					}
					else {
						if (ptr[7] <= 7) {
							if (ptr[3] <= 5) {
								if (ptr[8] <= 12) {
									if (ptr[36] <= 10) {
										if (ptr[34] <= 5) {
											if (ptr[20] <= 21) {
												if (ptr[5] <= 43) {
													return 1;
												}
												else {
													return 0;
												}
											}
											else {
												return 0;
											}
										}
										else {
											return 1;//short version
										}
									}
									else {
										return 0;
									}
								}
								else {
									return 0;
								}
							}
							else {
								return 0;
							}
						}
						else {
							return 0;//short version
						}
					}
				}
			}
		}
	}
	unsigned char predict_10(unsigned char ptr[]) {
		if (ptr[27] <= 0) {
			if (ptr[64] <= 0) {
				if (ptr[16] <= 10) {
					if (ptr[36] <= 7) {
						if (ptr[31] <= 33) {
							if (ptr[52] <= 2) {
								if (ptr[30] <= 12) {
									if (ptr[38] <= 2) {
										if (ptr[19] <= 0) {
											if (ptr[23] <= 0) {
												if (ptr[7] <= 0) {
													return 1;
												}
												else {
													return 0;
												}
											}
											else {
												if (ptr[8] <= 12) {
													return 0;
												}
												else {
													return 1;
												}
											}
										}
										else {
											if (ptr[3] <= 0) {
												return 0;//short version
											}
											else {
												return 0;//short version
											}
										}
									}
									else {
										if (ptr[35] <= 5) {
											if (ptr[12] <= 0) {
												if (ptr[20] <= 7) {
													return 0;
												}
												else {
													return 1;
												}
											}
											else {
												return 0;//short version
											}
										}
										else {
											if (ptr[12] <= 0) {
												return 1;//short version
											}
											else {
												return 0;//short version
											}
										}
									}
								}
								else {
									if (ptr[3] <= 0) {
										if (ptr[19] <= 2) {
											if (ptr[65] <= 12) {
												return 1;//short version
											}
											else {
												return 0;
											}
										}
										else {
											if (ptr[7] <= 2) {
												return 1;
											}
											else {
												return 0;
											}
										}
									}
									else {
										return 0;
									}
								}
							}
							else {
								if (ptr[14] <= 0) {
									if (ptr[51] <= 5) {
										if (ptr[12] <= 0) {
											if (ptr[34] <= 7) {
												if (ptr[10] <= 7) {
													return 1;
												}
												else {
													return 0;
												}
											}
											else {
												if (ptr[63] <= 5) {
													return 1;
												}
												else {
													return 0;
												}
											}
										}
										else {
											if (ptr[50] <= 0) {
												if (ptr[21] <= 20) {
													return 0;
												}
												else {
													return 1;
												}
											}
											else {
												return 0;
											}
										}
									}
									else {
										if (ptr[13] <= 2) {
											if (ptr[75] <= 0) {
												if (ptr[12] <= 2) {
													return 1;
												}
												else {
													return 0;
												}
											}
											else {
												return 0;
											}
										}
										else {
											return 0;
										}
									}
								}
								else {
									if (ptr[9] <= 12) {
										if (ptr[14] <= 36) {
											if (ptr[13] <= 0) {
												return 0;
											}
											else {
												return 0;//short version
											}
										}
										else {
											return 1;
										}
									}
									else {
										return 0;
									}
								}
							}
						}
						else {
							if (ptr[8] <= 2) {
								if (ptr[5] <= 2) {
									if (ptr[32] <= 30) {
										if (ptr[7] <= 2) {
											if (ptr[20] <= 2) {
												return 1;//short version
											}
											else {
												return 0;
											}
										}
										else {
											return 0;
										}
									}
									else {
										if (ptr[7] <= 2) {
											if (ptr[35] <= 15) {
												return 1;//short version
											}
											else {
												return 0;
											}
										}
										else {
											return 0;
										}
									}
								}
								else {
									if (ptr[7] <= 0) {
										if (ptr[3] <= 1) {
											if (ptr[6] <= 17) {
												return 1;//short version
											}
											else {
												return 0;
											}
										}
										else {
											return 0;
										}
									}
									else {
										if (ptr[32] <= 38) {
											if (ptr[3] <= 7) {
												return 0;//short version
											}
											else {
												return 0;
											}
										}
										else {
											return 0;
										}
									}
								}
							}
							else {
								if (ptr[33] <= 15) {
									if (ptr[34] <= 22) {
										return 0;//short version
									}
									else {
										return 1;
									}
								}
								else {
									return 0;
								}
							}
						}
					}
					else {
						if (ptr[39] <= 0) {
							if (ptr[53] <= 0) {
								if (ptr[18] <= 15) {
									if (ptr[48] <= 0) {
										if (ptr[37] <= 2) {
											if (ptr[67] <= 0) {
												return 0;//short version
											}
											else {
												return 1;
											}
										}
										else {
											if (ptr[11] <= 2) {
												if (ptr[62] <= 0) {
													return 1;
												}
												else {
													return 0;
												}
											}
											else {
												return 0;//short version
											}
										}
									}
									else {
										if (ptr[54] <= 0) {
											if (ptr[20] <= 0) {
												return 0;
											}
											else {
												if (ptr[30] <= 10) {
													return 0;
												}
												else {
													return 1;
												}
											}
										}
										else {
											return 1;
										}
									}
								}
								else {
									if (ptr[38] <= 0) {
										if (ptr[46] <= 0) {
											if (ptr[47] <= 0) {
												if (ptr[48] <= 7) {
													return 1;
												}
												else {
													return 0;
												}
											}
											else {
												return 0;
											}
										}
										else {
											return 0;
										}
									}
									else {
										return 1;
									}
								}
							}
							else {
								if (ptr[12] <= 0) {
									if (ptr[11] <= 0) {
										if (ptr[74] <= 0) {
											if (ptr[75] <= 0) {
												return 1;//short version
											}
											else {
												return 0;
											}
										}
										else {
											return 0;
										}
									}
									else {
										return 0;
									}
								}
								else {
									return 0;
								}
							}
						}
						else {
							if (ptr[14] <= 0) {
								if (ptr[36] <= 15) {
									if (ptr[35] <= 5) {
										if (ptr[24] <= 5) {
											if (ptr[11] <= 0) {
												if (ptr[78] <= 0) {
													return 1;
												}
												else {
													return 0;
												}
											}
											else {
												return 0;
											}
										}
										else {
											if (ptr[20] <= 12) {
												return 0;
											}
											else {
												return 1;
											}
										}
									}
									else {
										if (ptr[11] <= 5) {
											if (ptr[33] <= 5) {
												return 1;//short version
											}
											else {
												if (ptr[1] <= 19) {
													return 1;
												}
												else {
													return 0;
												}
											}
										}
										else {
											return 0;
										}
									}
								}
								else {
									if (ptr[35] <= 7) {
										if (ptr[33] <= 5) {
											if (ptr[10] <= 2) {
												if (ptr[11] <= 0) {
													return 1;
												}
												else {
													return 0;
												}
											}
											else {
												return 0;
											}
										}
										else {
											if (ptr[12] <= 10) {
												return 1;//short version
											}
											else {
												return 0;
											}
										}
									}
									else {
										if (ptr[11] <= 5) {
											if (ptr[25] <= 12) {
												if (ptr[10] <= 10) {
													return 1;
												}
												else {
													return 0;
												}
											}
											else {
												return 0;
											}
										}
										else {
											return 0;
										}
									}
								}
							}
							else {
								if (ptr[34] <= 12) {
									if (ptr[37] <= 28) {
										if (ptr[20] <= 10) {
											if (ptr[51] <= 15) {
												return 0;//short version
											}
											else {
												return 1;
											}
										}
										else {
											return 0;
										}
									}
									else {
										return 1;
									}
								}
								else {
									return 1;
								}
							}
						}
					}
				}
				else {
					if (ptr[2] <= 2) {
						if (ptr[7] <= 2) {
							if (ptr[20] <= 0) {
								if (ptr[63] <= 2) {
									if (ptr[6] <= 15) {
										if (ptr[25] <= 7) {
											if (ptr[60] <= 17) {
												return 1;//short version
											}
											else {
												return 1;
											}
										}
										else {
											return 0;
										}
									}
									else {
										if (ptr[62] <= 17) {
											if (ptr[6] <= 99) {
												return 1;//short version
											}
											else {
												return 0;
											}
										}
										else {
											return 0;
										}
									}
								}
								else {
									if (ptr[18] <= 15) {
										if (ptr[31] <= 12) {
											return 1;
										}
										else {
											if (ptr[5] <= 25) {
												if (ptr[31] <= 130) {
													return 1;
												}
												else {
													return 0;
												}
											}
											else {
												return 0;
											}
										}
									}
									else {
										return 1;
									}
								}
							}
							else {
								if (ptr[36] <= 0) {
									if (ptr[62] <= 0) {
										if (ptr[31] <= 35) {
											if (ptr[16] <= 35) {
												if (ptr[19] <= 22) {
													return 1;
												}
												else {
													return 0;
												}
											}
											else {
												return 1;
											}
										}
										else {
											return 1;
										}
									}
									else {
										return 0;
									}
								}
								else {
									if (ptr[75] <= 0) {
										if (ptr[63] <= 2) {
											if (ptr[12] <= 15) {
												if (ptr[61] <= 0) {
													return 1;
												}
												else {
													return 0;
												}
											}
											else {
												return 0;
											}
										}
										else {
											return 0;
										}
									}
									else {
										return 0;
									}
								}
							}
						}
						else {
							if (ptr[8] <= 5) {
								if (ptr[38] <= 0) {
									if (ptr[19] <= 2) {
										if (ptr[49] <= 7) {
											return 1;//short version
										}
										else {
											return 0;
										}
									}
									else {
										if (ptr[63] <= 7) {
											if (ptr[37] <= 5) {
												if (ptr[31] <= 28) {
													return 0;
												}
												else {
													return 1;
												}
											}
											else {
												return 1;
											}
										}
										else {
											return 0;
										}
									}
								}
								else {
									return 1;
								}
							}
							else {
								if (ptr[39] <= 1) {
									if (ptr[33] <= 17) {
										if (ptr[22] <= 1) {
											if (ptr[9] <= 35) {
												return 0;//short version
											}
											else {
												return 1;
											}
										}
										else {
											return 1;
										}
									}
									else {
										return 0;
									}
								}
								else {
									return 1;
								}
							}
						}
					}
					else {
						if (ptr[22] <= 2) {
							if (ptr[8] <= 7) {
								if (ptr[38] <= 2) {
									if (ptr[7] <= 15) {
										if (ptr[37] <= 1) {
											if (ptr[62] <= 7) {
												return 0;//short version
											}
											else {
												return 0;
											}
										}
										else {
											return 1;
										}
									}
									else {
										return 0;
									}
								}
								else {
									return 1;
								}
							}
							else {
								return 0;
							}
						}
						else {
							return 1;
						}
					}
				}
			}
			else {
				if (ptr[6] <= 0) {
					if (ptr[20] <= 0) {
						if (ptr[19] <= 0) {
							if (ptr[39] <= 0) {
								if (ptr[31] <= 10) {
									if (ptr[30] <= 2) {
										if (ptr[62] <= 7) {
											return 0;
										}
										else {
											return 1;
										}
									}
									else {
										return 1;
									}
								}
								else {
									if (ptr[37] <= 0) {
										if (ptr[7] <= 5) {
											if (ptr[30] <= 0) {
												return 1;//short version
											}
											else {
												return 1;//short version
											}
										}
										else {
											return 0;
										}
									}
									else {
										return 0;
									}
								}
							}
							else {
								return 0;
							}
						}
						else {
							if (ptr[31] <= 17) {
								if (ptr[75] <= 0) {
									if (ptr[48] <= 33) {
										if (ptr[37] <= 5) {
											if (ptr[12] <= 0) {
												return 0;//short version
											}
											else {
												return 0;
											}
										}
										else {
											return 1;
										}
									}
									else {
										return 1;
									}
								}
								else {
									if (ptr[62] <= 31) {
										if (ptr[45] <= 15) {
											if (ptr[74] <= 12) {
												return 0;//short version
											}
											else {
												return 1;
											}
										}
										else {
											return 1;
										}
									}
									else {
										return 1;
									}
								}
							}
							else {
								if (ptr[8] <= 10) {
									if (ptr[47] <= 33) {
										return 1;
									}
									else {
										return 0;
									}
								}
								else {
									return 0;
								}
							}
						}
					}
					else {
						if (ptr[54] <= 0) {
							if (ptr[19] <= 0) {
								return 0;
							}
							else {
								if (ptr[39] <= 2) {
									if (ptr[32] <= 38) {
										if (ptr[38] <= 2) {
											if (ptr[77] <= 10) {
												return 0;//short version
											}
											else {
												return 1;
											}
										}
										else {
											return 0;
										}
									}
									else {
										return 1;
									}
								}
								else {
									return 1;
								}
							}
						}
						else {
							if (ptr[11] <= 0) {
								return 1;
							}
							else {
								return 0;
							}
						}
					}
				}
				else {
					if (ptr[68] <= 0) {
						if (ptr[53] <= 2) {
							if (ptr[20] <= 0) {
								if (ptr[31] <= 17) {
									if (ptr[18] <= 0) {
										return 0;
									}
									else {
										if (ptr[31] <= 7) {
											if (ptr[7] <= 2) {
												if (ptr[37] <= 21) {
													return 0;
												}
												else {
													return 1;
												}
											}
											else {
												return 0;//short version
											}
										}
										else {
											if (ptr[8] <= 0) {
												if (ptr[5] <= 28) {
													return 0;
												}
												else {
													return 1;
												}
											}
											else {
												return 0;
											}
										}
									}
								}
								else {
									if (ptr[7] <= 5) {
										if (ptr[47] <= 0) {
											return 0;
										}
										else {
											return 1;//short version
										}
									}
									else {
										return 0;
									}
								}
							}
							else {
								if (ptr[38] <= 2) {
									if (ptr[54] <= 2) {
										if (ptr[39] <= 0) {
											if (ptr[48] <= 30) {
												return 0;//short version
											}
											else {
												return 0;
											}
										}
										else {
											return 0;
										}
									}
									else {
										return 0;
									}
								}
								else {
									return 1;
								}
							}
						}
						else {
							if (ptr[62] <= 0) {
								if (ptr[54] <= 5) {
									return 0;
								}
								else {
									return 1;
								}
							}
							else {
								return 0;
							}
						}
					}
					else {
						if (ptr[28] <= 0) {
							if (ptr[11] <= 2) {
								if (ptr[13] <= 0) {
									if (ptr[2] <= 2) {
										if (ptr[9] <= 2) {
											if (ptr[12] <= 2) {
												if (ptr[10] <= 11) {
													return 1;
												}
												else {
													return 0;
												}
											}
											else {
												return 0;
											}
										}
										else {
											return 1;
										}
									}
									else {
										return 1;
									}
								}
								else {
									return 0;
								}
							}
							else {
								return 0;
							}
						}
						else {
							return 0;
						}
					}
				}
			}
		}
		else {
			if (ptr[17] <= 10) {
				if (ptr[19] <= 10) {
					if (ptr[36] <= 12) {
						if (ptr[35] <= 10) {
							if (ptr[35] <= 2) {
								if (ptr[1] <= 24) {
									if (ptr[20] <= 30) {
										if (ptr[8] <= 17) {
											if (ptr[16] <= 17) {
												return 0;//short version
											}
											else {
												return 1;
											}
										}
										else {
											return 0;
										}
									}
									else {
										return 1;
									}
								}
								else {
									return 1;
								}
							}
							else {
								if (ptr[20] <= 20) {
									if (ptr[12] <= 0) {
										if (ptr[34] <= 7) {
											if (ptr[37] <= 12) {
												if (ptr[55] <= 20) {
													return 0;
												}
												else {
													return 1;
												}
											}
											else {
												return 0;
											}
										}
										else {
											return 0;
										}
									}
									else {
										if (ptr[22] <= 17) {
											if (ptr[16] <= 17) {
												return 0;//short version
											}
											else {
												return 1;
											}
										}
										else {
											return 0;
										}
									}
								}
								else {
									return 0;
								}
							}
						}
						else {
							if (ptr[33] <= 12) {
								if (ptr[37] <= 15) {
									if (ptr[39] <= 22) {
										if (ptr[14] <= 0) {
											return 0;//short version
										}
										else {
											if (ptr[18] <= 20) {
												if (ptr[54] <= 15) {
													return 0;
												}
												else {
													return 1;
												}
											}
											else {
												return 1;
											}
										}
									}
									else {
										return 1;
									}
								}
								else {
									return 0;
								}
							}
							else {
								return 1;
							}
						}
					}
					else {
						if (ptr[34] <= 7) {
							if (ptr[39] <= 10) {
								if (ptr[33] <= 12) {
									if (ptr[18] <= 12) {
										if (ptr[57] <= 2) {
											if (ptr[69] <= 12) {
												if (ptr[44] <= 15) {
													return 0;
												}
												else {
													return 1;
												}
											}
											else {
												return 1;
											}
										}
										else {
											return 0;
										}
									}
									else {
										return 0;
									}
								}
								else {
									return 1;
								}
							}
							else {
								return 0;
							}
						}
						else {
							if (ptr[23] <= 2) {
								return 1;
							}
							else {
								return 0;
							}
						}
					}
				}
				else {
					if (ptr[35] <= 10) {
						if (ptr[21] <= 5) {
							if (ptr[47] <= 2) {
								if (ptr[18] <= 19) {
									if (ptr[36] <= 20) {
										if (ptr[33] <= 2) {
											if (ptr[65] <= 0) {
												return 0;//short version
											}
											else {
												return 0;
											}
										}
										else {
											return 0;
										}
									}
									else {
										return 1;
									}
								}
								else {
									return 1;
								}
							}
							else {
								return 0;
							}
						}
						else {
							if (ptr[31] <= 0) {
								return 0;
							}
							else {
								return 1;
							}
						}
					}
					else {
						return 0;
					}
				}
			}
			else {
				if (ptr[28] <= 0) {
					if (ptr[21] <= 5) {
						if (ptr[37] <= 10) {
							if (ptr[34] <= 10) {
								if (ptr[38] <= 17) {
									if (ptr[19] <= 22) {
										if (ptr[63] <= 2) {
											if (ptr[10] <= 5) {
												if (ptr[36] <= 25) {
													return 0;
												}
												else {
													return 1;
												}
											}
											else {
												return 0;
											}
										}
										else {
											return 1;
										}
									}
									else {
										return 1;
									}
								}
								else {
									return 1;
								}
							}
							else {
								return 1;
							}
						}
						else {
							return 0;
						}
					}
					else {
						if (ptr[26] <= 2) {
							return 1;
						}
						else {
							return 0;
						}
					}
				}
				else {
					if (ptr[19] <= 7) {
						if (ptr[22] <= 12) {
							if (ptr[3] <= 15) {
								if (ptr[32] <= 2) {
									if (ptr[48] <= 5) {
										if (ptr[8] <= 12) {
											if (ptr[55] <= 16) {
												if (ptr[35] <= 15) {
													return 0;
												}
												else {
													return 1;
												}
											}
											else {
												return 1;
											}
										}
										else {
											return 1;
										}
									}
									else {
										return 1;
									}
								}
								else {
									return 0;
								}
							}
							else {
								return 1;
							}
						}
						else {
							return 0;
						}
					}
					else {
						return 0;
					}
				}
			}
		}
	}
	unsigned char predict_11(unsigned char ptr[]) {
		if (ptr[30] <= 5) {
			if (ptr[26] <= 0) {
				if (ptr[53] <= 2) {
					if (ptr[8] <= 0) {
						if (ptr[37] <= 10) {
							if (ptr[31] <= 15) {
								if (ptr[38] <= 2) {
									if (ptr[63] <= 0) {
										if (ptr[28] <= 0) {
											if (ptr[62] <= 0) {
												return 0;//short version
											}
											else {
												if (ptr[69] <= 2) {
													return 0;
												}
												else {
													return 1;
												}
											}
										}
										else {
											if (ptr[34] <= 17) {
												return 0;//short version
											}
											else {
												return 1;
											}
										}
									}
									else {
										if (ptr[7] <= 0) {
											if (ptr[19] <= 0) {
												if (ptr[14] <= 0) {
													return 1;
												}
												else {
													return 0;
												}
											}
											else {
												return 0;//short version
											}
										}
										else {
											if (ptr[54] <= 2) {
												if (ptr[2] <= 89) {
													return 0;
												}
												else {
													return 1;
												}
											}
											else {
												return 0;
											}
										}
									}
								}
								else {
									if (ptr[14] <= 0) {
										if (ptr[17] <= 10) {
											if (ptr[35] <= 5) {
												if (ptr[34] <= 5) {
													return 0;
												}
												else {
													return 1;
												}
											}
											else {
												if (ptr[11] <= 2) {
													return 1;
												}
												else {
													return 0;
												}
											}
										}
										else {
											if (ptr[19] <= 5) {
												return 1;
											}
											else {
												if (ptr[56] <= 12) {
													return 1;
												}
												else {
													return 0;
												}
											}
										}
									}
									else {
										if (ptr[34] <= 7) {
											if (ptr[22] <= 15) {
												return 0;//short version
											}
											else {
												return 0;
											}
										}
										else {
											return 0;
										}
									}
								}
							}
							else {
								if (ptr[7] <= 0) {
									if (ptr[31] <= 28) {
										if (ptr[18] <= 0) {
											if (ptr[20] <= 2) {
												if (ptr[5] <= 15) {
													return 1;
												}
												else {
													return 0;
												}
											}
											else {
												return 0;
											}
										}
										else {
											if (ptr[19] <= 5) {
												return 1;//short version
											}
											else {
												if (ptr[64] <= 0) {
													return 1;
												}
												else {
													return 0;
												}
											}
										}
									}
									else {
										if (ptr[48] <= 12) {
											if (ptr[2] <= 1) {
												return 1;//short version
											}
											else {
												return 0;
											}
										}
										else {
											if (ptr[6] <= 22) {
												return 1;//short version
											}
											else {
												return 0;
											}
										}
									}
								}
								else {
									if (ptr[7] <= 12) {
										if (ptr[39] <= 2) {
											if (ptr[61] <= 0) {
												return 0;//short version
											}
											else {
												return 0;//short version
											}
										}
										else {
											return 1;
										}
									}
									else {
										if (ptr[16] <= 5) {
											if (ptr[54] <= 7) {
												if (ptr[60] <= 12) {
													return 0;
												}
												else {
													return 1;
												}
											}
											else {
												return 1;
											}
										}
										else {
											if (ptr[17] <= 51) {
												if (ptr[40] <= 3) {
													return 0;
												}
												else {
													return 1;
												}
											}
											else {
												return 1;
											}
										}
									}
								}
							}
						}
						else {
							if (ptr[12] <= 2) {
								if (ptr[75] <= 0) {
									if (ptr[63] <= 0) {
										if (ptr[13] <= 0) {
											if (ptr[77] <= 2) {
												if (ptr[61] <= 0) {
													return 1;
												}
												else {
													return 0;
												}
											}
											else {
												return 1;
											}
										}
										else {
											return 0;
										}
									}
									else {
										return 0;
									}
								}
								else {
									return 0;
								}
							}
							else {
								if (ptr[33] <= 10) {
									return 0;//short version
								}
								else {
									return 1;
								}
							}
						}
					}
					else {
						if (ptr[38] <= 2) {
							if (ptr[23] <= 2) {
								if (ptr[63] <= 0) {
									if (ptr[52] <= 2) {
										if (ptr[48] <= 0) {
											if (ptr[37] <= 5) {
												return 0;//short version
											}
											else {
												if (ptr[19] <= 15) {
													return 0;
												}
												else {
													return 1;
												}
											}
										}
										else {
											if (ptr[37] <= 10) {
												return 0;//short version
											}
											else {
												return 0;
											}
										}
									}
									else {
										if (ptr[54] <= 0) {
											if (ptr[61] <= 0) {
												return 0;//short version
											}
											else {
												return 0;
											}
										}
										else {
											return 1;
										}
									}
								}
								else {
									if (ptr[38] <= 0) {
										if (ptr[68] <= 0) {
											if (ptr[54] <= 12) {
												if (ptr[58] <= 11) {
													return 0;
												}
												else {
													return 1;
												}
											}
											else {
												return 1;
											}
										}
										else {
											return 0;
										}
									}
									else {
										return 0;
									}
								}
							}
							else {
								if (ptr[27] <= 0) {
									if (ptr[7] <= 10) {
										if (ptr[20] <= 15) {
											if (ptr[19] <= 12) {
												return 0;//short version
											}
											else {
												return 1;
											}
										}
										else {
											return 1;//short version
										}
									}
									else {
										if (ptr[70] <= 0) {
											return 1;//short version
										}
										else {
											return 0;
										}
									}
								}
								else {
									if (ptr[9] <= 2) {
										if (ptr[19] <= 12) {
											if (ptr[16] <= 10) {
												return 0;//short version
											}
											else {
												return 1;
											}
										}
										else {
											return 1;
										}
									}
									else {
										return 0;
									}
								}
							}
						}
						else {
							if (ptr[11] <= 0) {
								if (ptr[14] <= 0) {
									if (ptr[28] <= 0) {
										if (ptr[19] <= 10) {
											if (ptr[12] <= 0) {
												if (ptr[76] <= 0) {
													return 1;
												}
												else {
													return 0;
												}
											}
											else {
												return 0;
											}
										}
										else {
											if (ptr[27] <= 2) {
												if (ptr[55] <= 21) {
													return 1;
												}
												else {
													return 0;
												}
											}
											else {
												return 1;
											}
										}
									}
									else {
										return 0;
									}
								}
								else {
									return 0;
								}
							}
							else {
								if (ptr[14] <= 2) {
									if (ptr[33] <= 5) {
										if (ptr[8] <= 22) {
											if (ptr[35] <= 2) {
												if (ptr[21] <= 10) {
													return 0;
												}
												else {
													return 1;
												}
											}
											else {
												return 0;//short version
											}
										}
										else {
											return 1;
										}
									}
									else {
										if (ptr[11] <= 10) {
											return 1;
										}
										else {
											return 0;
										}
									}
								}
								else {
									if (ptr[49] <= 10) {
										return 0;//short version
									}
									else {
										return 1;
									}
								}
							}
						}
					}
				}
				else {
					if (ptr[12] <= 0) {
						if (ptr[10] <= 2) {
							if (ptr[43] <= 5) {
								if (ptr[14] <= 0) {
									if (ptr[35] <= 2) {
										if (ptr[32] <= 2) {
											if (ptr[27] <= 0) {
												if (ptr[11] <= 0) {
													return 1;
												}
												else {
													return 0;
												}
											}
											else {
												return 0;
											}
										}
										else {
											if (ptr[49] <= 20) {
												if (ptr[3] <= 0) {
													return 1;
												}
												else {
													return 0;
												}
											}
											else {
												return 0;
											}
										}
									}
									else {
										if (ptr[60] <= 0) {
											if (ptr[75] <= 0) {
												return 1;//short version
											}
											else {
												return 0;
											}
										}
										else {
											return 0;
										}
									}
								}
								else {
									return 0;
								}
							}
							else {
								if (ptr[27] <= 0) {
									return 1;
								}
								else {
									return 0;
								}
							}
						}
						else {
							if (ptr[33] <= 5) {
								if (ptr[27] <= 0) {
									if (ptr[11] <= 5) {
										if (ptr[39] <= 22) {
											if (ptr[16] <= 10) {
												if (ptr[34] <= 10) {
													return 0;
												}
												else {
													return 1;
												}
											}
											else {
												return 1;
											}
										}
										else {
											return 1;
										}
									}
									else {
										return 0;
									}
								}
								else {
									return 0;
								}
							}
							else {
								if (ptr[32] <= 2) {
									return 0;
								}
								else {
									return 1;
								}
							}
						}
					}
					else {
						if (ptr[20] <= 12) {
							if (ptr[16] <= 10) {
								if (ptr[11] <= 0) {
									if (ptr[51] <= 0) {
										if (ptr[34] <= 15) {
											if (ptr[35] <= 20) {
												return 0;
											}
											else {
												return 1;
											}
										}
										else {
											return 1;
										}
									}
									else {
										return 0;
									}
								}
								else {
									if (ptr[32] <= 19) {
										if (ptr[36] <= 12) {
											if (ptr[35] <= 12) {
												if (ptr[5] <= 16) {
													return 0;
												}
												else {
													return 1;
												}
											}
											else {
												return 0;
											}
										}
										else {
											return 0;
										}
									}
									else {
										return 1;
									}
								}
							}
							else {
								return 1;
							}
						}
						else {
							return 0;
						}
					}
				}
			}
			else {
				if (ptr[20] <= 10) {
					if (ptr[34] <= 7) {
						if (ptr[33] <= 2) {
							if (ptr[35] <= 10) {
								if (ptr[38] <= 12) {
									if (ptr[19] <= 12) {
										if (ptr[27] <= 0) {
											if (ptr[32] <= 15) {
												if (ptr[52] <= 17) {
													return 0;
												}
												else {
													return 1;
												}
											}
											else {
												return 1;
											}
										}
										else {
											if (ptr[5] <= 24) {
												if (ptr[11] <= 40) {
													return 0;
												}
												else {
													return 1;
												}
											}
											else {
												return 1;
											}
										}
									}
									else {
										return 0;//short version
									}
								}
								else {
									if (ptr[35] <= 2) {
										return 0;//short version
									}
									else {
										if (ptr[16] <= 10) {
											return 0;//short version
										}
										else {
											return 1;
										}
									}
								}
							}
							else {
								if (ptr[19] <= 15) {
									if (ptr[25] <= 2) {
										return 0;
									}
									else {
										if (ptr[38] <= 22) {
											return 0;//short version
										}
										else {
											return 1;
										}
									}
								}
								else {
									return 1;
								}
							}
						}
						else {
							if (ptr[21] <= 7) {
								if (ptr[33] <= 12) {
									if (ptr[26] <= 5) {
										if (ptr[35] <= 5) {
											if (ptr[41] <= 28) {
												return 0;//short version
											}
											else {
												return 1;
											}
										}
										else {
											if (ptr[58] <= 10) {
												if (ptr[56] <= 7) {
													return 0;
												}
												else {
													return 1;
												}
											}
											else {
												return 1;
											}
										}
									}
									else {
										if (ptr[18] <= 29) {
											if (ptr[23] <= 33) {
												return 0;//short version
											}
											else {
												return 1;
											}
										}
										else {
											return 1;
										}
									}
								}
								else {
									return 0;
								}
							}
							else {
								if (ptr[33] <= 12) {
									if (ptr[37] <= 17) {
										if (ptr[13] <= 0) {
											return 0;//short version
										}
										else {
											if (ptr[45] <= 0) {
												return 0;//short version
											}
											else {
												return 1;
											}
										}
									}
									else {
										return 1;
									}
								}
								else {
									return 1;
								}
							}
						}
					}
					else {
						if (ptr[35] <= 10) {
							if (ptr[14] <= 0) {
								if (ptr[32] <= 5) {
									if (ptr[33] <= 5) {
										if (ptr[36] <= 15) {
											if (ptr[21] <= 26) {
												return 0;//short version
											}
											else {
												return 1;
											}
										}
										else {
											return 0;
										}
									}
									else {
										return 0;
									}
								}
								else {
									return 1;
								}
							}
							else {
								if (ptr[18] <= 19) {
									if (ptr[27] <= 10) {
										if (ptr[1] <= 5) {
											if (ptr[7] <= 7) {
												if (ptr[15] <= 0) {
													return 0;
												}
												else {
													return 1;
												}
											}
											else {
												return 0;
											}
										}
										else {
											return 0;
										}
									}
									else {
										return 0;
									}
								}
								else {
									return 1;
								}
							}
						}
						else {
							if (ptr[12] <= 2) {
								if (ptr[18] <= 0) {
									return 1;
								}
								else {
									if (ptr[44] <= 10) {
										return 1;
									}
									else {
										return 0;
									}
								}
							}
							else {
								return 0;
							}
						}
					}
				}
				else {
					if (ptr[18] <= 7) {
						if (ptr[13] <= 0) {
							if (ptr[37] <= 7) {
								if (ptr[17] <= 7) {
									return 0;//short version
								}
								else {
									return 0;
								}
							}
							else {
								return 0;
							}
						}
						else {
							if (ptr[34] <= 10) {
								if (ptr[35] <= 10) {
									if (ptr[11] <= 36) {
										if (ptr[49] <= 14) {
											if (ptr[14] <= 38) {
												return 0;//short version
											}
											else {
												return 1;
											}
										}
										else {
											return 1;
										}
									}
									else {
										return 1;
									}
								}
								else {
									return 0;
								}
							}
							else {
								return 0;
							}
						}
					}
					else {
						if (ptr[20] <= 15) {
							return 0;
						}
						else {
							return 1;
						}
					}
				}
			}
		}
		else {
			if (ptr[8] <= 0) {
				if (ptr[31] <= 28) {
					if (ptr[19] <= 0) {
						if (ptr[31] <= 5) {
							if (ptr[25] <= 0) {
								if (ptr[74] <= 5) {
									if (ptr[39] <= 2) {
										return 0;
									}
									else {
										return 1;
									}
								}
								else {
									return 1;
								}
							}
							else {
								return 0;
							}
						}
						else {
							if (ptr[3] <= 0) {
								if (ptr[1] <= 2) {
									if (ptr[18] <= 15) {
										if (ptr[10] <= 12) {
											if (ptr[7] <= 2) {
												if (ptr[28] <= 3) {
													return 1;
												}
												else {
													return 0;
												}
											}
											else {
												return 1;
											}
										}
										else {
											return 0;
										}
									}
									else {
										return 1;//short version
									}
								}
								else {
									return 0;
								}
							}
							else {
								return 0;
							}
						}
					}
					else {
						if (ptr[37] <= 2) {
							if (ptr[17] <= 33) {
								if (ptr[20] <= 0) {
									if (ptr[7] <= 7) {
										if (ptr[27] <= 0) {
											if (ptr[38] <= 5) {
												if (ptr[13] <= 0) {
													return 1;
												}
												else {
													return 0;
												}
											}
											else {
												return 1;
											}
										}
										else {
											return 0;
										}
									}
									else {
										return 0;
									}
								}
								else {
									if (ptr[69] <= 2) {
										if (ptr[31] <= 12) {
											if (ptr[23] <= 5) {
												return 0;//short version
											}
											else {
												return 1;
											}
										}
										else {
											if (ptr[48] <= 33) {
												return 0;//short version
											}
											else {
												return 1;
											}
										}
									}
									else {
										return 1;
									}
								}
							}
							else {
								if (ptr[7] <= 20) {
									if (ptr[6] <= 22) {
										if (ptr[20] <= 28) {
											return 1;//short version
										}
										else {
											return 0;
										}
									}
									else {
										return 0;
									}
								}
								else {
									return 0;
								}
							}
						}
						else {
							if (ptr[63] <= 2) {
								if (ptr[26] <= 0) {
									if (ptr[12] <= 5) {
										if (ptr[46] <= 12) {
											if (ptr[14] <= 5) {
												if (ptr[36] <= 45) {
													return 1;
												}
												else {
													return 0;
												}
											}
											else {
												return 0;
											}
										}
										else {
											return 0;
										}
									}
									else {
										return 0;
									}
								}
								else {
									return 0;
								}
							}
							else {
								return 0;
							}
						}
					}
				}
				else {
					if (ptr[7] <= 2) {
						if (ptr[2] <= 5) {
							if (ptr[69] <= 5) {
								if (ptr[5] <= 7) {
									if (ptr[6] <= 12) {
										if (ptr[1] <= 11) {
											if (ptr[36] <= 15) {
												return 1;//short version
											}
											else {
												return 0;
											}
										}
										else {
											return 0;
										}
									}
									else {
										if (ptr[46] <= 15) {
											return 1;
										}
										else {
											return 0;
										}
									}
								}
								else {
									if (ptr[62] <= 12) {
										if (ptr[1] <= 2) {
											if (ptr[18] <= 52) {
												return 1;//short version
											}
											else {
												return 0;
											}
										}
										else {
											return 1;
										}
									}
									else {
										return 0;
									}
								}
							}
							else {
								return 0;
							}
						}
						else {
							return 0;
						}
					}
					else {
						if (ptr[6] <= 20) {
							if (ptr[35] <= 0) {
								if (ptr[2] <= 2) {
									if (ptr[3] <= 2) {
										if (ptr[19] <= 17) {
											if (ptr[7] <= 15) {
												if (ptr[50] <= 5) {
													return 1;
												}
												else {
													return 0;
												}
											}
											else {
												return 0;
											}
										}
										else {
											return 0;
										}
									}
									else {
										return 0;
									}
								}
								else {
									return 0;
								}
							}
							else {
								return 0;
							}
						}
						else {
							return 0;
						}
					}
				}
			}
			else {
				if (ptr[38] <= 2) {
					if (ptr[53] <= 2) {
						if (ptr[16] <= 17) {
							if (ptr[30] <= 12) {
								if (ptr[23] <= 2) {
									if (ptr[16] <= 5) {
										if (ptr[71] <= 5) {
											if (ptr[17] <= 61) {
												return 0;//short version
											}
											else {
												return 1;
											}
										}
										else {
											return 0;
										}
									}
									else {
										if (ptr[37] <= 5) {
											if (ptr[17] <= 51) {
												return 0;//short version
											}
											else {
												return 1;
											}
										}
										else {
											return 1;
										}
									}
								}
								else {
									return 0;
								}
							}
							else {
								if (ptr[8] <= 17) {
									if (ptr[31] <= 68) {
										return 0;
									}
									else {
										return 1;
									}
								}
								else {
									return 0;
								}
							}
						}
						else {
							return 0;
						}
					}
					else {
						return 1;
					}
				}
				else {
					if (ptr[32] <= 5) {
						if (ptr[35] <= 5) {
							return 0;
						}
						else {
							return 1;
						}
					}
					else {
						return 1;
					}
				}
			}
		}
	}
	public:
	unsigned char c_predict(unsigned char ptr[]) {
		unsigned char sum = 0;
		sum += predict_0(ptr);
		sum += predict_1(ptr);
		sum += predict_2(ptr);
		sum += predict_3(ptr);
		sum += predict_4(ptr);
		sum += predict_5(ptr);
		sum += predict_6(ptr);
		sum += predict_7(ptr);
		sum += predict_8(ptr);
		sum += predict_9(ptr);
		sum += predict_10(ptr);
		sum += predict_11(ptr);
		return sum;
	}

};