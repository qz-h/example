﻿// inpaint.cpp : コンソール アプリケーションのエントリ ポイントを定義します。
//

#include "stdafx.h"
#include "includeOpenCV.h"
#include <string>
#include<tchar.h>
#include<math.h>
#include <direct.h>
#include<fstream>
#include<iostream>

#include "utils.h"
#include "imageSpillter.h"

#include "contourMgr.h"
using namespace cv;
using namespace std;
string mode_txt="";
ContourMgr contourMgr;
bool checkFileExistence(const std::string& str)
{
	std::ifstream ifs(str);
	return ifs.is_open();
}
void my_mouse_callback(int event, int x, int y, int flags, void* param) {
	switch (event) {
	case cv::EVENT_LBUTTONDOWN:
		contourMgr.onClick(x, y, my_mouse_callback);
		break;
	}
}
void main_test(string tag, string model_path) {
	goodBadDetecctor kk;
	kk.test(tag, model_path);
	return;
}
void main_test_2(string tag) {
	goodBadDetecctor kk;
	kk.test_c(tag);
	return;
}
void main_export(string model_path) {
	goodBadDetecctor kk;
	kk.export_model(model_path);
	return;
}
void tree_train(string path,int a,int b,int c,int d, float weight)
{
	goodBadDetecctor kk;
	kk.train(path,a,b,c,d, weight);
	if (a<0){
	int i;
	std::cin >> i;
	}
	return ;
}
void svm_train(string path, int a, int b, int c, int d, float weight)
{
	goodBadDetecctor_svm kk;
	kk.train(path, a, b, c, d, weight);
	if (a<0) {
		int i;
		std::cin >> i;
	}
	return;
}
int main_split(string src_name= "D:/data/20180504/good180503/g1.bmp",bool no_windows=false,std::string target="")
{
	imageSpillter kk;
	kk.solve(src_name, no_windows, target);
	return 0;
}

int main(int argc, char *argv[])
{
	int ScaleOut = 1;
	string src_name = "out1.png";
	string tag = "";
	string shuchu = "";

	std::cout << "[";
	for (int i = 0; i < argc; i++) {
		std::cout << argv[i]  << ", ";
	}
	std::cout << "]" << std::endl;

	if (argc >= 2) {
		src_name = argv[1];
		std::cout << "src_name:" << src_name << std::endl;
	}
	if (argc >= 3) {
		//out
		//cut
		//detect
		//train
		//gb2rgb
		//bg_level
		mode_txt = argv[2];
		
		//no_window = true;
	}
	if (argc >= 4) {
		tag = argv[3];
	}
	if (argc >= 5) {
		shuchu = argv[4];
	}
	if (mode_txt.find("tree_train") == 0) {
		int a, b, c, d; float weight;
		if (argc>4){
			a = atoi(argv[4]);//depth
			b = atoi(argv[5]);//samples
			c = atoi(argv[6]);//0
			d = atoi(argv[7]);//tree num
			weight= atof(argv[8]);//weight
		}
		else {
			a = -1; b = -1; c = -1; d = -1; 
			float weight = 1.75;
		}
		
		tree_train(tag,a,b,c,d, weight);
		return 0;
	}else if (mode_txt.find("svm_train") == 0) {
		int a, b, c, d; float weight;
		if (argc>4) {
			a = atoi(argv[4]);//depth
			b = atoi(argv[5]);//samples
			c = atoi(argv[6]);//0
			d = atoi(argv[7]);//tree num
			weight = atof(argv[8]);//weight
		}
		else {
			a = -1; b = -1; c = -1; d = -1;
			float weight = 1.75;
		}

		svm_train(tag, a, b, c, d, weight);
		return 0;
	}
	else if (mode_txt.find("test") == 0) {
		main_test(tag, shuchu);
		return 0;
	}
	else if (mode_txt.find("code_test") == 0) {
		main_test_2(tag);
		return 0;
	}
	else if (mode_txt.find("gb2rgb-gui") == 0) {
		main_split(src_name,false);
		return 0;
	}
	else if (mode_txt.find("gb2rgb") == 0) {
		main_split(src_name,true,tag);
		return 0;
	}
	else if (mode_txt.find("export") == 0) {
		main_export(src_name);
		return 0;
	}
	else if (mode_txt.find("bg_level") == 0) {
		//输入一个全黑的图片计算平均值
		Mat img = cv::imread(src_name, 1);

		vector<Mat> channels(3);
		// split img:
		split(img, channels);//gbr
		
		cv::Scalar pingjun = cv::mean(img);

		double b_zuida,b_zuixiao ;
		double r_zuida, r_zuixiao;
		cv::minMaxLoc(channels[0], &b_zuixiao, &b_zuida);
		cv::minMaxLoc(channels[0], &b_zuixiao, &b_zuida);

		std::cout << "Pingjun (B,R):\n";
		std::cout << "(" << pingjun[0] << "," << pingjun[2] << ")\n";

		std::cout << "Zuida (B,R)\n:";
		std::cout << "(" << b_zuida << "," << r_zuida << ")";
		return 0;
	}
	else {
		Mat img = cv::imread(src_name, 1);
		if (ScaleOut > 1) {
			cv::Size2i newImageSize = img.size();
			newImageSize.width /= ScaleOut;
			newImageSize.height /= ScaleOut;
			cv::resize(img, img, newImageSize);
		}
		if (mode_txt.find("cut") == 0) {
			int x_v = atoi(tag.c_str());
			if (x_v > img.rows) {
				x_v = img.rows - 10;
			}
			img = img(cv::Rect(0, x_v, 2048, 1000));
		}
		
		if (mode_txt.find("out") == 0) {
			contourMgr.setDemon();
		}
		contourMgr.init(img, ScaleOut);

		if (mode_txt.find("detect") == 0) {
			ofstream ofs("detect.csv", ofstream::app);
			contourMgr.setDemon();
			std::vector<float> results;
			for (int i = 0; i < contourMgr.contours_suitable.size() && i<200; i++) {
				auto gailv = contourMgr.pridict(i);
				if (gailv == 100000) {
					contourMgr.setDemon(false);
					contourMgr.show_debug_image(my_mouse_callback);
					contourMgr.onClick(i, my_mouse_callback);
					cv::waitKey();
				}
				results.push_back(gailv);
				
			}
			for (int i = 0; i < results.size(); i++) {
				std::cout << results[i] << std::endl;
				ofs << src_name << "," << tag << "," << results[i] << std::endl;
			}
			
			ofs.close();
			return 1;
		}
		if (mode_txt.find("crop") == 0) {
			contourMgr.setDemon();
			//std::vector<float> results;
			string shortFileName = argv[3];
			for (int i = 0; i < contourMgr.contours_suitable.size() && i<200; i++) {
				contourMgr.crop(i, shortFileName);
			}
		}
		else if (mode_txt.find("out") == 0) {
			
			contourMgr.setDemon();
			bool is_new_file = false;
			if (shuchu.length() == 0) {
				shuchu = "result.csv";
			}
			if (checkFileExistence(shuchu)==false) {
				is_new_file = true;
			}
			ofstream ofs(shuchu, ofstream::app);
			if (is_new_file){
				for (int i = 0; i < 316; i++) {
					ofs << i << ",";
				}
				ofs << "\n";
			}
			
			string image_name;
			for (int i = 0; i < contourMgr.contours_suitable.size(); i++) {

				//计算面积，周长等信息作为参考
				double area = contourArea(contourMgr.contours_suitable[i]);
				double perimeter = cv::arcLength(contourMgr.contours_suitable[i], true);

				auto result = contourMgr.extractFeature(i);

				for (auto it = result.begin(); it != result.end(); it++) {
					ofs << *it << ",";
				}
				if (tag.length() > 0) {
					ofs << tag << ",";
				}

				//计算种子的平均值作为光强度的标准
				if(true){
					cv::Scalar pingjun = contourMgr.get_mean_color(i);

					ofs << pingjun[0] << ",";
					ofs << pingjun[2] << ",";
				}


				if (result.size() > 0) {
					ofs << "\n";
				}
				std::cout << i << "/" << contourMgr.contours_suitable.size() << std::endl;
			}
			ofs.close();
		}
		else {
			Mat result;
			imshow("Orgrion Image", img);
			contourMgr.show_debug_image(my_mouse_callback);
			int k = cv::waitKey(0);
		}
	}
	return 0;
}
