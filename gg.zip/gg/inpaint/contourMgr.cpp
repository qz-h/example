﻿#include "contourMgr.h"


ContourMgr::ContourMgr() { no_window = false; };
void ContourMgr::setDemon(bool flag) {
	no_window = flag;
	
	imageProcesser.setDemon(flag);
}
cv::Mat get_qian(cv::Mat & img) {
	/*
	基本思路
	第一列都视为是背景
	如果比当前值小或者不大于10都认为是背景。
	修改背景值为 原始值x0.9+现在值*0.1
	如果是前景 原始值x0.99+现在值*0.01
	输出结果
	*/
	cv::Mat result = cv::Mat::zeros(img.size(), img.type());
	std::vector<float> bg;
	for (int i = 0; i < img.rows; i++) {
		for (int j = 0; j < img.cols; j++) {
			if (i == 0) {
				bg.push_back(img.at<unsigned char>(i, j));
			}
			else {
				float now_color = img.at<unsigned char>(i, j);
				if (now_color - bg[j] > 8) {
					result.at<unsigned char>(i, j) = 255;
					bg[j] = bg[j] * 0.995 + now_color * 0.005;
				}
				else {
					bg[j] = bg[j] * 0.98 + now_color * 0.02;
				}
			}
		}
	}
	return result;
}
void ContourMgr::init(cv::Mat img,int ScaleOut)
{
	imageProcesser.init(img);

	this->ScaleOut = ScaleOut;
	
	rgb_image = img.clone();
	
	Mat dst = img.clone();

	cvtColor(dst, dst, CV_BGR2GRAY);
	//std::cout << "get no_window=" << no_window << std::endl;
	if (!no_window)
		cv::imshow("dst gray", dst);

	//这里按照王总的意见做一个建议版本的背景抽取算法
//#if 1

	vector<Mat> channels(3);
	split(img, channels);
	cv::Mat chaochu_map = channels[2].clone();

	chaochu_map = chaochu_map>Background_Level;
	chaochu_map=get_qian(chaochu_map);
//#if 0
//	imshow("chaochu_map1", chaochu_map);
//	cv::waitKey(0);
//	chaochu_map /= 51;
//	cv::Mat kernel_gradient_3x3 = (cv::Mat_<int>(3, 3) << 1, 1, 1, 1, 0, 1, 1, 1, 1);
//	Mat img_gradient_3x3;
//	cv::filter2D(chaochu_map, chaochu_map, -1, kernel_gradient_3x3);
//	
//	double zuida, zuixiao;
//	cv::minMaxLoc(chaochu_map, &zuixiao, &zuida);
//	
//	//std::cout  << "NNNN\n" << zuida;
//	//cv::waitKey(0);
//	dst = chaochu_map>39;
//#endif
	dst = chaochu_map;

	if (!no_window)
		imshow("chaochu_map2", dst);
//#else
//	threshold(dst, dst, Background_Level, 255, THRESH_BINARY);//10
//#endif



//	//是否做侵蚀处理.一般不用做
//#if USE_ERODE==1
//	cv::Mat erode_kernal = cv::Mat::ones(3, 3, CV_8UC1);
//
//	if (ScaleOut > 1) {
//		erode_kernal = cv::Mat::ones(3, 3, CV_8UC1);
//	}
//	cv::erode(dst, dst, erode_kernal);
//#endif
	if (!no_window)
	imshow("dst", dst);
	vector<vector<Point> > contours;
	contours.clear();
	findContours(dst, contours, CV_RETR_EXTERNAL, CV_CHAIN_APPROX_NONE);
	contours_suitable.clear();

	for (int i = 0; i<contours.size(); i++) {
		double area = contourArea(contours.at(i));
		double perimeter = cv::arcLength(contours.at(i), true);

		if (contours[i].size()>4) {
			if (area*ScaleOut*ScaleOut>Mini_Aera && area*ScaleOut*ScaleOut<20000) {
				contours_suitable.push_back(contours.at(i));
			}
		}
	}
}

cv::Mat ContourMgr::make_debug_image(){
	cv::Mat result;
	Mat mask = Mat::zeros(rgb_image.rows, rgb_image.cols, CV_8UC1);
	drawContours(mask, contours_suitable, -1, Scalar(255), -1);


	rgb_image.copyTo(result, mask);
	result.setTo(cv::Scalar(255, 255, 255), (1 - mask));
	return result;
}

void ContourMgr::show_debug_image(cv::MouseCallback my_mouse_callback) {
	auto result = make_debug_image();
	imshow("Result", result);
	cv::setMouseCallback("Result", my_mouse_callback);
}

ContourMgr::~ContourMgr()
{
}

void ContourMgr::nouse()
{
#if 0
	//BGR中R-G
	cv::Mat R_Float, B_Float;
	BGR_planes[2].convertTo(R_Float, CV_32F);
	BGR_planes[0].convertTo(B_Float, CV_32F);
	R_Float -= B_Float;

	//R_Float = abs(R_Float);

	R_Float += 255;
	R_Float /= 2;

	R_Float.convertTo(R_B_sub_u8, CV_8U);
	/*imshow("BGR_planes[0]", BGR_planes[0]);
	cv::imwrite("Blue.bmp", BGR_planes[0]);
	cv::imwrite("Red.bmp", BGR_planes[2]);
	imshow("BGR_planes[2]", BGR_planes[2]);*/
	if (!no_window)
		imshow("R_B_sub_u8", R_B_sub_u8);


	cv::Mat kernel_gradient_3x3_rb = (cv::Mat_<int>(3, 3) << -1, -1, -1, -1, 8, -1, -1, -1, -1);
	Mat img_gradient_3x3_rb;
	cv::filter2D(R_B_sub_u8, img_gradient_3x3_rb, -1, kernel_gradient_3x3_rb);

	if (!no_window)
		imshow("(R-B)_gradient_3x3", img_gradient_3x3_rb);


#endif

#if 0
	cv::Mat kernel_gradient_3x3 = (cv::Mat_<int>(3, 3) << -1, -1, -1, -1, 8, -1, -1, -1, -1);
	Mat img_gradient_3x3;
	cv::filter2D(dst, img_gradient_3x3, -1, kernel_gradient_3x3);

	if (!no_window)
		imshow("original_img_gradient_3x3", img_gradient_3x3);
#endif
}
std::vector<float>  ContourMgr::extractFeature(int id) {
	return  imageProcesser.getALLDestcriptors(contours_suitable.at(id));
}
cv::Scalar ContourMgr::get_mean_color(int id){
	return  imageProcesser.get_mean_color(contours_suitable.at(id));
}
float ContourMgr::pridict(std::vector<float> feature) {
	return kk.pridict(kk.makeDes(feature), false,0,true);
}
float ContourMgr::pridict(int id) {
	return kk.pridict(kk.makeDes(extractFeature(id)), false,0,true);
}
void ContourMgr::onClick(int x, int y, cv::MouseCallback my_mouse_callback) {
	vector<vector<Point> > show_contours_subset;
	for (int i = 0; i < contours_suitable.size(); i++) {

		if (pointPolygonTest(contours_suitable[i], Point2f(x, y), true) >= 0) {
			cv::Mat show_temp_image = make_debug_image();

			show_contours_subset.clear();
			show_contours_subset.push_back(contours_suitable[i]);

			auto gailv = pridict(i);

			std::cout << "Gailv:" << gailv << std::endl;

			if (gailv<0.5) {
				//BGR
				//说明好的是0，坏的是1
				drawContours(show_temp_image, show_contours_subset, -1, Scalar(0, 255, 0), 2);
			}
			else {
				drawContours(show_temp_image, show_contours_subset, -1, Scalar(0, 0, 255), 2);
			}
			cv::imshow("Result", show_temp_image);
			cv::setMouseCallback("Result", my_mouse_callback);
		}
	}
}

void ContourMgr::onClick(int x, cv::MouseCallback my_mouse_callback) {
	vector<vector<Point> > show_contours_subset;
	int i = x;
	cv::Mat show_temp_image = make_debug_image();

	

	show_contours_subset.clear();
	show_contours_subset.push_back(contours_suitable[i]);

	auto gailv = pridict(i);

	std::cout << "Gailv:" << gailv << std::endl;

	if (gailv<0.5) {
		drawContours(show_temp_image, show_contours_subset, -1, Scalar(0, 255, 0), 2);
	}
	else {
		drawContours(show_temp_image, show_contours_subset, -1, Scalar(0, 0, 255), 2);
	}
	cv::imshow("Result", show_temp_image);
	cv::setMouseCallback("Result", my_mouse_callback);
		
	
}
void ContourMgr::crop(int i, string shortFileName) {
	auto box = findEllipse(contours_suitable.at(i));
	imageProcesser.cropImage(rgb_image,box, shortFileName,i);
}
RotatedRect ContourMgr::findEllipse(std::vector<Point> c) {
	Mat inputpoints;
	Mat(c).convertTo(inputpoints, CV_32F);

	//RotatedRect box = minAreaRect(inputpoints);    //楕円フィッティング
	RotatedRect box1 = fitEllipse(inputpoints);    //最小矩形(回転を考慮)算出

	return box1;
}
void cutImage() {
	/*for (int i = 0; i < 10; i++) {
	std::ostringstream fileName;


	fileName << image_name << "_" << i << ".bmp";
	cv::imwrite(fileName.str(), img(cv::Rect(0, i * 2000, 2048, 2000)));
	}
	return 0;*/
}