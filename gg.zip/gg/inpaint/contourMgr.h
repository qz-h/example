#pragma once
#include "opencv2\opencv.hpp"
#include <string>
#include<tchar.h>
#include<math.h>
#include <direct.h>
#include<fstream>
#include<iostream>
#include "imageProcesser.h"
#include "utils.h"
#define USE_ERODE 0
#define USE_DISTANCE 1
#define Mini_Aera 16
//default Background_Level 10
#define Background_Level 25
using namespace cv;
class ContourMgr
{
	bool no_window;
	void nouse();
	int ScaleOut;
	
	cv::Mat rgb_image;
	goodBadDetecctor kk;
	ImageProcesser imageProcesser=ImageProcesser(false);
	//void my_mouse_callback(int event, int x, int y, int flags, void* param);
public:
	vector<vector<Point> > contours_suitable;
	
	void init(cv::Mat image,int ScaleOut);
	cv::Mat make_debug_image();
	
	std::vector<float>  extractFeature(int id);
	float pridict(std::vector<float> feature);
	float pridict(int id);
	void crop(int i, string shortFileName);
	void onClick(int x,int y, cv::MouseCallback my_mouse_callback);
	void onClick(int x, cv::MouseCallback my_mouse_callback);
	void show_debug_image(cv::MouseCallback my_mouse_callback);
	RotatedRect ContourMgr::findEllipse(std::vector<Point> c);
	void setDemon(bool flag=true);

	cv::Scalar get_mean_color(int i);
	ContourMgr();
	~ContourMgr();
};

