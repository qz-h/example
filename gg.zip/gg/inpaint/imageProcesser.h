#pragma once
#include "opencv2\opencv.hpp"
#include <string>
#include<tchar.h>
#include<math.h>
#include <direct.h>
#include<fstream>
#include<iostream>
using namespace cv;
using namespace std;
#define USE_DISTANCE 1
class ImageProcesser
{
	cv::Mat makeHV(cv::Mat hsv, cv::Mat mask, std::vector<float> & buff);
	cv::Mat makeHS(cv::Mat hsv, cv::Mat mask, std::vector<float> & buff);
	cv::Mat makeSV(cv::Mat hsv, cv::Mat mask, std::vector<float> & buff);
	cv::Mat makeRGB(cv::Mat rgb, cv::Mat mask, int type, std::vector<float> & buff);
	bool no_window;

	void make_x(cv::Mat &x, cv::Point p1, cv::Point p2, std::vector<String> label);
	void make_y(cv::Mat &x, cv::Point p1, cv::Point p2, std::vector<String> label);

	std::vector<float> getDistancefeature(std::vector<Point> c, bool dir);
	
	bool hasOcao(std::vector<float> resultDes, float xia, int jian);

	float tSum(cv::Mat & t, int n);
	float tMax(std::vector<float> t);
	RotatedRect findEllipse(std::vector<Point> c);

	Mat hsv_image;
	vector<Mat> HSV_planes;
	vector<Mat> BGR_planes;
	cv::Mat rgb_image;
	cv::Mat r_image_2;
	cv::Mat r_image_4;
	cv::Mat r_image_8;
public:
	ImageProcesser(bool no_window);
	~ImageProcesser();
	void init(cv::Mat image);
	void showHSV(cv::Mat hsv, cv::Mat mask, std::vector<float> & buff);
	void showRGB(cv::Mat rgb, cv::Mat mask, std::vector<float> & buff);
	void showMinColor(cv::Mat rgb, cv::Mat mask, std::vector<float> & buff);
	String cropImage(cv::Mat img_copy, cv::RotatedRect k, string image_name, int id,int mode=0);

	std::vector<float> getRGBFeature(std::vector<Point> c, String title) { return getDestcriptor(false,c,title); }
	std::vector<float> getHSVFeature(std::vector<Point> c, String title) { return getDestcriptor(true, c, title); }
	std::vector<float> getDestcriptor(bool is_hsv, std::vector<Point> c, String title);
	
	std::vector<float> getDistancefeature(std::vector<Point> c);
	cv::Scalar get_mean_color(std::vector<Point> c);
	void show_distance(std::vector<float> resultDes, string title);

	std::vector<float> getALLDestcriptors(std::vector<Point> c);
	void setDemon(bool flag);
};

