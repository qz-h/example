﻿#include "imageSpillter.h"

cv::Mat yy, yy2;
cv::Mat linshi;
cv::Mat out1;
cv::Mat out2;
bool tuichu;
std::string shuchuName = "";
imageSpillter::imageSpillter()
{
}


imageSpillter::~imageSpillter()
{
}
void imageSpillter::solve(std::string src_name, bool no_windows, std::string target)
{
	this->no_windows = no_windows;
	image_raw = cv::imread(src_name, 0);
	//cv::imshow("yuanshi",image_raw);
	std::cout<< "Image size:"<< image_raw.cols << "," << image_raw.cols;
	yashuo();
	split();
	shift();
	merger(no_windows,target);
}

void imageSpillter::split()
{
	auto orginal_size = image_raw.size();
	auto targetRow = orginal_size.height;
	if (targetRow % 2 == 1) {
		targetRow = targetRow - 1;
	}
	targetRow = targetRow / 2;
	cv::Size2i splitSize = cv::Size2i(orginal_size.width, targetRow);

	image_a= cv::Mat::zeros(splitSize, CV_8UC1);
	image_b = cv::Mat::zeros(splitSize, CV_8UC1);
	image_b_shifted_1= cv::Mat::zeros(splitSize, CV_8UC1);
	image_b_shifted_2 = cv::Mat::zeros(splitSize, CV_8UC1);
	int writeRow = 0;
	for (int j = 0; j < targetRow * 2; j+=2) {
		for (int i = 0; i < orginal_size.width; i++) {
			image_a.at<unsigned char>(writeRow, i) = image_raw.at<unsigned char>(j, i);
			image_b.at<unsigned char>(writeRow, i) = image_raw.at<unsigned char>(j+1, i);
		}
		writeRow++;
	}

}

void imageSpillter::yashuo()
{
	//x方向压缩一半
	auto output_size = image_raw.size();
	output_size.width = output_size.width / 4;
	cv::resize(image_raw, image_raw, output_size);
	if (!no_windows)
	cv::imshow("image_raw_yasuo", image_raw);
}

void imageSpillter::shift()
{
#if 0
	for (int j = 1; j < image_b.rows-1; j++) {
		for (int i = 0; i < image_b.cols; i++) {
			int sum = image_b.at<unsigned char>(j-1, i) + image_b.at<unsigned char>(j+1, i);
			image_b_shifted.at<unsigned char>(j, i) = (unsigned char)(sum / 2);
			
		}
	}
#endif
#if 1
	for (int j = 1; j < image_b.rows - 1; j++) {
		for (int i = 0; i < image_b.cols; i++) {
			int sum = image_b.at<unsigned char>(j - 1, i);
			image_b_shifted_1.at<unsigned char>(j, i) = (unsigned char)(sum);

		}
	}
#endif

#if 1
	for (int j = 1; j < image_b.rows - 1; j++) {
		for (int i = 0; i < image_b.cols; i++) {
			int sum = image_b.at<unsigned char>(j + 1, i);
			image_b_shifted_2.at<unsigned char>(j, i) = (unsigned char)(sum);

		}
	}
#endif


}
cv::Mat imageSpillter::get_qian(cv::Mat & img) {
	/*
	基本思路
	第一列都视为是背景
	如果比当前值小或者不大于10都认为是背景。
	修改背景值为 原始值x0.9+现在值*0.1
	如果是前景 原始值x0.99+现在值*0.01
	输出结果
	*/
	cv::Mat result = cv::Mat::zeros(img.size(), img.type());
	std::vector<float> bg;
	for (int i = 0; i < img.rows; i++) {
		for (int j = 0; j < img.cols; j++) {
			if (i == 0) {
				bg.push_back(img.at<unsigned char>(i, j));
			}
			else {
				float now_color = img.at<unsigned char>(i, j);
				if (now_color - bg[j] > 10) {
					result.at<unsigned char>(i, j) = 255;
					bg[j] = bg[j] * 0.995 + now_color * 0.005;
				}
				else {
					bg[j] = bg[j] * 0.98 + now_color * 0.02;
				}
			}
		}
	}
	return result;
}



float yellowCheck(cv::Mat & Rimg, cv::Mat & Bimg) {
	float result=0;
	for (int i = 0; i < Rimg.rows; i++) {
		for (int j = 0; j < Rimg.cols; j++) {
			int B = Bimg.at<unsigned char>(i, j);
			
			int R = Rimg.at<unsigned char>(i, j);



			if ((R - B > 10) && (R>60) && (R<200) && (B>30)) {
				result++;
			}
		}
	}
	return result;
}
void my_mouse_callback11(int event, int x, int y, int flags, void* param) {
	
	int i = y;
	int j = x;
	switch (event) {
	case cv::EVENT_MOUSEMOVE:
		int B = yy.at<cv::Vec3b>(i, j)[0];
		int G = yy.at<cv::Vec3b>(i, j)[1];
		int R = yy.at<cv::Vec3b>(i, j)[2];
		std::cout << "(B,G,R)=(" << B << "," << G << "," << R <<")" << std::endl;
		cv::rectangle(yy, cv::Rect(0, 0, 30, 30), cv::Scalar(255, 255, 255), -1);
		cv::rectangle(yy, cv::Rect(10, 10, 10, 10), cv::Scalar(B, G, R), -1);
		cv::imshow("result1", yy);

		cv::setMouseCallback("result1", my_mouse_callback11, (void *)&yy);
		break;
	}
}
void my_mouse_callback22(int event, int x, int y, int flags, void* param) {

	int i = y;
	int j = x;
	switch (event) {
	case cv::EVENT_MOUSEMOVE:
		int B = yy2.at<cv::Vec3b>(i, j)[0];
		int G = yy2.at<cv::Vec3b>(i, j)[1];
		int R = yy2.at<cv::Vec3b>(i, j)[2];
		std::cout << "(B,G,R)=(" << B << "," << G << "," << R << ")" << std::endl;
		cv::rectangle(yy2, cv::Rect(0, 0, 30, 30), cv::Scalar(255, 255, 255), -1);
		cv::rectangle(yy2, cv::Rect(10, 10, 10, 10), cv::Scalar(B, G, R), -1);
		cv::imshow("result2", yy2);

		cv::setMouseCallback("result2", my_mouse_callback22, (void *)&yy2);
		break;
	}
}
void my_mouse_callback33(int event, int x, int y, int flags, void* param) {

	int i = y;
	int j = x;
	cv::Mat bb = linshi.clone();
	switch (event) {
	case cv::EVENT_MOUSEMOVE:
		if (x*2<linshi.cols) {
			cv::rectangle(bb, cv::Rect(0, 0, bb.cols/2, 800), cv::Scalar(255, 0, 0), 2);
			
		}
		else {
			cv::rectangle(bb, cv::Rect(bb.cols / 2, 0, bb.cols / 2, 800), cv::Scalar(255, 0, 0), 2);
			
		}
		cv::imshow("xuanze", bb);
		cv::setMouseCallback("xuanze", my_mouse_callback33, (void *)&bb);
		break;
	case cv::EVENT_LBUTTONDOWN:
		
		if (x * 2 < linshi.cols) {
			std::cout << "save out1:" << shuchuName << std::endl;
			cv::imwrite("temp.bmp", out1);
			tuichu = true;
		}
		else {
			std::cout << "save out2:" << shuchuName << std::endl;
			cv::imwrite("temp.bmp", out2);
			tuichu = true;
		}
		
		break;
	}
}
void imageSpillter::merger(bool jidong,std::string target)
{
	image_g= cv::Mat::zeros(image_a.size(), CV_8UC1);
	image_g.setTo(0);

	

	//白平衡
	double a_mean = cv::mean(image_a)[0];
	double b_mean = cv::mean(image_b_shifted_1)[0];

	//临时处理

	cv::Mat image_a_temp = image_a.clone();
	cv::Mat image_b_temp = image_b_shifted_1.clone();

	/*cv::Mat image_a_nise_map = image_a_temp < 10;
	cv::Mat image_b_nise_map = image_b_temp < 10;

	cv::bitwise_and(image_a_temp, cv::Mat::zeros(image_a_temp.size(), image_a_temp.type() )  , image_a_temp, image_a_nise_map);
	cv::bitwise_and(image_b_temp, cv::Mat::zeros(image_b_temp.size(), image_b_temp.type()), image_b_temp, image_b_nise_map);
*/
	//cv::Mat image_a_qian = get_qian(image_a_temp);
	//cv::Mat image_b_qian = get_qian(image_b_temp);
	//if (!no_windows) {
	//	cv::imshow("image_a_qian", image_a_qian);
	//	cv::imshow("image_b_qian", image_b_qian);
	//}
	//if (cv::mean(image_a_qian)[0] > cv::mean(image_b_qian)[0]) {
	//	std::cout << "use a qian" << std::endl;

	//	cv::bitwise_and(image_a_temp, image_a_qian, image_a_temp);
	//	cv::bitwise_and(image_b_temp, image_a_qian, image_b_temp);

	//	/*a_mean = cv::mean(image_a_temp, image_a_qian)[0];
	//	b_mean = cv::mean(image_b_temp, image_a_qian)[0];*/
	//}
	//else {
	//	std::cout << "use b qian" << std::endl;
	//	cv::bitwise_and(image_a_temp, image_b_qian, image_a_temp);
	//	cv::bitwise_and(image_b_temp, image_b_qian, image_b_temp);
	//	/*a_mean = cv::mean(image_a_temp, image_b_qian)[0];
	//	b_mean = cv::mean(image_b_temp, image_b_qian)[0];*/
	//}
	//
	//cv::imshow("image_a_temp", image_a_temp);
	//cv::imshow("image_b_temp", image_b_temp);
	//cv::Mat cha1 = image_a_temp > image_b_temp;
	//cv::Mat cha2 = image_a_temp < image_b_temp;
	//

	//

	//std::cout << "a_mean:" << a_mean << std::endl;
	//std::cout << "b_mean:" << b_mean << std::endl;

#if 0
	

	image_a = image_a * ((a_mean + b_mean) /( 2 * a_mean));
	image_b_shifted = image_b_shifted * ((a_mean + b_mean) /( 2 * b_mean));
#endif
	image_a = image_a * 1;
	image_b_shifted_2 = image_b_shifted_1 * 1;
	image_b_shifted_2 = image_b_shifted_2 * 1;
	

	if (!no_windows) {
		cv::imshow("image_a", image_a);
		cv::imshow("image_b", image_b);
		cv::imshow("image_b_shifted", image_b_shifted_1);
	}


	//亮度增强
	image_a = image_a * 2;
	image_b_shifted_1 = image_b_shifted_1 * 2;



	/*std::cout << "out1=" << yellowCheck(image_b_shifted_1, image_a) << std::endl;
	std::cout << "out2=" << yellowCheck(image_a, image_b_shifted_2) << std::endl;*/


	std::vector<cv::Mat> inputImages1;
	inputImages1.push_back(image_b_shifted_1);
	inputImages1.push_back(image_g);
	inputImages1.push_back(image_a);
	
	
	cv::merge(inputImages1, out1);
	



	std::vector<cv::Mat> inputImages2;
	inputImages2.push_back(image_a);
	inputImages2.push_back(image_g);
	inputImages2.push_back(image_b_shifted_2);
	

	
	cv::merge(inputImages2, out2);


	//20180705
	auto output_size = out1.size();
	output_size.height  = output_size.height / 2;
	cv::resize(out1, out1, output_size);
	cv::resize(out2, out2, output_size);
	//end 2010705

	
	//显示给用户供用户选择
	cv::Mat yonghu(cv::Size(out1.cols*2,800), out2.type());
	yonghu.setTo(cv::Scalar(0, 0, 0));
	cv::Mat l_roi = yonghu(cv::Rect(0, 0, out2.cols, 800));
	cv::Mat r_roi = yonghu(cv::Rect(out2.cols, 0, out2.cols, 800));

	cv::Mat source_out1 = out1(cv::Rect(0, 0, out1.cols, 800));

	cv::Mat source_out2 = out2(cv::Rect(0, 0, out2.cols, 800));
	source_out1.copyTo(l_roi);
	source_out2.copyTo(r_roi);


	shuchuName = target;
	tuichu = false;
	
	linshi = yonghu.clone();
	cv::imshow("xuanze", linshi);
	cv::setMouseCallback("xuanze", my_mouse_callback33, (void *)&yonghu);
	while (cv::waitKey(10) == -1) {
		if (tuichu) {
			return;
		}
	}
	

	/*if (jidong) {
		if (a_mean > b_mean) {
			cv::imwrite(target, out1);
		}
		else {
			cv::imwrite(target, out2);
		}
	}
	else {
		cv::imwrite("out1.png", out1);
		cv::imwrite("out2.png", out2);
	}

	if (!no_windows) {
		cv::imshow("result1", out1);
		cv::imshow("result2", out2);
		yy = out1;
		yy2 = out2;
		cv::setMouseCallback("result1", my_mouse_callback11, (void *)&out1);
		

		
	}*/
}
