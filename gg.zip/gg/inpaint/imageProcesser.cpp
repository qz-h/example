﻿#include "imageProcesser.h"
ImageProcesser::ImageProcesser(bool no_window)
{
	this->no_window = no_window;
}


ImageProcesser::~ImageProcesser()
{
}
void ImageProcesser::setDemon(bool flag) {
	no_window = flag;
}
String ImageProcesser::cropImage(cv::Mat img_copy,cv::RotatedRect k, string image_name,int id,int mode) {
	std::ostringstream fileName;
	std::ostringstream normalSizeFileName;
	std::ostringstream normalSizeBRFileName;

	fileName << image_name << "_" << id << ".bmp";
	auto loc = k.boundingRect();
	loc.x -= 2;
	loc.y -= 2;
	loc.width += 4;
	loc.height += 4;

	if (loc.x < 0) loc.x = 0;
	if (loc.y < 0) loc.y = 0;
	if (loc.x + loc.width > img_copy.cols) loc.width = img_copy.cols - loc.x;
	if (loc.y + loc.height > img_copy.rows) loc.height = img_copy.rows - loc.y;

	auto parts = img_copy(loc);
	cv::imwrite(fileName.str(), parts);

	if (mode > 0) {
		parts = parts.clone();
		normalSizeFileName << image_name << "_BGR" << id << ".png";
		cv::resize(parts, parts, Size(64, 64));
		cv::imwrite(normalSizeFileName.str(), parts);
	}
	if(mode>1){
	auto chuli = parts.clone();
	chuli.setTo(Scalar(255, 0, 255));
	cv::bitwise_and(parts, chuli, parts);
	normalSizeBRFileName << image_name << "_BR" << id << ".png";
	cv::imwrite(normalSizeBRFileName.str(), parts);
	}
	return fileName.str();
}
void ImageProcesser::showHSV(cv::Mat hsv, cv::Mat mask, std::vector<float> & buff) {
	auto histImgS = makeHS(hsv, mask, buff);
	auto histImgV = makeHV(hsv, mask, buff);
	auto histImgSV = makeSV(hsv, mask, buff);

	auto outSize = histImgS.size();
	outSize.width *= 2;
	outSize.width += 10;
	outSize.height *= 2;
	outSize.height += 10;

	cv::Mat img_merge = Mat::zeros(outSize, CV_8UC3);
	img_merge.setTo(cv::Scalar(190, 190, 190));
	Mat outImg_left, outImg_right, outImg_below;

	outImg_left = img_merge(Rect(0, 0, histImgS.cols, histImgS.rows));
	outImg_right = img_merge(Rect(histImgS.cols + 10, 0, histImgV.cols, histImgV.rows));
	outImg_below = img_merge(Rect(0, histImgS.rows + 10, histImgSV.cols, histImgSV.rows));
	//3.将待拷贝图像拷贝到感性趣区域中
	histImgS.copyTo(outImg_left);
	histImgV.copyTo(outImg_right);
	histImgSV.copyTo(outImg_below);

	if (!no_window)
		imshow("HSV_Layout", img_merge);
}

void ImageProcesser::showMinColor(cv::Mat rgb, cv::Mat mask, std::vector<float> & buff) {
	//暂时的程序
	//4x4
	//8x8
	
	cv::Mat mask_2,mask_4,mask_8;
	cv::resize(mask, mask_2, cv::Size2d(mask.size().width/2,mask.size().height/2));
	cv::resize(mask, mask_4, cv::Size2d(mask.size().width / 4, mask.size().height / 4));
	cv::resize(mask, mask_8, cv::Size2d(mask.size().width / 8, mask.size().height / 8));

	//cv::bitwise_not(mask_2, mask_2);
	//cv::bitwise_not(mask_4, mask_4);
	//cv::bitwise_not(mask_8, mask_8);

	double mini_2, mini_4, mini_8;
	double max_2, max_4, max_8;

	/*cv::erode(mask_2, mask_2, cv::Mat(), cv::Point(-1, -1), 1);
	cv::erode(mask_4, mask_4, cv::Mat(), cv::Point(-1, -1), 1);
	cv::erode(mask_8, mask_8, cv::Mat(), cv::Point(-1, -1), 1);
*/
	if (!no_window) {
		cv::imshow("r_image_2", r_image_2);
		cv::imshow("r_image_4", r_image_4);
		cv::imshow("r_image_8", r_image_8);
	}
	cv::minMaxLoc(this->r_image_2, &mini_2, &max_2,NULL,NULL,mask_2);
	cv::minMaxLoc(r_image_4, &mini_4, &max_4, NULL, NULL, mask_4);
	cv::minMaxLoc(r_image_8, &mini_8, &max_8, NULL, NULL, mask_8);
	if (!no_window) {
		std::cout << "mini_2:" << mini_2 << std::endl;
		std::cout << "max_4:" << mini_4 << std::endl;
		std::cout << "max_8:" << mini_8 << std::endl;
	}
	buff.push_back((float)mini_2);
	buff.push_back((float)mini_4);
	buff.push_back((float)mini_8);

	//buff.push_back((float)max_2);
	//buff.push_back((float)max_4);
	//buff.push_back((float)max_8);

}
void ImageProcesser::showRGB(cv::Mat rgb, cv::Mat mask, std::vector<float> & buff) {

	auto histImgV = makeRGB(rgb, mask, 1, buff);

	if (!no_window) {
		std::vector<float>  huyo;
		auto histImgSV = makeRGB(rgb, mask, 2, huyo);
		auto histImgS = makeRGB(rgb, mask, 0, huyo);
		auto outSize = histImgS.size();
		outSize.width *= 2;
		outSize.width += 10;
		outSize.height *= 2;
		outSize.height += 10;

		cv::Mat img_merge = Mat::zeros(outSize, CV_8UC3);
		img_merge.setTo(cv::Scalar(190, 190, 190));
		Mat outImg_left, outImg_right, outImg_below;

		outImg_left = img_merge(Rect(0, 0, histImgS.cols, histImgS.rows));
		outImg_right = img_merge(Rect(histImgS.cols + 10, 0, histImgV.cols, histImgV.rows));
		outImg_below = img_merge(Rect(0, histImgS.rows + 10, histImgSV.cols, histImgSV.rows));
		//3.将待拷贝图像拷贝到感性趣区域中
		histImgS.copyTo(outImg_left);
		histImgV.copyTo(outImg_right);
		histImgSV.copyTo(outImg_below);


		imshow("RGB_Layout", img_merge);
	}
}

cv::Mat ImageProcesser::makeHV(cv::Mat hsv, cv::Mat mask, std::vector<float> & buff)
{
	// 色相を 30 分割レベルで，
	// 彩度を 32 分割レベルで量子化します
	int hbins = 10, sbins = 12;
	int histSize[] = { hbins, sbins };
	// cvtColor にあるように，色相の範囲は 0 から 179 です．
	float hranges[] = { 0, 180 };
	// 彩度の範囲は 0 （黒-灰色-白）から
	// 255 （純粋なスペクトルカラー）までです．
	float sranges[] = { 0, 256 };
	const float* ranges[] = { hranges, sranges };
	MatND hist;
	// 0 番目と 1 番目のチャンネルからヒストグラムを求めます．
	int channels[] = { 0, 2 };

	calcHist(&hsv, 1, channels, mask, // マスクは利用しません
		hist, 2, histSize, ranges,
		true, // ヒストグラムは一様です
		false);
	double maxVal = 0;
	//minMaxLoc(hist, 0, &maxVal, 0, 0);

	maxVal = cv::sum(hist)[0];

	int scale = 10;
	Mat histImg = Mat::zeros(sbins*scale, hbins * 10, CV_8UC3);

	buff.push_back(-1);
	for (int h = 0; h < hbins; h++) {
		for (int s = 0; s < sbins; s++)
		{
			float binVal = hist.at<float>(h, s);
			int intensity = cvRound(binVal * 100 / maxVal);

			buff.push_back(intensity);

			Scalar se;
			intensity = intensity * 100;
			if (intensity > 765) intensity = 765;
			if (intensity > 510)
				se = cv::Scalar(0, 0, intensity - 510);//>5%
			else if (intensity>255)
				se = cv::Scalar(0, intensity - 255, 0);//>2%
			else
				se = cv::Scalar(intensity, 0, 0);
			rectangle(histImg, Point(h*scale, s*scale),
				Point((h + 1)*scale - 1, (s + 1)*scale - 1),
				se,
				CV_FILLED);
		}
	}
	cv::putText(histImg, "H", cv::Point(hbins * 5, 10), 1, 1, cv::Scalar(255, 255, 255));

	cv::putText(histImg, "V", cv::Point(5, sbins * 5), 1, 1, cv::Scalar(255, 255, 255));
	return histImg;
}
cv::Mat ImageProcesser::makeHS(cv::Mat hsv, cv::Mat mask, std::vector<float> & buff)
{
	// 色相を 30 分割レベルで，
	// 彩度を 32 分割レベルで量子化します
	int hbins = 10, sbins = 12;
	int histSize[] = { hbins, sbins };
	// cvtColor にあるように，色相の範囲は 0 から 179 です．
	float hranges[] = { 0, 180 };
	// 彩度の範囲は 0 （黒-灰色-白）から
	// 255 （純粋なスペクトルカラー）までです．
	float sranges[] = { 0, 256 };
	const float* ranges[] = { hranges, sranges };
	MatND hist;
	// 0 番目と 1 番目のチャンネルからヒストグラムを求めます．
	int channels[] = { 0, 1 };

	calcHist(&hsv, 1, channels, mask, // マスクは利用しません
		hist, 2, histSize, ranges,
		true, // ヒストグラムは一様です
		false);
	double maxVal = 0;
	//minMaxLoc(hist, 0, &maxVal, 0, 0);

	maxVal = cv::sum(hist)[0];

	int scale = 10;
	Mat histImg = Mat::zeros(sbins*scale, hbins * 10, CV_8UC3);

	buff.push_back(-2);
	if (!no_window)
		std::cout << "H-S" << std::endl;
	for (int h = 0; h < hbins; h++) {
		for (int s = 0; s < sbins; s++)
		{
			float binVal = hist.at<float>(h, s);
			int intensity = cvRound(binVal * 100 / maxVal);
			if (!no_window)
				std::cout << intensity << ",";
			buff.push_back(intensity);
			Scalar se;
			intensity = intensity * 100;
			if (intensity > 765) intensity = 765;
			if (intensity > 510)
				se = cv::Scalar(0, 0, intensity - 510);//>5%
			else if (intensity>255)
				se = cv::Scalar(0, intensity - 255, 0);//>2%
			else
				se = cv::Scalar(intensity, 0, 0);
			rectangle(histImg, Point(h*scale, s*scale),
				Point((h + 1)*scale - 1, (s + 1)*scale - 1),
				se,
				CV_FILLED);
		}
		if (!no_window)
			std::cout << std::endl;
	}
	std::cout << "<<<<<<<<<<<<<<<<\n";
	cv::putText(histImg, "H", cv::Point(hbins * 5, 10), 1, 1, cv::Scalar(255, 255, 255));

	cv::putText(histImg, "S", cv::Point(5, sbins * 5), 1, 1, cv::Scalar(255, 255, 255));
	return histImg;
}
cv::Mat ImageProcesser::makeSV(cv::Mat hsv, cv::Mat mask, std::vector<float> & buff)
{
	// 色相を 30 分割レベルで，
	// 彩度を 32 分割レベルで量子化します
	int hbins = 12, sbins = 12;
	int histSize[] = { hbins, sbins };
	// cvtColor にあるように，色相の範囲は 0 から 179 です．
	float hranges[] = { 0, 256 };
	// 彩度の範囲は 0 （黒-灰色-白）から
	// 255 （純粋なスペクトルカラー）までです．
	float sranges[] = { 0, 256 };
	const float* ranges[] = { hranges, sranges };
	MatND hist;
	// 0 番目と 1 番目のチャンネルからヒストグラムを求めます．
	int channels[] = { 1, 2 };

	calcHist(&hsv, 1, channels, mask, // マスクは利用しません
		hist, 2, histSize, ranges,
		true, // ヒストグラムは一様です
		false);
	double maxVal = 0;
	//minMaxLoc(hist, 0, &maxVal, 0, 0);

	maxVal = cv::sum(hist)[0];

	int scale = 10;
	Mat histImg = Mat::zeros(sbins*scale, hbins * 10, CV_8UC3);

	buff.push_back(-3);
	for (int h = 0; h < hbins; h++) {
		for (int s = 0; s < sbins; s++)
		{
			float binVal = hist.at<float>(h, s);
			int intensity = cvRound(binVal * 100 / maxVal);
			buff.push_back(intensity);
			Scalar se;
			intensity = intensity * 100;
			if (intensity > 765) intensity = 765;
			if (intensity > 510)
				se = cv::Scalar(0, 0, intensity - 510);//>5%
			else if (intensity>255)
				se = cv::Scalar(0, intensity - 255, 0);//>2%
			else
				se = cv::Scalar(intensity, 0, 0);
			rectangle(histImg, Point(h*scale, s*scale),
				Point((h + 1)*scale - 1, (s + 1)*scale - 1),
				se,
				CV_FILLED);
		}
	}
	cv::putText(histImg, "S", cv::Point(hbins * 5, 10), 1, 1, cv::Scalar(255, 255, 255));

	cv::putText(histImg, "V", cv::Point(5, sbins * 5), 1, 1, cv::Scalar(255, 255, 255));
	return histImg;
}

cv::Mat ImageProcesser::makeRGB(cv::Mat rgb, cv::Mat mask, int type, std::vector<float> & buff)
{
	// 色相を 30 分割レベルで，
	// 彩度を 32 分割レベルで量子化します
	int hbins = 10, sbins = 25;
	int histSize[] = { hbins, sbins };
	// cvtColor にあるように，色相の範囲は 0 から 179 です．
	//float hranges[] = { 0, 256 };
	//float hranges[] = { 0,18,40,66,96,130,168,210,256 };
	float hranges[] = { 0,12,24,40,66,86,110,140,180,210,256 };
	// 彩度の範囲は 0 （黒-灰色-白）から
	// 255 （純粋なスペクトルカラー）までです．
	//float sranges[] = { 0, 256 };
	float sranges[] = { 0,10,20,30,40,48,56,64,72,80,88,94,102,108,116,122,130,136,144,150,162,176,194,214,234,256 };
	const float* ranges[] = { hranges, sranges };
	MatND hist;
	// 0 番目と 1 番目のチャンネルからヒストグラムを求めます．

	int channels[] = { 1, 2 };
	String msg_x, msg_y;
	if (type == 0) {
		channels[0] = 1;
		channels[1] = 2;
		msg_x = "R";
		msg_y = "G";
	}

	if (type == 1) {
		channels[0] = 0;
		channels[1] = 2;

		msg_x = "R";
		msg_y = "B";
	}

	if (type == 2) {
		channels[0] = 0;
		channels[1] = 1;
		msg_x = "G";
		msg_y = "B";
	}

	calcHist(&rgb, 1, channels, mask, // マスクは利用しません
		hist, 2, histSize, ranges,
		false, // ヒストグラムは一様です
		false);
	double maxVal = 0;
	//minMaxLoc(hist, 0, &maxVal, 0, 0);

	maxVal = cv::sum(hist)[0];

	int scale = 10;
	Mat histImg = Mat::zeros(hbins * 10, sbins*scale, CV_8UC3);

	//buff.push_back(-10 * (type + 1));
	if (!no_window)
		std::cout << msg_x << "-" << msg_y << std::endl;
	for (int h = 0; h < hbins; h++) {
		for (int s = 0; s < sbins; s++)
		{
			float binVal = hist.at<float>(h, s);
			int intensity = cvRound(binVal * 100 / maxVal);

			if (!no_window)
				std::cout << intensity << ",";

			buff.push_back(intensity);
			Scalar se;
			intensity = intensity * 100;
			if (intensity > 765) intensity = 765;
			if (intensity > 510)
				se = cv::Scalar(0, 0, intensity - 510);//>5%
			else if (intensity > 255)
				se = cv::Scalar(0, intensity - 255, 0);//>2%
			else
				se = cv::Scalar(intensity, 0, 0);

			auto p1 = Point(s*scale, h*scale);
			auto p2 = Point((s + 1)*scale - 1, (h + 1)*scale - 1);


			rectangle(histImg, p1,
				p2,
				se,
				CV_FILLED);
		}
		if (!no_window)
			std::cout << std::endl;
	}

	//这里做个4合一的处理
	buff.push_back(-1);
	for (int h = 0; h < hbins-1; h+=2) {
		for (int s = 0; s < sbins-1; s+=2)
		{
			float binVal = hist.at<float>(h, s) + hist.at<float>(h, s+1) + hist.at<float>(h+1, s) + hist.at<float>(h+1, s + 1);
			int intensity = cvRound(binVal * 100 / maxVal);
			buff.push_back(intensity);
		}
	}
	buff.push_back(-1);

	//std::cout << ">>>>>>>>>" << std::endl;
	cv::putText(histImg, msg_x, cv::Point(histImg.cols / 2 - 5, 10), 1, 1, cv::Scalar(255, 255, 255));

	cv::putText(histImg, msg_y, cv::Point(10, histImg.rows / 2 - 5), 1, 1, cv::Scalar(255, 255, 255));

	/*if (type == 1) {
	cv::line(histImg, cv::Point(0, 40), cv::Point(80, 120), cv::Scalar(200, 200, 200));
	cv::line(histImg, cv::Point(160, 120), cv::Point(80, 120), cv::Scalar(200, 200, 200));
	}*/
	return histImg;
}
std::vector<float> ImageProcesser::getDestcriptor(bool is_hsv, std::vector<Point> c, String title) {
	/*
	target:原始图像
	c:边界信息
	rect 外接矩形

	这里所说的特征量是4*4*4区间
	*/
	int binWidth = 20;
	int RL_Blank = 30;
	int relarge = 1;
	std::vector<float> result;
	Mat mask = Mat::zeros(HSV_planes[0].size(), CV_8UC1);

	vector<vector<Point> > contours_subset;
	contours_subset.push_back(c);
	drawContours(mask, contours_subset, -1, Scalar(255), -1);

	int hbins = 10, sbins = 10, vbins = 10;
	int histSizeH[] = { hbins };
	int histSizeS[] = { sbins };
	int histSizeV[] = { vbins };

	float hranges[] = { 0, 180 };
	if (is_hsv == false) {
		hranges[1] = 256;
	}
	float sranges[] = { 0, 256 };
	float vranges[] = { 0, 256 };
	const float* histRangeH = { hranges };
	const float* histRangeS = { sranges };
	const float* histRangeV = { vranges };
	MatND hist;

	bool uniform = true; bool accumulate = false;

	Mat h_hist, s_hist, v_hist;

	if (is_hsv) {
		if (!no_window)
			printf("HSV\n");
		calcHist(&HSV_planes[2], 1, 0, mask, v_hist, 1, histSizeV, &histRangeV, uniform, accumulate);
		calcHist(&HSV_planes[1], 1, 0, mask, s_hist, 1, histSizeS, &histRangeS, uniform, accumulate);
		calcHist(&HSV_planes[0], 1, 0, mask, h_hist, 1, histSizeH, &histRangeH, uniform, accumulate);

	}
	else {
		if (!no_window)
			printf("BGR\n");
		calcHist(&BGR_planes[2], 1, 0, mask, v_hist, 1, histSizeV, &histRangeV, uniform, accumulate);
		calcHist(&BGR_planes[1], 1, 0, mask, s_hist, 1, histSizeS, &histRangeS, uniform, accumulate);
		calcHist(&BGR_planes[0], 1, 0, mask, h_hist, 1, histSizeH, &histRangeH, uniform, accumulate);
	}

	int image_width = hbins * binWidth + RL_Blank * 2;
	Mat histImg = Mat::zeros(230, image_width, CV_8UC3);
	histImg.setTo(Scalar::all(200));


	std::vector<String> x_labels{ "0","85","170","255" };
	std::vector<String> y_labels{ "0","50%","100%" };
	make_x(histImg, cv::Point(RL_Blank, 210), cv::Point(image_width - RL_Blank, 210), x_labels);
	make_y(histImg, cv::Point(RL_Blank, 210), cv::Point(RL_Blank, 10), y_labels);
	if (is_hsv) {
		std::ostringstream msg1;
		msg1 << "----H";
		cv::putText(histImg, msg1.str(), cv::Point(histImg.size().width - 80, 20), 1, 1, cv::Scalar(255, 0, 0));
		std::ostringstream msg2;

		msg2 << "----S";
		cv::putText(histImg, msg2.str(), cv::Point(histImg.size().width - 80, 35), 1, 1, cv::Scalar(0, 255, 0));
		std::ostringstream msg3;

		msg3 << "----V";
		cv::putText(histImg, msg3.str(), cv::Point(histImg.size().width - 80, 50), 1, 1, cv::Scalar(0, 0, 255));


	
	}
	else {
		std::ostringstream msg1;
		msg1 << "----B";
		cv::putText(histImg, msg1.str(), cv::Point(histImg.size().width - 80, 20), 1, 1, cv::Scalar(255, 0, 0));
		std::ostringstream msg2;

		msg2 << "----G";
		cv::putText(histImg, msg2.str(), cv::Point(histImg.size().width - 80, 35), 1, 1, cv::Scalar(0, 255, 0));
		std::ostringstream msg3;

		msg3 << "----R";
		cv::putText(histImg, msg3.str(), cv::Point(histImg.size().width - 80, 50), 1, 1, cv::Scalar(0, 0, 255));
		//msg.clear();
	}


	Point lastPoint = Point(RL_Blank, 210);
	double maxVal = 0;
	maxVal = tSum(h_hist, hbins) / relarge;



	std::vector<int> pan;
	for (int i = 0; i < hbins; i++)
	{
		int binVal = h_hist.at<float>(i);

		int intensity = cvRound(binVal * 200 / maxVal);
		if (pan.size()<4) {
			pan.push_back(cvRound(1.0*binVal / maxVal * 100 / relarge));
		}

		if (!no_window)
			printf("%d/%d\t", binVal, cvRound(1.0*binVal / maxVal * 100));

		Point nowPoint = Point(lastPoint.x + binWidth, 210 - intensity);
		/*line(histImg, lastPoint,
		nowPoint,
		Scalar(255,0,0)
		);*/


		cv::rectangle(histImg, cv::Rect(lastPoint.x + binWidth * 0, 210 - intensity, binWidth / 3, intensity), Scalar(255, 0, 0), -1);


		lastPoint = Point(nowPoint.x, nowPoint.y);;
	}
	if (is_hsv) {
		int gokei = 0;
		for (auto iter = pan.begin(); iter != pan.end(); iter++) {
			gokei += *iter;
		}
		if (!no_window)
			printf("good bad h:%d\n", gokei);
	}
	if (!no_window)
		printf("\n");
	maxVal = tSum(s_hist, sbins) / relarge;
	lastPoint = Point(RL_Blank, 210);
	for (int i = 0; i < sbins; i++)
	{
		int binVal = s_hist.at<float>(i);
		//binVal = binVal * 2;

		int intensity = cvRound(binVal * 200 / maxVal);

		if (!no_window)
			printf("%d/%d\t", binVal, cvRound(1.0*binVal / maxVal * 100));
		Point nowPoint = Point(lastPoint.x + binWidth, 210 - intensity);
		/*line(histImg, lastPoint,
		nowPoint,
		Scalar(0,255, 0)
		);*/
		cv::rectangle(histImg, cv::Rect(lastPoint.x + 1 * binWidth / 3, 210 - intensity, binWidth / 3, intensity), Scalar(0, 255, 0), -1);
		lastPoint = Point(nowPoint.x, nowPoint.y);;
	}
	if (!no_window)
		printf("\n");
	maxVal = tSum(v_hist, vbins) / relarge;

	pan.clear();
	lastPoint = Point(RL_Blank, 210);
	for (int i = 0; i < vbins; i++)
	{
		int binVal = v_hist.at<float>(i);
		//binVal = binVal * 2;

		int intensity = cvRound(binVal * 200 / maxVal);

		if (!no_window)
			printf("%d/%d\t", binVal, cvRound(1.0*binVal / maxVal * 100));

		if (pan.size()<20) {
			pan.push_back(cvRound(1.0*binVal / maxVal * 100));
		}


		Point nowPoint = Point(lastPoint.x + binWidth, 210 - intensity);
		/*line(histImg, lastPoint,
		nowPoint,
		Scalar(0,0,255)
		);*/
		cv::rectangle(histImg, cv::Rect(lastPoint.x + 2 * binWidth / 3, 210 - intensity, binWidth / 3, intensity), Scalar(0, 0, 255), -1);
		lastPoint = Point(nowPoint.x, nowPoint.y);;
	}

	if (is_hsv) {
		int gokei = 0;
		for (auto iter = pan.begin(); iter != pan.end(); iter++) {
			gokei += *iter;
		}

		if (!no_window)
			printf("good bad v:%d\n", gokei);
	}

	if (!no_window)
		printf("\n");
	if (!no_window) {
		namedWindow(title, 1);
		imshow(title, histImg);
	}
	return result;
}

void ImageProcesser::make_x(cv::Mat &x, cv::Point p1, cv::Point p2, std::vector<String> label) {
	cv::line(x, p1, p2, cv::Scalar(0, 0, 0), 2);
	float step = (p2.x - p1.x) / (label.size() - 1);
	cv::Point loc = p1;
	loc.y += 15;

	for (auto iter = label.begin(); iter != label.end(); iter++) {

		std::ostringstream msg1;

		msg1 << *iter;
		cv::putText(x, msg1.str(), loc, 1, 1, cv::Scalar(255, 0, 0));
		msg1.clear();
		loc.x += step;
	}
}

void ImageProcesser::make_y(cv::Mat &x, cv::Point p1, cv::Point p2, std::vector<String> label) {
	cv::line(x, p1, p2, cv::Scalar(0, 0, 0), 2);
	float step = (p1.y - p2.y) / (label.size() - 1);
	cv::Point loc = p1;
	loc.x -= 29;

	for (auto iter = label.begin(); iter != label.end(); iter++) {

		std::ostringstream msg1;

		msg1 << *iter;
		cv::putText(x, msg1.str(), loc, 1, 1, cv::Scalar(255, 0, 0));
		msg1.clear();
		loc.y -= step;
	}
}

std::vector<float> ImageProcesser::getDistancefeature(std::vector<Point> c) {
	auto n1 = getDistancefeature(c, true);
	auto n2 = getDistancefeature(c, false);
	for (int i = 0; i < n2.size(); i++) {
		n1.push_back(n2[i]);
	}


	//paixu
	int max_id = 0;
	float max_v = 0;
	for (int i = 0; i < n1.size(); i++) {
		if (n1[i]>max_v) {

			max_v = n1[i];
			max_id = i;
		}
	}
	max_id = 0;
	std::vector<float> n3;
	ofstream outputfile = ofstream("banjing.txt");
	for (int i = max_id; i < n1.size(); i++) {
		n3.push_back(n1[i]);
		outputfile << n1[i] << std::endl;

	}
	outputfile.close();
	for (int i = 0; i < max_id; i++) {
		n3.push_back(n1[i]);
	}


	std::vector<float> tt;
	for (int i = 6; i < n3.size(); i++) {
		tt.push_back(50 + 2.0*(n3[i] + 0 * n3[i - 1] + n3[i - 1] - n3[i - 5] - 0 * n3[i - 4] - n3[i - 6]));
	}

	show_distance(n3, "real");
	show_distance(tt, "cha");

	return n1;
}
std::vector<float> ImageProcesser::getDistancefeature(std::vector<Point> c, bool dir) {
	/*
	target:原始图像
	c:边界信息
	rect 外接矩形

	这里所说的特征量是4*4*4区间

	*/

	//auto rb_mean = getRB_Mean(c);

	auto show_temp_image = rgb_image.clone();

	if (!no_window)
		printf("Start getdestriptor3\n");
	std::vector<float> resultDes;
	int stepNum = 1;

	std::vector<float> target_xielv_list;
	if (dir == true) {
		for (int i = -89; i < 90; i += stepNum) {
			//printf("%d,",i);
			target_xielv_list.push_back(tan(3.1415926*i / 180));
		}
	}
	else {
		for (int i = 91; i < 270; i += stepNum) {
			//printf("%d,",i);
			target_xielv_list.push_back(tan(3.1415926*i / 180));
		}
	}
	std::cout << "Firsrt Value=" << target_xielv_list[0] << std::endl;
	std::cout << "Last Value=" << target_xielv_list[target_xielv_list.size() - 1];

	//printf("\n");
	auto box = findEllipse(c);
	cv::Point centor_loc(0, 0);

	Point2f vtx[4];
	box.points(vtx);

	for (int j = 0; j < 4; j += 2) {
		centor_loc.x += vtx[j].x;
		centor_loc.y += vtx[j].y;
	}
	centor_loc.x = centor_loc.x / 2;
	centor_loc.y = centor_loc.y / 2;


	double area = contourArea(c);
	double perimeter = cv::arcLength(c, true);
	std::ostringstream msg1;
	std::ostringstream msg2;
	std::ostringstream msg3;

	std::ostringstream msg4;
	msg1 << "Aera=" << area;
	msg2 << "Perimeter=" << perimeter;
	msg3 << "A/P=" << area / perimeter;
	//msg4 << "rb_mean:" << rb_mean;
	msg4 << "rb_mean:" << "not use";
	if (!no_window)
		printf("Center:(%d,%d)\n", centor_loc.x, centor_loc.y);
#if(0)
	cv::circle(show_temp_image, centor_loc, 2, cv::Scalar(0, 0, 255), 2);
	cv::putText(show_temp_image, msg1.str(), cv::Point(centor_loc.x + 40, centor_loc.y - 15), 1, 1, cv::Scalar(0, 255, 0));
	cv::putText(show_temp_image, msg2.str(), cv::Point(centor_loc.x + 40, centor_loc.y), 1, 1, cv::Scalar(0, 255, 0));
	cv::putText(show_temp_image, msg3.str(), cv::Point(centor_loc.x + 40, centor_loc.y + 15), 1, 1, cv::Scalar(0, 255, 0));
	cv::putText(show_temp_image, msg4.str(), cv::Point(centor_loc.x + 40, centor_loc.y + 30), 1, 1, cv::Scalar(0, 255, 0));
#endif




	std::vector<float> xielv_list;
	std::vector<Point> c_id_list;
	//printf("*****01 start\n");

	for (int i = 0; i < c.size(); i++) {
		float x_cha = c[i].x; x_cha -= centor_loc.x;
		float y_cha = c[i].y; y_cha -= centor_loc.y;
		float xielv;
		if ((dir == true && x_cha > 0)) {

			xielv = y_cha / x_cha;

			xielv_list.push_back(xielv);
			c_id_list.push_back(c[i]);
		}
		if ((dir == false && x_cha < 0)) {

			xielv = y_cha / x_cha;

			xielv_list.push_back(xielv);
			c_id_list.push_back(c[i]);
		}
	}


	std::vector<Point> c_id_list2;
	for (int i = 0; i < target_xielv_list.size(); i++) {
		float target = target_xielv_list[i];
		//printf("target:%f 's location=", target);
		float gosa = INT_MAX;
		int loc = 0;
		for (int j = 0; j < xielv_list.size(); j++) {
			float a = abs(xielv_list[j] - target);
			if (gosa > a) {
				gosa = a;
				loc = j;
			}
		}
		c_id_list2.push_back(c_id_list[loc]);

		//printf("[@%d] gosa=%f\n", loc,gosa);

	}
	for (int j = 0; j < c_id_list2.size(); j++) {

		/*if (j == 0) {
		cv::circle(show_temp_image, c_id_list2[j], 2, cv::Scalar(0, 0, 255), 2);
		}
		if (j == 20) {
		cv::circle(show_temp_image, c_id_list2[j], 2, cv::Scalar(255, 0, 0), 2);
		}*/
		float cha_y = c_id_list2[j].y; cha_y -= centor_loc.y;
		float cha_x = c_id_list2[j].x; cha_x -= centor_loc.x;

		float distance = cha_x * cha_x + cha_y * cha_y;
		distance = sqrt(distance);
		printf("(%d,%d)-(%d,%d)=%f\n", c_id_list2[j].x, c_id_list2[j].y, centor_loc.x, centor_loc.y, distance);
		resultDes.push_back(distance);
	}
	if (!no_window)
		if (dir)
			cv::imshow("Result", show_temp_image);
		else
			cv::imshow("Result", show_temp_image);
	return resultDes;
}
void ImageProcesser::show_distance(std::vector<float> resultDes, string title) {
	for (int i = 6; i < 30; i++) {
		hasOcao(resultDes, 6, i);
	}

	int RL_Blank = 30;
	int stepNum = 1;
	int image_width = 360 + RL_Blank * 2;
	Mat histImg = Mat::zeros(230, image_width, CV_8UC3);
	histImg.setTo(Scalar::all(200));

	//line(histImg, Point(5, 210),
	//	Point(image_width - 5, 210),
	//	Scalar(0, 0, 0),
	//	2
	//);

	std::vector<String> x_labels{ "0","60","120","180","240","300","360" };
	std::vector<String> y_labels{ "0","25","50","75" ,"100" };
	make_x(histImg, cv::Point(RL_Blank, 210), cv::Point(image_width - RL_Blank, 210), x_labels);
	make_y(histImg, cv::Point(RL_Blank, 210), cv::Point(RL_Blank, 10), y_labels);

	//printf("\n");
	Point lastPoint = Point(RL_Blank, 210);
	double maxVal = 0;
	//maxVal = tMax(resultDes);
	maxVal = 100;
	for (int i = 0; i < resultDes.size(); i++)
	{
		if (!no_window)
			printf("%f,%d\t", resultDes[i], i);
		int intensity = cvRound(resultDes[i] * 200 / maxVal);
		Point nowPoint = Point(lastPoint.x + stepNum, 210 - intensity);
		line(histImg, lastPoint,
			nowPoint,
			Scalar(255, 0, 0)
		);
		lastPoint = Point(nowPoint.x, nowPoint.y);;
	}
	/*line(histImg, Point(0,110),
	Point(500, 110),
	Scalar(0, 0, 255)
	);*/
	if (!no_window) {
		namedWindow("Distance-" + title, 1);
		imshow("Distance-" + title, histImg);
	}
}
bool ImageProcesser::hasOcao(std::vector<float> resultDes, float xia, int jian) {
	std::vector<float> tmp;
	for (auto iter = resultDes.begin(); iter != resultDes.end(); iter++) {
		tmp.push_back(*iter);
	}
	if (jian > resultDes.size()) {
		jian = resultDes.size();
	}
	for (int i = 0; i < jian; i++) {
		tmp.push_back(resultDes[i]);
	}


	for (int i = 0; i < tmp.size() - jian - 1; i++) {
		int middel_loc = i + jian / 2;
		if (tmp[i]>10 && tmp[middel_loc]>10 && tmp[i + jian]>10) {


			if ((tmp[middel_loc] + xia) < tmp[i] && (tmp[middel_loc] + xia) < tmp[i + jian]) {
				

				if (!no_window)
					printf("*%f,%f,%f\t", tmp[i], tmp[middel_loc], tmp[i + jian]);
				i = tmp.size();
			}
			else {
				//printf("%f,%f,%f\t", tmp[i], tmp[middel_loc], tmp[i + jian]);
			}
		}
	}
	return 0;
}


#if 0
float imageProcesser::getRB_Mean(std::vector<Point> c) {
	/*
	c:边界信息
	*/

	cv::Mat tempImg = R_B_sub_u8.clone();

	Mat mask = Mat::zeros(HSV_planes[0].size(), CV_8UC1);


	vector<vector<Point> > contours_subset;
	contours_subset.push_back(c);
	drawContours(mask, contours_subset, -1, Scalar(255), -1);
	//cv::imshow("mask", mask);
	/*showHSV(hsv_image, mask);
	showRGB( img_copy, mask);*/
	vector<vector<Point> > contours_subset2;
	contours_subset2.push_back(c);
	cv::drawContours(tempImg, contours_subset2, -1, Scalar(255), 2);

	int meanresult = cv::mean(R_B_sub_u8, mask)[0];
	if (!no_window)
		imshow("R_B_sub_u8", tempImg);
	return meanresult;
}
#endif
float ImageProcesser::tSum(cv::Mat & t, int n) {
	float sum = 0;
	for (int i = 0; i < n; i++)
	{
		sum += t.at<float>(i);
	}
	return sum;
}

float ImageProcesser::tMax(std::vector<float> t) {
	float sum = -99999;
	for (int i = 0; i < t.size(); i++)
	{
		if (sum < t[i]) {
			sum = t[i];
		}
	}
	return sum;
}
void ImageProcesser::ImageProcesser::init(cv::Mat img) {
	rgb_image = img.clone();

	vector<Mat> channels(3);
	// split img:
	split(img, channels);//gbr
	//zhi yao r
	r_image_2 = channels[2].clone();
	r_image_4 = channels[2].clone();
	r_image_8 = channels[2].clone();

	

	auto size_2 = img.size();
	size_2.width = size_2.width / 2;
	size_2.height = size_2.height / 2;

	auto size_4 = img.size();
	size_4.width = size_2.width / 2;
	size_4.height = size_2.height / 2;

	auto size_8 = img.size();
	size_8.width = size_4.width / 2;
	size_8.height = size_4.height / 2;


	cv::resize(r_image_2, r_image_2, size_2);
	cv::resize(r_image_4, r_image_4, size_4);
	cv::resize(r_image_8, r_image_8, size_8);

	cv::cvtColor(img, hsv_image, CV_BGR2HSV);
	split(img, BGR_planes);
	split(hsv_image, HSV_planes);
}


cv::Scalar ImageProcesser::get_mean_color(std::vector<Point> c) {
	Mat mask = Mat::zeros(HSV_planes[0].size(), CV_8UC1);

	vector<vector<Point> > contours_subset;
	contours_subset.push_back(c);
	drawContours(mask, contours_subset, -1, Scalar(255), -1);

	return cv::mean(this->rgb_image, mask);
}
std::vector<float> ImageProcesser::getALLDestcriptors(std::vector<Point> c) {
	std::vector<float> reuslt;
	double area = contourArea(c);
	double perimeter = cv::arcLength(c, true);
	//auto box = findEllipse(c);
	reuslt.push_back((float)area);
	reuslt.push_back((float)perimeter);

#if USE_DISTANCE
	//测试
	//getHSVFeature(c, "HSV_Histgram");
	//getRGBFeature(c, "BGR_Histgram");
	//getDistancefeature(c);
#endif
	
	Mat mask = Mat::zeros(HSV_planes[0].size(), CV_8UC1);

	vector<vector<Point> > contours_subset;
	contours_subset.push_back(c);
	drawContours(mask, contours_subset, -1, Scalar(255), -1);

	showRGB(this->rgb_image, mask, reuslt);

	//showMinColor(this->rgb_image, mask, reuslt);

	return reuslt;
}
RotatedRect ImageProcesser::findEllipse(std::vector<Point> c) {
	Mat inputpoints;
	Mat(c).convertTo(inputpoints, CV_32F);

	//RotatedRect box = minAreaRect(inputpoints);    //楕円フィッティング
	RotatedRect box1 = fitEllipse(inputpoints);    //最小矩形(回転を考慮)算出

	return box1;
}