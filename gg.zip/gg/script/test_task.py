import os
from subprocess import call
import subprocess
feature_path='''hou2_result.csv'''
model_path='''C:/Users\D\Documents\MobaXterm\home\work\Visual_Studio_2015\Projects\inpaint\Release/tress.dat'''
exe_path='''C:/Users\D\Documents\MobaXterm\home\work\Visual_Studio_2015\Projects\inpaint\Release\inpaint.exe'''

def test(feature_path,model_path):
    para=[exe_path, '1','code_test', feature_path, model_path]

    print(' '.join(para))
    p = subprocess.Popen(para, shell=True, stdout=subprocess.PIPE, stderr=subprocess.STDOUT)
    print('*************************')
    for line in p.stdout.readlines():
        print(line)
    print('+++++++++++++++++++++++++')
    retval = p.wait()

# test(feature_path, model_path)
#
# feature_path='''hou3_result.csv'''
# model_path='''C:/Users\D\Documents\MobaXterm\home\work\Visual_Studio_2015\Projects\inpaint\Release/tress.dat'''
# test(feature_path, model_path)

feature_path='''09_val_hou2_result.csv'''
model_path='''C:/Users\D\Documents\MobaXterm\home\work\Visual_Studio_2015\Projects\inpaint\Release/tress.dat'''
test(feature_path, model_path)