import xml.etree.ElementTree as ET
import time

import requests
time_machine=2.0


def restart(t=3):
    url = "http://127.0.0.1:8989/restart"
    params = { }
    s = requests.session()
    r = s.post(url, data=params)
    XmlData=r.text.encode("utf-8")
    #print(XmlData)
    root = ET.fromstring(XmlData)
    time.sleep(t*time_machine)
    return root[0].text

def send_cmd(cmd,t=2):
    url = "http://127.0.0.1:8989/cmd-call"
    params = {"cmd":cmd }
    s = requests.session()
    r = s.post(url, data=params)
    XmlData=r.text.encode("utf-8")
    #print(XmlData)
    root = ET.fromstring(XmlData)
    time.sleep(t*time_machine)
    return root[0].text

class city_loader:
    def __init__(self,url):
        self.url=url
        self.max_page_num = 20
        self.today_filter = True

    def set_max_page(self,max_page_num):
        self.max_page_num=max_page_num


    def run(self):
        d1='Eval_Data(go_to,%s,5)'%(self.url)
        save_command='Kvs_Add(%s,Eval_Data(find_ceng,div@class~=invest-table,html_all))'%(self.url)
        print(send_cmd(d1), 4)
        print(send_cmd(save_command), 1)



time_machine=2
for i in range(346,347,1):
    #url='https://www.yidai.com/invest/?post_type=house&page=%s'%(i)
    url='https://www.yidai.com/invest/index.html?post_type=car&page=%s'%(i)
    print('Start to load: %s'%(url))
    city_reader=city_loader(url)
    city_reader.set_max_page(30)
    city_reader.run()