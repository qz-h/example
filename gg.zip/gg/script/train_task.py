import os
from subprocess import call
import subprocess
target_folder='''D:/yumi/hebi180705/hebi180705/org/train'''
output_folder='''D:/yumi/hebi180705/hebi180705/rgb/train'''
exe_path='''C:/Users\D\Documents\MobaXterm\home\work\Visual_Studio_2015\Projects\inpaint\Release\inpaint.exe'''
class Config:
    def __init__(self,max_depth, mini_sample_count, num_val, tress_num, weight):
        self.max_depth = max_depth
        self.mini_sample_count = mini_sample_count
        self.num_val = num_val
        self.tress_num = tress_num
        self.weight = weight
    def print(self):
        print('max_depth={0}\t'.format(self.max_depth))
        print('mini_sample_count={0}\t'.format(self.mini_sample_count))
        print('num_val={0}\t'.format(self.num_val))
        print('tress_num={0}\t'.format(self.tress_num))
        print('weight={0}\t'.format(self.weight))
def train(config ,path, algrithm='tree'):
    config.print()
    para=[exe_path, '1','%s_train'%(algrithm), path]
    para.append(str(config.max_depth))
    para.append(str(config.mini_sample_count))
    para.append(str(config.num_val))
    para.append(str(config.tress_num))
    para.append(str(config.weight))

    print(' '.join(para))
    p = subprocess.Popen(para, shell=True, stdout=subprocess.PIPE, stderr=subprocess.STDOUT)
    print('*************************')
    for line in p.stdout.readlines():
        print(line)
    print('+++++++++++++++++++++++++')
    retval = p.wait()


#config=Config(14,250,25,10,3)
#train(config, 'C:/Users\D\Documents\MobaXterm\home\work\Visual_Studio_2015\Projects\inpaint\script/qian2hou2_result.csv')

config=Config(0,0,0,0,1.3)
train(config, 'C:/Users\D\Documents\MobaXterm\home\work\Visual_Studio_2015\Projects\inpaint\script/qian2hou2_result.csv',"svm")


if 0:
    for d in range(8,20,3):
        #4*5*3
        for sam in range(15,41,5):
            for t in range(10,26,5):
                if sam>d:
                    config = Config(d, 250,sam, t, 3)
                    train(config,
                          'C:/Users\D\Documents\MobaXterm\home\work\Visual_Studio_2015\Projects\inpaint\script/qian2hou2_result.csv')