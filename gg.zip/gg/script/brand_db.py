# coding: utf-8
import xml.etree.ElementTree as ET
import time

import requests
time_machine=1.0

def send_cmd(cmd,t=2):
    url = "http://127.0.0.1:8989/cmd-call"
    params = {"cmd":cmd }
    s = requests.session()
    r = s.post(url, data=params)
    XmlData=r.text.encode("utf-8")
    #print(XmlData)
    root = ET.fromstring(XmlData)
    time.sleep(t*time_machine)
    return root[0].text


# for i in range(1,28,1):
#     c1='Eval_Data(click_by_ceng,table@class=btn_tbl;td@all;a@all,%s,click)'%(i)
#     c2='Eval_Data(find_ceng,ul@class=brand_list;li@all;a@all,value<space>text_all)'
#     c3='Eval_Data(click_by_ceng,input@value=戻る,2,click)'
#     send_cmd(c1,3)
#     print(send_cmd(c2,3))
#     send_cmd(c3, 3)
# print('finish')

# zong=[]
# b1='Eval_Data(find_ceng,div@id=cat_list_wrap;a@all,value<space>text_only)'
# result=send_cmd(b1,3).split('%%|')
# for k in result:
#     nn=k.split('<space>')
#     print(nn)
#     hao=nn[0]
#     zhi=nn[1]
#
#     try:
#         b2 = 'Eval_Data(click_by_ceng,div@id=cat_list_wrap;a@value=%s,1,click)' % (hao)
#         send_cmd(b2, 4)
#         b3 = 'Eval_Data(find_ceng,ul@class=cate_list;a@all,value<space>text_only)'
#
#         mm = send_cmd(b3, 1).split('%%|')
#         for t in mm:
#             vv = t.split('<space>')
#             zong.append('%s\t%s\t%s\t%s' % (zhi, hao, vv[1], vv[0]))
#
#         b4 = 'Eval_Data(click_by_ceng,input@value=戻る,2,click)'
#         send_cmd(b4, 10)
#     except:
#         print('error one time')
#         zong.append('%s\t%s\t%s\t%s' % (zhi, hao, '', ''))
#         b5='Eval_Data(click_by_ceng,a@class~=popup_category,1,click)'
#         send_cmd(b5, 10)
#
# print('>>>>>>>>>>>>>>')
# print('%%|'.join(zong))






zong=[]
b1='52<space>バッグ・カバン<space>2106%%|97<space>インナー・ルームウェア<space>2110%%|141<space>アウター・ジャケット<space>2203%%|212<space>その他ファッション<space>2213%%|210<space>スーツ<space>2219%%|211<space>セットアップ<space>2220%%|299<space>メイク小物<space>2304%%|327<space>香水・フレグランス<space>2305%%|326<space>バスグッズ<space>2312%%|432<space>ライフスタイルその他<space>2413%%|289<space>キッズ・ベビー・マタニティその他<space>2504%%|270<space>キッズバッグ・財布<space>2507%%|274<space>おしゃぶり・授乳・離乳食グッズ<space>2508%%|485<space>スポーツその他<space>2610%%|96<space>スマホケース・テックアクセサリー<space>3172%%|192<space>スマホケース・テックアクセサリー<space>3416%%|271<space>ベビーカー<space>3783%%|273<space>抱っこ紐・スリング・ベビーキャリア<space>3784%%|275<space>赤ちゃん用スキンケア<space>3786%%|272<space>チャイルドシート(ベビー/ジュニア)<space>3789%%|269<space>マザーズバッグ<space>3862'
result=b1.split('%%|')
for k in result:
    nn=k.split('<space>')
    print(nn)
    hao=nn[2]
    zhi=nn[1]
    xu = nn[0]

    try:
        b2 = 'Eval_Data(click_by_ceng,div@id=cat_list_wrap;a@value=%s,1,click)' % (hao)
        send_cmd(b2, 4)
        b3 = 'Eval_Data(find_ceng,ul@class=cate_list;a@all,value<space>text_only)'

        mm = send_cmd(b3, 1).split('%%|')
        for t in mm:
            vv = t.split('<space>')
            zong.append('%s\t%s\t%s\t%s\t%s' % (xu,zhi, hao, vv[1], vv[0]))

        b4 = 'Eval_Data(click_by_ceng,input@value=戻る,2,click)'
        send_cmd(b4, 10)
    except:
        print('error one time')
        zong.append('%s\t%s\t%s\t%s\t%s' % (xu,zhi, hao, '', ''))
        b5='Eval_Data(click_by_ceng,a@class~=popup_category,1,click)'
        send_cmd(b5, 10)

print('>>>>>>>>>>>>>>')
print('%%|'.join(zong))