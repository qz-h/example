import sqlite3
from contextlib import closing
from bs4 import BeautifulSoup
import copy
import json
import codecs
import codecs
dbname = 'C:/Users/D/Documents/shopCrawler/dat/kvs.db'
def find_cost_money(a,jiage):
    bili=-1
    a=a.replace(',','')

    if a == '無':
        bili = 0
    elif a == '-':
        bili = 0
    elif 'ヶ月' in a:
        a = a.replace('ヶ月', '')
        bili = float(a)
    elif a.endswith('万円'):
        a = a.replace('万円', '')
        bili = float(a) * 10000 /jiage
    elif a.endswith('円'):
        a = a.replace('円', '')
        bili = float(a) / jiage

    return bili

def tranform(results):
    shuchu=[]
    for result in results:
        if '築年数/階数' in result:
            year_kai=result['築年数/階数']
            year_kai=year_kai.replace(' / ','/')
            year_kai = year_kai.replace('年', '')
            year_kai = year_kai.replace('新築', '0')
            year_kai = year_kai.replace('階建', '')
            temp=year_kai.split('/')
            result['constructed_year']=temp[0]
            result['constructed_kai'] = temp[1]

        try:
            result['floar'] = int(result['floar'].replace('階', ''))
        except:
            result['floar']=-1
        result['qu'] = result['所在地'][3:5]
        # if '豊島' not in result['qu']:
        #     continue
        result['price']=find_cost_money(result['price'],1)
        result['kyoueki'] = find_cost_money(result['kyoueki'],1)
        result['space'] = result['space'].replace('m²', '')
        if  result['layout']=='ワンルーム':
            result['layout']=0
        elif  result['layout']=='1K':
            result['layout']=1
        else:
            result['layout'] = 2

        #敷/礼/保証/敷引・償却
        chengben=result['cost'].split('/')
        a = find_cost_money(chengben[0],result['price'])
        b = find_cost_money(chengben[1],result['price'])
        result['sikikin']=a
        result['reikin']=b

        result['ID'] = result['datail'].split('/')[-2]

        eki_Options=result['交通'].split('\n')
        #print(eki_Options)
        for eki_Option in eki_Options:
            eki_Option=eki_Option.replace('　',' ')
            eki_Option_List=eki_Option.split(' ')
            if len(eki_Option_List) < 2:
                eki_Option_List = eki_Option.split('駅')
                if len(eki_Option_List) < 2:
                    eki_Option_List.append('9999')

            result_copy=copy.copy(result)
            #result_copy['交通']=eki_Option
            del result_copy['交通']
            try:
                target_eki=['池袋駅','大塚駅','要町駅','西巣鴨駅','北池袋駅','新大塚駅']
                result_copy['eki_name'] = eki_Option_List[-2]
                # if result_copy['eki_name'] not in target_eki:
                #     continue
                result_copy['eki_distance'] = int(eki_Option_List[-1].replace('徒歩','').replace('分',''))
                shuchu.append(result_copy)
            except:
                pass
    return shuchu

result_all=[]
with closing(sqlite3.connect(dbname)) as conn:
    c = conn.cursor()

    select_sql = 'select * from dat'
    for row in c.execute(select_sql):
        base_url=row[1]
        html=row[2]
        timestamp=row[4]
        if len(html)==0:
            continue
        #print (html)


        base_info={}
        base_info['timestamp']=timestamp
        soup=BeautifulSoup(html,"html.parser")
        try:
            bukkenSpecs=soup.find_all("div", attrs={"class": "item"})
            for bukken in bukkenSpecs:
                spec_items = bukken.find_all("a")

                daikuan_url=spec_items[1].attrs['href']
                daikuan_title = spec_items[1].attrs['title']
                zhuantai=spec_items[2].text.strip()
                #print([zhuantai,daikuan_url,daikuan_title])

                test_item=bukken.find_all("li")
                jine = test_item[1].text.strip()
                li_lv=test_item[2].text.strip()
                shijian = test_item[3].text.strip()
                #print(jine)

                result_all.append([zhuantai,daikuan_url,daikuan_title,jine,li_lv,shijian])

        except:
            pass



import csv

with codecs.open('output_new.csv', 'w','utf-8') as f:
    writer = csv.writer(f, lineterminator='\n') # 改行コード（\n）を指定しておく
    writer.writerows(result_all) # 2次元配列も書き込める