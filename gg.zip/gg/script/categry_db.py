# coding: utf-8
import xml.etree.ElementTree as ET
import time

import requests
import copy
time_machine=1.0

home_categry=['レディースファッション','メンズファッション','ベビー・キッズ','ビューティー','ライフスタイル','スポーツ']



def send_cmd(cmd,t=2):
    url = "http://127.0.0.1:8989/cmd-call"
    params = {"cmd":cmd }
    s = requests.session()
    r = s.post(url, data=params)
    XmlData=r.text.encode("utf-8")
    #print(XmlData)
    root = ET.fromstring(XmlData)
    time.sleep(t*time_machine)
    return root[0].text


def get_main_categry():
    categry_all=[]
    main_categry= send_cmd('ListAll(Eval_Data(find_ceng,a@class=cate_link,value<space>text_only))').split(',')
    i=0
    home_id=0
    for big_categry in main_categry:
        big_categry_array=big_categry.split('<space>')
        categry_all.append([home_categry[home_id],big_categry_array[1],big_categry_array[0]])
        i=i+1
        if u'その他' in big_categry_array[1]:
            print(home_categry[home_id], big_categry_array[1], big_categry_array[0])
            home_id=home_id+1
    return categry_all



def update_small_categry(categry_all):
    categry_all_2_level=[]
    lb=[]
    with open('categry22.csv', mode='w') as f:
        for i in range(len(categry_all)):

            try:
                b2 = 'Eval_Data(click_by_ceng,div@id=cat_list_wrap;a@value=%s,1,click)' % (categry_all[i][-1])
                send_cmd(b2, 4)
                b3 = 'Eval_Data(find_ceng,ul@class=cate_list;a@all,value<space>text_only)'

                mm = send_cmd(b3, 1).split('%%|')
                for t in mm:
                    yuanshi = copy.deepcopy(categry_all[i])
                    categry_all_2_level.append(yuanshi)
                    vv = t.split('<space>')
                    categry_all_2_level[-1].append(vv[1])
                    categry_all_2_level[-1].append(vv[0])
                    print(','.join(categry_all_2_level[-1]))
                    lb.append(','.join(categry_all_2_level[-1]))
                b4 = 'Eval_Data(click_by_ceng,input@value=戻る,2,click)'
                send_cmd(b4, 10)
            except:
                print('error one time')
                yuanshi = copy.deepcopy(categry_all[i])
                categry_all_2_level.append(yuanshi)
                print(','.join(categry_all_2_level[-1]))
                lb.append(','.join(categry_all_2_level[-1]))
                b5='Eval_Data(click_by_ceng,a@class~=popup_category,1,click)'
                send_cmd(b5, 10)

    print('\%%|'.join(lb))



gg=get_main_categry()
update_small_categry(gg)