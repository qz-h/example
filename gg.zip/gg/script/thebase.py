import os
import csv
import time
from datetime import datetime


def Execute(cmd='', para1='', para2='', para3='', para4=''):
    global hoge
    return hoge.Execute('%s' % (cmd), '%s' % (para1), '%s' % (para2), '%s' % (para3), '%s' % (para4))


def WriteLog(msg='', tag='', log_name=''):
    global hoge
    hoge.WriteLog('%s' % (msg), '%s' % (tag))


def alert(msg=''):
    global hoge
    hoge.alert('%s' % (msg))


def intTryParse(value):
    try:
        return int(value), False
    except ValueError:
        return value, True


class Variation:
    def __init__(self, title, instock):
        self.title = title
        self.instock = instock


class Product:
    def __init__(self, id):
        self.title = ""
        self.url = ""
        self.variations = []
        self.msg = ""
        self.timestamp = None
        self.id = id

    def openItemPage(self):
        if Execute("go_to", self.url, "1") == "ok":
            i = 0
            while i < 6:
                time.sleep(1)
                strTemp = Execute("find_ceng", "h1@all", "html_all")
                if "商品編集" in strTemp:
                    return True
                i = (i + 1)
            return False
        else:
            return False

    def addVariation(self, title, instock):
        self.variations.append(Variation(title, instock))

    def updateItemVariation(self):
        sum_variation = 0
        strTemp = Execute("find_ceng", "div@id=x_stockWrapper;div@class=item_add", "text_only")
        if strTemp == "null":
            return True
        else:
            sum_variation = len(strTemp.split("%%|"))

        # alert(string.Format("表示中種類={0}", sum_variation));

        for i in range(sum_variation):
            tag = Execute("find_ceng", "input@id=ItemVariation%s" % (i), "value")
            tag = tag.strip()
            # alert(string.Format("表示中tag={0}", tag));
            targetStock = 0  # デフォルト在庫数を０にする
            for j in range(len(self.variations)):
                # alert(string.Format("tag=[{0}] t=[{1}]", tag, variations[j].title));
                if self.variations[j].title == tag:
                    targetStock = self.variations[j].instock
                elif self.variations[j].title.strip() == "削除":
                    targetStock = 0
                Execute("setAttr_by_ceng", "input@id=ItemVariationStock{i}" % (i), "1", "value", targetStock)
                time.sleep(0.5)
        self.save()
        # 完了時間を記録する
        self.timestamp = datetime.now().strftime("%Y/%m/%d %H:%M:%S")

    def save(self):
        form_target = self.url
        form_target = form_target.replace("https://admin.thebase.in", "")
        form_target = form_target.replace("http://admin.thebase.in", "")
        if Execute("post_by_form_action", form_target, "1") == "ok":
            i = 0
            while i < 6:
                time.sleep(1)
                strTemp = Execute("find_ceng", "h1@all", "html_all")
                strTemp = strTemp.replace(" ", "")
                if "商品管理" in strTemp:
                    return True
                i = i + 1
            return False
        else:
            return False


def loadProducts(path):
    global products
    global idList
    products = {}
    idList = []

    with open(path, 'r') as f:
        reader = csv.reader(f)
        header = next(reader)  # ヘッダーを読み飛ばしたい時
        rowID = 1
        for row in reader:
            rowID = rowID + 1
            if len(row) >= 4:
                id = row[0]
                variation = row[1]
                instock_str = row[2]
                flag = row[3]
                instock, errorFlag = intTryParse(instock_str)
                if errorFlag:
                    msg_error = ("CSVフォーマットエラー。行Num：%s" % (rowID))
                    alert(msg_error)
                    return msg_error
            else:
                msg_error = "CSVフォーマットエラー。行Num：%s" % (rowID)
                alert(msg_error)
                return msg_error

            if products.has_key(id):
                # すでに存在する場合
                products[id].addVariation(variation, instock)
            else:
                # 新規追加の場合
                product = Product(id)
                product.addVariation(variation, instock)
                products[id] = product

            if id not in idList:
                idList.append(id)


def readProductsFromSite():
    title_href_str = Execute("find_ceng", "div@class=itemlistSort__item;a@all", "text_only<space>href")
    WriteLog("title_href_str=%s" % (title_href_str), "readProductsFromSite")
    if (title_href_str != "null"):
        title_href_str = title_href_str.strip()

        title_href_lists = title_href_str.split('%%|')
        for title_href in title_href_lists:
            space = "<space>"
            title_href_array = title_href.Split(space)
            if len(title_href_array) == 2:

                # 収集成功の場合のみ対応する
                title = title_href_array[0].strip()
                href = title_href_array[1].strip()
                WriteLog("title=" + title, "readProductsFromSite", "thebase.log")
                WriteLog("href=" + href, "readProductsFromSite", "thebase.log")
                if title.endswith("]"):

                    # 管理番号が存在する場合のみ処理する
                    title = title[0:-1]
                    loc = title.find("[")
                    if (loc > 0):
                        # 管理番号が存在する場合のみ処理する
                        id = title[loc + 1:]
                        if products.has_key(id):
                            # すでに存在する場合.URLを更新する
                            # 存在しない場合は無視する
                            products[id].url = href
                        else:
                            WriteLog("no exit in products, id=" + id, "readProductsFromSite", "thebase.log")
                    else:
                        WriteLog("no word [", "readProductsFromSite", "thebase.log")
                else:
                    WriteLog("not endwith ]", "readProductsFromSite", "thebase.log")


def updateInstock():
    work_count = products.Count
    alert("在庫更新開始")
    WriteLog("在庫更新開始", "readProductsFromSite", "thebase.log")
    for id in products.keys():
        work_count = work_count - 1
        if len(products[id].url) > 0:
            openResult = products[id].openItemPage()
            if openResult:
                products[id].updateItemVariation()
                products[id].msg = "sucess"
                alert("更新済み（ID=%s)。残り%s件" % (id, work_count))
            else:
                products[id].msg = "Can not open product page";
                alert("無視（ID=%s)。残り%s件" % (id, work_count))
        else:
            products[id].msg = "Product not exist";
            alert("無視（ID=%s)。残り%s件" % (id, work_count))
    alert("在庫更新完了")


def exportResult():
    global idList
    global products
    results = [['id', 'option', 'instock', 'result', 'time']]

    for id in idList:
        for v in products[id].variations:
            results.append(id, v.title, v.instock, products[id].msg, products[id].timestamp)

    with open("thebase_result.csv", 'w', newline='') as f:
        writer = csv.writer(f)
        writer.writerows(results)


products = {}
idList = []
path = hoge.can1

alert('path={0}' % (path))

if os.path.exists(path):
    WriteLog("csv exist", "work")
    alert("Load CSV")
    if loadProducts(path):
        alert("商品データ取り込み")
        WriteLog("商品データ取り込み", "work", "thebase.log")
        readProductsFromSite()
        # サイト上にある商品の在庫を更新する
        WriteLog("在庫更新開始", "work", "thebase.log")
        updateInstock()
        # 更新の結果を出力
        WriteLog("出力開始", "work")
        exportResult()
        msg = "更新完了"
        WriteLog(msg, "work")
    else:
        msg = "在庫管理データロード失敗"
        WriteLog(msg, "work")
else:
    msg = f"ファイル：{path} not exit"
    WriteLog(msg, "work");
