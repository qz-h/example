import os
from subprocess import call
import subprocess

target_folder='''D:/yumi/hebi180705/hebi180705/rgb/train'''
exe_path='''C:/Users\D\Documents\MobaXterm\home\work\Visual_Studio_2015\Projects\inpaint\Release\inpaint.exe'''

def feature_all(target,tag, output_file_name='result.csv'):
    for root, dirs, files in os.walk(target):
        # print('-'*10)
        # print('root:{}'.format(root))
        # print('dirs:{}'.format(dirs))
        # print('files:{}'.format(files))
        for file in files:
            if file.endswith('.bmp'):
                para=([exe_path,
                      '{0}/{1}'.format(root,file),
                      'out',
                      '{}'.format(tag),
                       output_file_name
                      ])
                print(para)
                p = subprocess.Popen(para, shell=True, stdout=subprocess.PIPE, stderr=subprocess.STDOUT)
                for line in p.stdout.readlines():
                    print(line)

                retval = p.wait()

moshi='09qian2_val'
if moshi=='train':
    #好的种子Flag等于0，坏的等于1
    target_folder='''D:/yumi/hebi180705/hebi180705/rgb/train/good'''
    target_folder='''D:\yumi\hebi180707/rgb/train/good/'''
    feature_all(target_folder,0)

    target_folder='''D:\yumi\hebi180707/rgb/train/bad/'''
    feature_all(target_folder,1)
elif moshi=='hou2':
    output_file_name='hou2_result.csv'
    target_folder = '''D:\yumi\hebi180707/rgb/val_hou2\good'''
    feature_all(target_folder, 0, output_file_name)

    target_folder = '''D:\yumi\hebi180707/rgb/val_hou2/bad'''
    feature_all(target_folder, 1, output_file_name)
elif moshi=='hou3':
    output_file_name='hou3_result.csv'
    target_folder = '''D:\yumi\hebi180707/rgb/val_hou3\good'''
    feature_all(target_folder, 0, output_file_name)

    target_folder = '''D:\yumi\hebi180707/rgb/val_hou3/bad'''
    feature_all(target_folder, 1, output_file_name)
elif moshi=='qian2':
    output_file_name='qian2hou2_result.csv'
    target_folder = '''D:\yumi\qian2_20180709/rgb/train\good/'''
    feature_all(target_folder, 0, output_file_name)

    target_folder = '''D:\yumi\qian2_20180709/rgb/train/bad/'''
    feature_all(target_folder, 1, output_file_name)

    target_folder = '''D:\yumi\hou2_20180709/rgb/train\good/'''
    feature_all(target_folder, 0, output_file_name)

    target_folder = '''D:\yumi\hou2_20180709/rgb/train/bad/'''
    feature_all(target_folder, 1, output_file_name)

elif moshi=='09qian2_val':
    output_file_name='09_val_qian2_result.csv'
    target_folder = '''D:\yumi\qian2_20180709/rgb/val\good/'''
    feature_all(target_folder, 0, output_file_name)

    target_folder = '''D:\yumi\qian2_20180709/rgb/val/bad/'''
    feature_all(target_folder, 1, output_file_name)

elif moshi=='09hou2_val':
    output_file_name='09_val_hou2_result.csv'
    target_folder = '''D:\yumi\hou2_20180709/rgb/val\good/'''
    feature_all(target_folder, 0, output_file_name)

    target_folder = '''D:\yumi\hou2_20180709/rgb/val/bad/'''
    feature_all(target_folder, 1, output_file_name)