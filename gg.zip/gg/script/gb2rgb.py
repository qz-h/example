import os
from subprocess import call
import shutil
import subprocess
target_folder='''D:/yumi/hebi180705/hebi180705/org/train'''
output_folder='''D:/yumi/hebi180705/hebi180705/rgb/train'''
exe_path='''C:/Users\D\Documents\MobaXterm\home\work\Visual_Studio_2015\Projects\inpaint\Release\inpaint.exe'''

def convert_all(target, des):
    for root, dirs, files in os.walk(target):
        # print('-'*10)
        # print('root:{}'.format(root))
        # print('dirs:{}'.format(dirs))
        # print('files:{}'.format(files))
        for file in files:
            if file.endswith('.bmp'):
                dest='{0}/{1}'.format(des,file)
                para=([exe_path,
                      '{0}/{1}'.format(root,file),
                      'gb2rgb',
                      'temp.bmp'
                      ])
                print(para)
                p = subprocess.Popen(para, shell=True, stdout=subprocess.PIPE, stderr=subprocess.STDOUT)
                for line in p.stdout.readlines():
                    print(line)

                retval = p.wait()
                print(dest)
                shutil.copy('temp.bmp',dest)



moshi='qian2hou2_val'
if moshi=='train':
    target_folder='''D:\yumi\hebi180707\org/train\good'''
    output_folder='''D:\yumi\hebi180707/rgb/train\good'''
    convert_all(target_folder, output_folder)

    target_folder='''D:\yumi\hebi180707\org/train/bad/'''
    output_folder='''D:\yumi\hebi180707/rgb/train/bad/'''
    convert_all(target_folder, output_folder)

elif moshi=='hou2':
#ce shi shuju
    target_folder='D:\yumi\hebi180707\org/val/good\hou2'
    output_folder='D:\yumi\hebi180707/rgb/val_hou2/good'
    convert_all(target_folder, output_folder)
    target_folder='D:\yumi\hebi180707\org/val/bad\hou2'
    output_folder='D:\yumi\hebi180707/rgb/val_hou2/bad'
    convert_all(target_folder, output_folder)
elif moshi=='hou3':
    target_folder='D:\yumi\hebi180707\org/val/good\hou3'
    output_folder='D:\yumi\hebi180707/rgb/val_hou3/good'
    convert_all(target_folder, output_folder)
    target_folder='D:\yumi\hebi180707\org/val/bad\hou3'
    output_folder='D:\yumi\hebi180707/rgb/val_hou3/bad'
    convert_all(target_folder, output_folder)
elif moshi=='qian2':
    target_folder = 'D:\yumi\qian2_20180709\org/train\good/'
    output_folder = 'D:\yumi\qian2_20180709/rgb/train\good/'
    convert_all(target_folder, output_folder)
    target_folder = 'D:\yumi\qian2_20180709\org/train/bad/'
    output_folder = 'D:\yumi\qian2_20180709/rgb/train/bad/'
    convert_all(target_folder, output_folder)
elif moshi=='hou2_09':
    target_folder = 'D:\yumi\hou2_20180709\org/train\good/'
    output_folder = 'D:\yumi\hou2_20180709/rgb/train\good/'
    convert_all(target_folder, output_folder)
    target_folder = 'D:\yumi\hou2_20180709\org/train/bad/'
    output_folder = 'D:\yumi\hou2_20180709/rgb/train/bad/'
    convert_all(target_folder, output_folder)

elif moshi=='qian2hou2_val':
    target_folder = 'D:\yumi\qian2_20180709\org/val\good/'
    output_folder = 'D:\yumi\qian2_20180709/rgb/val\good/'
    convert_all(target_folder, output_folder)
    target_folder = 'D:\yumi\qian2_20180709\org/val/bad/'
    output_folder = 'D:\yumi\qian2_20180709/rgb/val/bad/'
    convert_all(target_folder, output_folder)

    target_folder = 'D:\yumi\hou2_20180709\org/val\good/'
    output_folder = 'D:\yumi\hou2_20180709/rgb/val\good/'
    convert_all(target_folder, output_folder)
    target_folder = 'D:\yumi\hou2_20180709\org/val/bad/'
    output_folder = 'D:\yumi\hou2_20180709/rgb/val/bad/'
    convert_all(target_folder, output_folder)