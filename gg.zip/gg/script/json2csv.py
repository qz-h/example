import pandas as pd
df = pd.read_json("ouput_new.json")
df.to_csv("ouput.csv")