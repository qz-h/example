import sqlite3
import xml.etree.ElementTree as ET
import time

import requests
time_machine=2.0
def make_db():
    conn = sqlite3.connect('work.db')
    c = conn.cursor()
    c.execute('''CREATE TABLE Dat
           (ID  integer primary key,
           URL           TEXT    NOT NULL,
           html           TEXT
           title         TEXT,
           money         REAL,
           qijian         REAL,
           zhuangtai1         TEXT,
           zhuangtai2         TEXT,
           zhuangtai3         TEXT,
           zhuangtai4         TEXT,
           zhuangtai5         TEXT,
           zhuangtai6         TEXT,
           zhuangtai7         TEXT,
           zhuangtai8         TEXT
           );''')
    conn.commit()
    conn.close()
def insert_db(urls):
    conn = sqlite3.connect('work.db')
    c = conn.cursor()
    for t in urls:
        c.execute("insert into Dat (URL) values (?)", t)
    conn.commit()
    conn.close()
def update_db(url,html):
    conn = sqlite3.connect('work.db')
    c = conn.cursor()
    c.execute("update Dat set html= ? where URL=?", (html,url))
    conn.commit()
    conn.close()
def show_all():
    conn = sqlite3.connect('work.db')
    c = conn.cursor()
    select_sql = 'select * from Dat'
    for row in c.execute(select_sql):
        print(row)

# #make_db()
# insert_db(['a','b'])
# update_db('a','a_html')
# show_all()





def restart(t=3):
    url = "http://127.0.0.1:8989/restart"
    params = { }
    s = requests.session()
    r = s.post(url, data=params)
    XmlData=r.text.encode("utf-8")
    #print(XmlData)
    root = ET.fromstring(XmlData)
    time.sleep(t*time_machine)
    return root[0].text

def send_cmd(cmd,t=2):
    url = "http://127.0.0.1:8989/cmd-call"
    params = {"cmd":cmd }
    s = requests.session()
    r = s.post(url, data=params)
    XmlData=r.text.encode("utf-8")
    #print(XmlData)
    root = ET.fromstring(XmlData)
    time.sleep(t*time_machine)
    return root[0].text

print(send_cmd('Kvs_Query(%=1%)'))