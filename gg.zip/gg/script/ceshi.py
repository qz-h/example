all_step_buffer = {}


def count_all_step( left_card ):
    if left_card in all_step_buffer:
        return all_step_buffer[left_card]
    else:
        all_routes = 0
        takemax=left_card+1
        if takemax>4:
            takemax=4
        for take_card in range(1, takemax, 1):
            if take_card < left_card:
                next_step_left_card = left_card-take_card
                all_routes = all_routes + count_all_step(next_step_left_card)
            else:
                all_routes = all_routes+1
        all_step_buffer[left_card] = all_routes
        return all_routes
def count_all_step2( left_card ):
    return 2**(left_card-1)
if __name__ == '__main__':
    print('{2}\t{0}_{1}'.format(1, count_all_step(1),1))
    print('{2}\t{0}_{1}'.format(2, count_all_step(2),2))
    print('{2}\t{0}_{1}'.format(4, count_all_step(3),3))
    print('{2}\t{0}_{1}'.format(8, count_all_step(4),4))
    print('{2}\t{0}_{1}'.format(16, count_all_step(5),5))
    print('{2}\t{0}_{1}'.format(-1, count_all_step(10), 10))
