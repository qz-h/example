
import pandas as pd
# CSVファイルの読み込み
df = pd.read_csv("qian2hou2_result.csv")
print (df.head(3).to_string())
non_0_num=[0,0]

#mo shi 1
target_col_num=252
#moshi 2
#target_col_num=251
for i in range(2,target_col_num,1):
    non_0_num.append(df[df[str(i)]>0][str(i)].count())
print(non_0_num)

ordered_num = sorted(non_0_num)

print (ordered_num[-80])

print('B ={0}'.format(df['253'].mean()))
print('R ={0}'.format(df['254'].mean()))
