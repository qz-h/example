import sys    # 1. argparseをインポート
import glob
import xml.etree.ElementTree as ET
user_tree={}
def search_user(str):
    users=glob.glob("./buff/*.html")
    i=0
    for user in users:
        user_tree['%s'%(i)]=user
        print("%d\t%s"%(i,user[:-3]))
def show_user(str):
    if str in user_tree:
        path=user_tree
        tree = ET.parse(path)
        root = tree.getroot()
        for element in root.findall('.licence'):
            name = element.find('item')
            print(name.text)
'''
list d
show user
add user site
'''
arguments = sys.argv
if len(arguments)>0:
    cmd=arguments[0]
    para1=''
    para2=''
    if len(arguments) > 1:
        para1=arguments[1]
    if len(arguments)>2:
        para2=arguments[2]
    if cmd=='list':
        search_user(para1)
    elif cmd=='show':
        show_user(para1)
else:
    print("Please write cmd")