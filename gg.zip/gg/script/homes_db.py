import xml.etree.ElementTree as ET
import time

import requests
time_machine=2.0


def restart(t=3):
    url = "http://127.0.0.1:8989/restart"
    params = { }
    s = requests.session()
    r = s.post(url, data=params)
    XmlData=r.text.encode("utf-8")
    #print(XmlData)
    root = ET.fromstring(XmlData)
    time.sleep(t*time_machine)
    return root[0].text

def send_cmd(cmd,t=2):
    url = "http://127.0.0.1:8989/cmd-call"
    params = {"cmd":cmd }
    s = requests.session()
    r = s.post(url, data=params)
    XmlData=r.text.encode("utf-8")
    #print(XmlData)
    root = ET.fromstring(XmlData)
    time.sleep(t*time_machine)
    return root[0].text

class city_loader:
    def __init__(self,city_name,url):
        self.city_name=city_name
        self.url=url
        self.max_page_num = 20
        self.today_filter = True

    def set_max_page(self,max_page_num):
        self.max_page_num=max_page_num
    def set_today_filter(self,status):
        self.today_filter=status
    def run(self):
        d1='Eval_Data(go_to,%s,5)'%(self.url)
        c1='Eval_Data(set_select_by_value,cond[walkminutesh],10,0)'
        c2='Eval_Data(set_select_by_value,cond[houseageh],30,0)'
        only_today='Eval_Data(set_select_by_value,cond[newdate],1,0)'
        only_3_day = 'Eval_Data(set_select_by_value,cond[newdate],3,0)'

        order_by_new = 'Eval_Data(set_select_by_value,cond[sortby],newdate,0)'

        a2='Eval_Data(click_by_ceng,input@name=cond[mbg][3001],1,click)'
        a2='Eval_Data(uncheck_box_by_name,cond[mbg][3001])'

        a3='Eval_Data(click_by_ceng,input@name=cond[mbg][3003],1,click)'
        a3='Eval_Data(uncheck_box_by_name,cond[mbg][3003])'

        a4='Eval_Data(click_by_ceng,input@name=cond[madori][11],1,click)'
        a4='Eval_Data(check_box_by_name,cond[madori][11])'

        a5='Eval_Data(click_by_ceng,input@name=cond[madori][12],1,click)'

        netx_page='Eval_Data(click_link_by_value,次ヘ,1)'
        '''not exit'''

        save_command='Kvs_Add(%s,Eval_Data(find_ceng,div@class~=mergeBuilding,html_all))'%(self.city_name)



        print(send_cmd(d1,6))
        print(send_cmd(c1,0.5))
        print(send_cmd(c2,0.5))
        print(send_cmd(order_by_new, 1))

        # if self.today_filter:
        #     print(send_cmd(only_today,0.5))
        # else:
        #     print(send_cmd(only_3_day,0.5))

        print(send_cmd(a2,0.5))
        print(send_cmd(a3,0.5))
        print(send_cmd(a4,0.5))
        print(send_cmd(a5,3))
        next_page_result='ok'
        page_num=0


        while next_page_result=='ok':
            print(send_cmd(save_command),3)
            page_num=page_num+1
            print('%s: next_page_result=%s' % (page_num, next_page_result))
            if page_num >= self.max_page_num:
                break
            next_page_result=send_cmd(netx_page,6)

        print('finish')

citys=['https://www.homes.co.jp/chintai/tokyo/chiyoda-city/list/',
'https://www.homes.co.jp/chintai/tokyo/chuo-city/list/',
'https://www.homes.co.jp/chintai/tokyo/minato-city/list/',
'https://www.homes.co.jp/chintai/tokyo/shinjuku-city/list/',
'https://www.homes.co.jp/chintai/tokyo/bunkyo-city/list/',
'https://www.homes.co.jp/chintai/tokyo/shibuya-city/list/',
'https://www.homes.co.jp/chintai/tokyo/taito-city/list/',
'https://www.homes.co.jp/chintai/tokyo/sumida-city/list/',
'https://www.homes.co.jp/chintai/tokyo/koto-city/list/',
'https://www.homes.co.jp/chintai/tokyo/arakawa-city/list/',
'https://www.homes.co.jp/chintai/tokyo/adachi-city/list/',
'https://www.homes.co.jp/chintai/tokyo/katsushika-city/list/',
'https://www.homes.co.jp/chintai/tokyo/edogawa-city/list/',
'https://www.homes.co.jp/chintai/tokyo/shinagawa-city/list/',
'https://www.homes.co.jp/chintai/tokyo/meguro-city/list/',
'https://www.homes.co.jp/chintai/tokyo/ota-city/list/',
'https://www.homes.co.jp/chintai/tokyo/setagaya-city/list/',
'https://www.homes.co.jp/chintai/tokyo/nakano-city/list/',
'https://www.homes.co.jp/chintai/tokyo/suginami-city/list/',
'https://www.homes.co.jp/chintai/tokyo/nerima-city/list/',
'https://www.homes.co.jp/chintai/tokyo/toshima-city/list/',
'https://www.homes.co.jp/chintai/tokyo/kita-city/list/',
'https://www.homes.co.jp/chintai/tokyo/itabashi-city/list/'
]

tokyo_citys_23=['https://www.homes.co.jp/chintai/tokyo/chiyoda-city/list/',
'https://www.homes.co.jp/chintai/tokyo/chuo-city/list/',
'https://www.homes.co.jp/chintai/tokyo/minato-city/list/',
'https://www.homes.co.jp/chintai/tokyo/shinjuku-city/list/',
'https://www.homes.co.jp/chintai/tokyo/bunkyo-city/list/',
'https://www.homes.co.jp/chintai/tokyo/shibuya-city/list/',
'https://www.homes.co.jp/chintai/tokyo/taito-city/list/'
]
main_citys=[
'https://www.homes.co.jp/chintai/tokyo/toshima-city/list/'
]

city_map={}
for k in main_citys:
    city_short=k[38:-6]
    city_map[city_short]=k

time_machine=2
for k,v in city_map.items():
    print('Start to load: %s'%(k))
    city_reader=city_loader(k,v)
    # city_reader.set_today_filter(False)
    city_reader.set_max_page(30)
    city_reader.run()